package com.cxplayer.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.util.Base64;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.media.app.NotificationCompat.MediaStyle;
import androidx.media.session.MediaButtonReceiver;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CxplayerPlaybackService extends Service implements
        MediaPlayer.OnPreparedListener,
        MediaPlayer.OnCompletionListener,
        MediaPlayer.OnErrorListener,
        AudioManager.OnAudioFocusChangeListener {

    public static final String CHANNEL_ID = "cxplayer_playback_channel";
    public static final int NOTIFICATION_ID = 4201;

    private static final String ACTION_TOGGLE_PLAY = "com.cxplayer.app.ACTION_TOGGLE_PLAY";
    private static final String ACTION_NEXT = "com.cxplayer.app.ACTION_NEXT";
    private static final String ACTION_PREVIOUS = "com.cxplayer.app.ACTION_PREVIOUS";
    private static final String ACTION_STOP = "com.cxplayer.app.ACTION_STOP";

    public interface ServiceEventListener {
        void onTrackPrepared(double durationSec);
        void onTimeUpdate(double currentTimeSec, double durationSec);
        void onStateChanged(boolean isPlaying);
        void onTrackEnded();
        void onRemoteNext();
        void onRemotePrevious();
        void onRemoteTogglePlay();
        void onAudioFocusLost(boolean transientLoss);
        void onAudioError(String message);
    }

    public class LocalBinder extends Binder {
        public CxplayerPlaybackService getService() {
            return CxplayerPlaybackService.this;
        }
    }

    private final IBinder binder = new LocalBinder();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService artworkExecutor = Executors.newSingleThreadExecutor();

    private MediaPlayer mediaPlayer;
    private MediaSessionCompat mediaSession;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private PowerManager.WakeLock wakeLock;

    @Nullable
    private ServiceEventListener listener;

    private boolean isPrepared = false;
    private boolean playWhenPrepared = false;
    private boolean isPlayingState = false;
    private boolean noisyReceiverRegistered = false;
    private boolean foregroundActive = false;

    private float currentVolume = 0.85f;
    private float currentPlaybackRate = 1.0f;

    private String currentTrackId = "";
    private String currentTitle = "Cxplayer";
    private String currentArtist = "Ready";
    private String currentAlbum = "Cxplayer";
    private double knownDurationSec = 0.0;
    private Bitmap currentArtwork = null;

    private final BroadcastReceiver becomingNoisyReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction())) {
                pausePlayback();
                if (listener != null) {
                    listener.onAudioFocusLost(true);
                }
            }
        }
    };

    private final Runnable progressTicker = new Runnable() {
        @Override
        public void run() {
            if (mediaPlayer != null && isPrepared && isPlayingState) {
                double pos = Math.max(0.0, mediaPlayer.getCurrentPosition() / 1000.0);
                double dur = getDurationSeconds();
                if (listener != null) {
                    listener.onTimeUpdate(pos, dur);
                }
                updateMediaSessionState();
                mainHandler.postDelayed(this, 250);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Cxplayer::AudioWakeLock");
            wakeLock.setReferenceCounted(false);
        }

        mediaSession = new MediaSessionCompat(this, "CxplayerMediaSession");
        mediaSession.setCallback(new MediaSessionCompat.Callback() {
            @Override
            public void onPlay() {
                playPlayback();
            }

            @Override
            public void onPause() {
                pausePlayback();
            }

            @Override
            public void onSkipToNext() {
                if (listener != null) {
                    listener.onRemoteNext();
                }
            }

            @Override
            public void onSkipToPrevious() {
                if (listener != null) {
                    listener.onRemotePrevious();
                }
            }

            @Override
            public void onSeekTo(long posMs) {
                seekToSeconds(posMs / 1000.0);
            }

            @Override
            public void onStop() {
                pausePlayback();
                stopForegroundCompat(true);
            }
        });
        mediaSession.setActive(true);

        IntentFilter noisyFilter = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        ContextCompat.registerReceiver(this, becomingNoisyReceiver, noisyFilter, ContextCompat.RECEIVER_NOT_EXPORTED);
        noisyReceiverRegistered = true;

        updateMediaSessionMetadata();
        updateMediaSessionState();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_TOGGLE_PLAY.equals(action)) {
                if (isPlayingState) {
                    pausePlayback();
                } else {
                    playPlayback();
                }
            } else if (ACTION_NEXT.equals(action)) {
                if (listener != null) {
                    listener.onRemoteNext();
                }
            } else if (ACTION_PREVIOUS.equals(action)) {
                if (listener != null) {
                    listener.onRemotePrevious();
                }
            } else if (ACTION_STOP.equals(action)) {
                pausePlayback();
                stopForegroundCompat(true);
            } else {
                MediaButtonReceiver.handleIntent(mediaSession, intent);
            }
        }
        return START_NOT_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public void setServiceEventListener(@Nullable ServiceEventListener eventListener) {
        this.listener = eventListener;
    }

    public void loadTrack(
            String trackId,
            String title,
            String artist,
            String album,
            String audioUrl,
            @Nullable String coverUrl,
            double fallbackDurationSec
    ) {
        this.currentTrackId = trackId != null ? trackId : "";
        this.currentTitle = title != null && !title.isEmpty() ? title : "Untitled Track";
        this.currentArtist = artist != null && !artist.isEmpty() ? artist : "Unknown Artist";
        this.currentAlbum = album != null && !album.isEmpty() ? album : "Cxplayer";
        this.knownDurationSec = fallbackDurationSec > 0 ? fallbackDurationSec : 0.0;
        this.isPrepared = false;
        this.playWhenPrepared = false;

        loadArtworkAsync(coverUrl, this.currentTrackId);
        updateMediaSessionMetadata();
        updateNotification();

        if (audioUrl == null || audioUrl.trim().isEmpty()) {
            return;
        }

        try {
            releasePlayerOnly();
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
            );
            mediaPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            mediaPlayer.setVolume(currentVolume, currentVolume);
            mediaPlayer.setOnPreparedListener(this);
            mediaPlayer.setOnCompletionListener(this);
            mediaPlayer.setOnErrorListener(this);

            Uri uri = Uri.parse(audioUrl);
            mediaPlayer.setDataSource(getApplicationContext(), uri);
            mediaPlayer.prepareAsync();
        } catch (Exception e) {
            isPlayingState = false;
            if (listener != null) {
                listener.onAudioError("Unable to prepare audio source: " + e.getMessage());
            }
        }
    }

    public void playPlayback() {
        if (!requestAudioFocus()) {
            return;
        }

        if (mediaPlayer == null) {
            return;
        }

        if (!isPrepared) {
            playWhenPrepared = true;
            return;
        }

        try {
            if (!mediaPlayer.isPlaying()) {
                mediaPlayer.start();
            }
            applyPlaybackRateIfPlaying();
            isPlayingState = true;
            acquireWakeLock();
            startForegroundWithNotification();
            updateMediaSessionState();
            startProgressTicker();
            if (listener != null) {
                listener.onStateChanged(true);
            }
        } catch (Exception e) {
            if (listener != null) {
                listener.onAudioError("Failed to start playback: " + e.getMessage());
            }
        }
    }

    public void pausePlayback() {
        playWhenPrepared = false;
        if (mediaPlayer != null && isPrepared) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                }
            } catch (IllegalStateException ignored) {
            }
        }
        isPlayingState = false;
        stopProgressTicker();
        releaseWakeLock();
        updateMediaSessionState();
        updateNotification();
        if (listener != null) {
            listener.onStateChanged(false);
        }
    }

    public void seekToSeconds(double seconds) {
        if (mediaPlayer == null || !isPrepared) {
            return;
        }
        double dur = getDurationSeconds();
        double clamped = dur > 0 ? Math.max(0.0, Math.min(dur, seconds)) : Math.max(0.0, seconds);
        try {
            mediaPlayer.seekTo((int) Math.round(clamped * 1000.0));
            updateMediaSessionState();
            if (listener != null) {
                listener.onTimeUpdate(clamped, dur);
            }
        } catch (IllegalStateException ignored) {
        }
    }

    public void setVolume(float volume) {
        this.currentVolume = Math.max(0f, Math.min(1f, volume));
        if (mediaPlayer != null) {
            try {
                mediaPlayer.setVolume(this.currentVolume, this.currentVolume);
            } catch (IllegalStateException ignored) {
            }
        }
    }

    public void setPlaybackRate(float rate) {
        this.currentPlaybackRate = Math.max(0.5f, Math.min(2.0f, rate));
        applyPlaybackRateIfPlaying();
        updateMediaSessionState();
    }

    private void applyPlaybackRateIfPlaying() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && mediaPlayer != null && isPrepared && mediaPlayer.isPlaying()) {
            try {
                PlaybackParams params = mediaPlayer.getPlaybackParams();
                params.setSpeed(currentPlaybackRate);
                mediaPlayer.setPlaybackParams(params);
            } catch (Exception ignored) {
            }
        }
    }

    public double getCurrentTimeSeconds() {
        if (mediaPlayer == null || !isPrepared) {
            return 0.0;
        }
        try {
            return Math.max(0.0, mediaPlayer.getCurrentPosition() / 1000.0);
        } catch (IllegalStateException e) {
            return 0.0;
        }
    }

    public double getDurationSeconds() {
        if (mediaPlayer != null && isPrepared) {
            try {
                int ms = mediaPlayer.getDuration();
                if (ms > 0) {
                    return ms / 1000.0;
                }
            } catch (IllegalStateException ignored) {
            }
        }
        return knownDurationSec;
    }

    public boolean isPlaying() {
        return isPlayingState;
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        isPrepared = true;
        int ms = mp.getDuration();
        if (ms > 0) {
            knownDurationSec = ms / 1000.0;
        }
        updateMediaSessionMetadata();
        updateMediaSessionState();
        if (listener != null) {
            listener.onTrackPrepared(getDurationSeconds());
        }
        if (playWhenPrepared) {
            playWhenPrepared = false;
            playPlayback();
        }
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        isPlayingState = false;
        stopProgressTicker();
        updateMediaSessionState();
        updateNotification();
        if (listener != null) {
            listener.onStateChanged(false);
            listener.onTrackEnded();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        isPrepared = false;
        isPlayingState = false;
        stopProgressTicker();
        releaseWakeLock();
        updateMediaSessionState();
        if (listener != null) {
            listener.onStateChanged(false);
            listener.onAudioError("Android MediaPlayer error (" + what + "/" + extra + ")");
        }
        return true;
    }

    @Override
    public void onAudioFocusChange(int focusChange) {
        switch (focusChange) {
            case AudioManager.AUDIOFOCUS_LOSS:
                pausePlayback();
                if (listener != null) {
                    listener.onAudioFocusLost(false);
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                pausePlayback();
                if (listener != null) {
                    listener.onAudioFocusLost(true);
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                if (mediaPlayer != null) {
                    try {
                        float duck = Math.max(0.15f, currentVolume * 0.35f);
                        mediaPlayer.setVolume(duck, duck);
                    } catch (IllegalStateException ignored) {
                    }
                }
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if (mediaPlayer != null) {
                    try {
                        mediaPlayer.setVolume(currentVolume, currentVolume);
                    } catch (IllegalStateException ignored) {
                    }
                }
                break;
        }
    }

    private boolean requestAudioFocus() {
        if (audioManager == null) {
            return true;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (audioFocusRequest == null) {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build();
                audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(attrs)
                        .setOnAudioFocusChangeListener(this)
                        .build();
            }
            return audioManager.requestAudioFocus(audioFocusRequest) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        } else {
            @SuppressWarnings("deprecation")
            int res = audioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            return res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }
    }

    private void abandonAudioFocus() {
        if (audioManager == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioFocusRequest != null) {
            audioManager.abandonAudioFocusRequest(audioFocusRequest);
        } else {
            @SuppressWarnings("deprecation")
            int ignored = audioManager.abandonAudioFocus(this);
        }
    }

    private void startForegroundWithNotification() {
        Intent serviceIntent = new Intent(this, CxplayerPlaybackService.class);
        ContextCompat.startForegroundService(this, serviceIntent);
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        foregroundActive = true;
    }

    private void updateNotification() {
        if (!foregroundActive && !isPlayingState) {
            return;
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, buildNotification());
        }
    }

    private void stopForegroundCompat(boolean removeNotification) {
        foregroundActive = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(removeNotification ? STOP_FOREGROUND_REMOVE : STOP_FOREGROUND_DETACH);
        } else {
            @SuppressWarnings("deprecation")
            boolean remove = removeNotification;
            stopForeground(remove);
        }
    }

    private Notification buildNotification() {
        Intent launchIntent = new Intent(this, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        PendingIntent prevIntent = serviceActionIntent(ACTION_PREVIOUS, 1);
        PendingIntent toggleIntent = serviceActionIntent(ACTION_TOGGLE_PLAY, 2);
        PendingIntent nextIntent = serviceActionIntent(ACTION_NEXT, 3);

        Bitmap largeIcon = currentArtwork != null
                ? currentArtwork
                : BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_cxplayer)
                .setLargeIcon(largeIcon)
                .setContentTitle(currentTitle)
                .setContentText(currentArtist)
                .setSubText(currentAlbum)
                .setContentIntent(contentIntent)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(isPlayingState)
                .addAction(R.drawable.ic_media_prev, "Previous", prevIntent)
                .addAction(
                        isPlayingState ? R.drawable.ic_media_pause : R.drawable.ic_media_play,
                        isPlayingState ? "Pause" : "Play",
                        toggleIntent
                )
                .addAction(R.drawable.ic_media_next, "Next", nextIntent)
                .setStyle(new MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2))
                .build();
    }

    private PendingIntent serviceActionIntent(String action, int requestCode) {
        Intent intent = new Intent(this, CxplayerPlaybackService.class);
        intent.setAction(action);
        return PendingIntent.getService(
                this,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private void updateMediaSessionMetadata() {
        if (mediaSession == null) return;
        MediaMetadataCompat.Builder builder = new MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, currentTitle)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, currentArtist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, currentAlbum)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, (long) Math.round(getDurationSeconds() * 1000.0));

        if (currentArtwork != null) {
            builder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, currentArtwork);
        }
        mediaSession.setMetadata(builder.build());
    }

    private void updateMediaSessionState() {
        if (mediaSession == null) return;
        long actions = PlaybackStateCompat.ACTION_PLAY
                | PlaybackStateCompat.ACTION_PAUSE
                | PlaybackStateCompat.ACTION_PLAY_PAUSE
                | PlaybackStateCompat.ACTION_SKIP_TO_NEXT
                | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                | PlaybackStateCompat.ACTION_SEEK_TO
                | PlaybackStateCompat.ACTION_STOP;

        int state = isPlayingState ? PlaybackStateCompat.STATE_PLAYING : PlaybackStateCompat.STATE_PAUSED;
        long positionMs = (long) Math.round(getCurrentTimeSeconds() * 1000.0);

        mediaSession.setPlaybackState(
                new PlaybackStateCompat.Builder()
                        .setActions(actions)
                        .setState(state, positionMs, isPlayingState ? currentPlaybackRate : 0f)
                        .build()
        );
    }

    private void loadArtworkAsync(@Nullable final String coverUrl, final String expectedTrackId) {
        currentArtwork = null;
        if (coverUrl == null || coverUrl.trim().isEmpty()) {
            return;
        }
        artworkExecutor.execute(() -> {
            Bitmap loaded = null;
            try {
                if (coverUrl.startsWith("data:image/")) {
                    int comma = coverUrl.indexOf(',');
                    if (comma != -1) {
                        byte[] bytes = Base64.decode(coverUrl.substring(comma + 1), Base64.DEFAULT);
                        loaded = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    }
                } else if (coverUrl.startsWith("http://") || coverUrl.startsWith("https://")) {
                    HttpURLConnection conn = (HttpURLConnection) new URL(coverUrl).openConnection();
                    conn.setConnectTimeout(4000);
                    conn.setReadTimeout(4000);
                    try (InputStream is = conn.getInputStream()) {
                        loaded = BitmapFactory.decodeStream(is);
                    } finally {
                        conn.disconnect();
                    }
                }
            } catch (Exception ignored) {
            }

            final Bitmap finalBitmap = loaded;
            if (finalBitmap != null) {
                mainHandler.post(() -> {
                    if (expectedTrackId.equals(currentTrackId)) {
                        currentArtwork = finalBitmap;
                        updateMediaSessionMetadata();
                        updateNotification();
                    }
                });
            }
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Cxplayer Playback",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Lock-screen and notification audio controls");
            channel.setShowBadge(false);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private void startProgressTicker() {
        mainHandler.removeCallbacks(progressTicker);
        mainHandler.post(progressTicker);
    }

    private void stopProgressTicker() {
        mainHandler.removeCallbacks(progressTicker);
    }

    private void acquireWakeLock() {
        if (wakeLock != null && !wakeLock.isHeld()) {
            wakeLock.acquire(4 * 60 * 60 * 1000L);
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
    }

    private void releasePlayerOnly() {
        if (mediaPlayer != null) {
            try {
                mediaPlayer.reset();
                mediaPlayer.release();
            } catch (Exception ignored) {
            }
            mediaPlayer = null;
        }
        isPrepared = false;
    }

    @Override
    public void onDestroy() {
        stopProgressTicker();
        releasePlayerOnly();
        releaseWakeLock();
        abandonAudioFocus();
        if (noisyReceiverRegistered) {
            try {
                unregisterReceiver(becomingNoisyReceiver);
            } catch (Exception ignored) {
            }
            noisyReceiverRegistered = false;
        }
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
            mediaSession = null;
        }
        artworkExecutor.shutdownNow();
        super.onDestroy();
    }
}
