package com.cxplayer.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.IBinder;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Queue;

@CapacitorPlugin(name = "CxplayerAudio")
public class CxplayerAudioPlugin extends Plugin implements CxplayerPlaybackService.ServiceEventListener {

    private CxplayerPlaybackService playbackService;
    private boolean isBound = false;
    private final Queue<Runnable> pendingCommands = new ArrayDeque<>();

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            CxplayerPlaybackService.LocalBinder binder = (CxplayerPlaybackService.LocalBinder) service;
            playbackService = binder.getService();
            playbackService.setServiceEventListener(CxplayerAudioPlugin.this);
            isBound = true;
            while (!pendingCommands.isEmpty()) {
                Runnable task = pendingCommands.poll();
                if (task != null) {
                    task.run();
                }
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
            playbackService = null;
        }
    };

    @Override
    public void load() {
        super.load();
        ensureServiceBound();
    }

    private void ensureServiceBound() {
        if (isBound && playbackService != null) {
            return;
        }
        Context context = getContext();
        Intent intent = new Intent(context, CxplayerPlaybackService.class);
        context.startService(intent);
        context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    private void runWithService(Runnable action) {
        ensureServiceBound();
        if (isBound && playbackService != null) {
            action.run();
        } else {
            pendingCommands.add(action);
        }
    }

    @PluginMethod
    public void cacheTrackData(PluginCall call) {
        String id = call.getString("id", "track");
        String base64Data = call.getString("base64Data");
        String mimeType = call.getString("mimeType", "audio/wav");

        if (base64Data == null || base64Data.isEmpty()) {
            call.reject("Missing base64 audio data");
            return;
        }

        String safeId = (id != null ? id : "track").replaceAll("[^a-zA-Z0-9._-]", "_");
        if (safeId.length() > 64) {
            safeId = safeId.substring(0, 64);
        }

        String ext = ".audio";
        if (mimeType != null) {
            if (mimeType.contains("mpeg") || mimeType.contains("mp3")) ext = ".mp3";
            else if (mimeType.contains("wav")) ext = ".wav";
            else if (mimeType.contains("ogg")) ext = ".ogg";
            else if (mimeType.contains("flac")) ext = ".flac";
            else if (mimeType.contains("mp4") || mimeType.contains("m4a") || mimeType.contains("aac")) ext = ".m4a";
        }

        try {
            File cacheRoot = new File(getContext().getCacheDir(), "cxplayer_tracks");
            if (!cacheRoot.exists() && !cacheRoot.mkdirs()) {
                call.reject("Unable to create audio cache directory");
                return;
            }
            File targetFile = new File(cacheRoot, safeId + ext);
            String canonicalRoot = cacheRoot.getCanonicalPath();
            String canonicalTarget = targetFile.getCanonicalPath();
            if (!canonicalTarget.startsWith(canonicalRoot + File.separator)) {
                call.reject("Invalid cache path");
                return;
            }

            byte[] decoded = Base64.decode(base64Data, Base64.DEFAULT);
            try (FileOutputStream fos = new FileOutputStream(targetFile)) {
                fos.write(decoded);
            }

            JSObject ret = new JSObject();
            ret.put("fileUri", Uri.fromFile(targetFile).toString());
            call.resolve(ret);
        } catch (IOException | IllegalArgumentException e) {
            call.reject("Failed to cache audio track: " + e.getMessage());
        }
    }

    @PluginMethod
    public void loadTrack(PluginCall call) {
        String id = call.getString("id", "");
        String title = call.getString("title", "Cxplayer");
        String artist = call.getString("artist", "Unknown Artist");
        String album = call.getString("album", "Cxplayer");
        String audioUrl = call.getString("audioUrl", "");
        String coverUrl = call.getString("coverUrl");
        Double duration = call.getDouble("duration", 0.0);

        if (!isAllowedAudioUri(audioUrl)) {
            call.reject("Unsupported audio URI scheme");
            return;
        }

        final double fallbackDur = duration != null ? duration : 0.0;
        runWithService(() -> {
            playbackService.loadTrack(id, title, artist, album, audioUrl, coverUrl, fallbackDur);
            JSObject ret = new JSObject();
            ret.put("duration", playbackService.getDurationSeconds());
            call.resolve(ret);
        });
    }

    @PluginMethod
    public void play(PluginCall call) {
        runWithService(() -> {
            playbackService.playPlayback();
            call.resolve();
        });
    }

    @PluginMethod
    public void pause(PluginCall call) {
        runWithService(() -> {
            playbackService.pausePlayback();
            call.resolve();
        });
    }

    @PluginMethod
    public void seek(PluginCall call) {
        Double seconds = call.getDouble("seconds", 0.0);
        final double target = seconds != null ? Math.max(0.0, seconds) : 0.0;
        runWithService(() -> {
            playbackService.seekToSeconds(target);
            call.resolve();
        });
    }

    @PluginMethod
    public void setVolume(PluginCall call) {
        Double volume = call.getDouble("volume", 0.85);
        final float clamped = (float) Math.max(0.0, Math.min(1.0, volume != null ? volume : 0.85));
        runWithService(() -> {
            playbackService.setVolume(clamped);
            call.resolve();
        });
    }

    @PluginMethod
    public void setPlaybackRate(PluginCall call) {
        Double rate = call.getDouble("rate", 1.0);
        final float clamped = (float) Math.max(0.5, Math.min(2.0, rate != null ? rate : 1.0));
        runWithService(() -> {
            playbackService.setPlaybackRate(clamped);
            call.resolve();
        });
    }

    @PluginMethod
    public void getState(PluginCall call) {
        runWithService(() -> {
            JSObject ret = new JSObject();
            ret.put("currentTime", playbackService.getCurrentTimeSeconds());
            ret.put("duration", playbackService.getDurationSeconds());
            ret.put("isPlaying", playbackService.isPlaying());
            call.resolve(ret);
        });
    }

    private boolean isAllowedAudioUri(String uri) {
        if (uri == null || uri.trim().isEmpty()) {
            return false;
        }
        String lower = uri.toLowerCase();
        return lower.startsWith("http://")
                || lower.startsWith("https://")
                || lower.startsWith("file://")
                || lower.startsWith("content://")
                || lower.startsWith("capacitor://");
    }

    @Override
    protected void handleOnDestroy() {
        if (isBound) {
            if (playbackService != null) {
                playbackService.setServiceEventListener(null);
            }
            try {
                getContext().unbindService(serviceConnection);
            } catch (IllegalArgumentException ignored) {
            }
            isBound = false;
        }
        super.handleOnDestroy();
    }

    @Override
    public void onTrackPrepared(double durationSec) {
        JSObject payload = new JSObject();
        payload.put("currentTime", playbackService != null ? playbackService.getCurrentTimeSeconds() : 0.0);
        payload.put("duration", durationSec);
        notifyListeners("timeUpdate", payload);
    }

    @Override
    public void onTimeUpdate(double currentTimeSec, double durationSec) {
        JSObject payload = new JSObject();
        payload.put("currentTime", currentTimeSec);
        payload.put("duration", durationSec);
        notifyListeners("timeUpdate", payload);
    }

    @Override
    public void onStateChanged(boolean isPlaying) {
        JSObject payload = new JSObject();
        payload.put("isPlaying", isPlaying);
        notifyListeners("stateChange", payload);
    }

    @Override
    public void onTrackEnded() {
        notifyListeners("trackEnded", new JSObject());
    }

    @Override
    public void onRemoteNext() {
        notifyListeners("remoteNext", new JSObject());
    }

    @Override
    public void onRemotePrevious() {
        notifyListeners("remotePrevious", new JSObject());
    }

    @Override
    public void onRemoteTogglePlay() {
        notifyListeners("remoteTogglePlay", new JSObject());
    }

    @Override
    public void onAudioFocusLost(boolean transientLoss) {
        JSObject payload = new JSObject();
        payload.put("transient", transientLoss);
        notifyListeners("audioFocusLost", payload);
    }

    @Override
    public void onAudioError(String message) {
        JSObject payload = new JSObject();
        payload.put("message", message);
        notifyListeners("audioError", payload);
    }
}
