# Cxplayer Multi-Platform Build & Android APK Guide

Cxplayer runs from one shared React + TypeScript + Vite codebase (`src/`) across both **Web / PWA** and **Android APK** (via Capacitor 8).

---

## 1. Shared Architecture

- **`src/platform/PlayerController.ts`**: Routes playback through `WebAudioAdapter` in browsers and `NativeAudioAdapter` on Android (`Capacitor.isNativePlatform()`), serializing track loading, seeking, volume, and playback rate.
- **`src/platform/WebAudioAdapter.ts`**: `HTMLAudioElement` + Web Audio API `AnalyserNode` + Web MediaSession (`navigator.mediaSession`).
- **`src/platform/NativeAudioAdapter.ts`**: Bridges React UI events to the native Android foreground media service (`CxplayerAudioPlugin`). Converts uploaded/synthesized `blob:` URLs into cached local files via `cacheTrackData`.
- **`src/platform/StateSyncAdapter.ts`**: Local-first cross-platform state persistence using `@capacitor/preferences` on Android and `localStorage` + `BroadcastChannel` on Web, plus portable JSON Export/Import inside **Settings**.
- **`src/platform/PlatformLifecycle.ts`**: Handles Android hardware Back button navigation (closes open sheets/sidebars before minimizing), app backgrounding flush, Status Bar styling, and Splash Screen dismissal.
- **`android/app/src/main/java/com/cxplayer/app/CxplayerPlaybackService.java`**: Native Android `ForegroundService` (`foregroundServiceType="mediaPlayback"`) using `MediaPlayer`, `MediaSessionCompat`, lock-screen & notification controls (`NotificationCompat.MediaStyle`), `AudioFocusRequest`, headphone-disconnect (`ACTION_AUDIO_BECOMING_NOISY`) pause, and `PARTIAL_WAKE_LOCK` for uninterrupted screen-off playback.

---

## 2. Web Build (Hostinger / Static Hosting)

```bash
npm install
npm test
npm run build
```

Upload the contents of `dist/` (which includes `.htaccess` for SPA fallback and PWA service worker assets) into your web host's `public_html/`.

---

## 3. Building the Android APK Locally

### Prerequisites
- Node.js 20+
- JDK 21 (Temurin / OpenJDK)
- Android Studio or Android SDK Command-Line Tools (`compileSdk 36`, `minSdk 24`)

### Build a Debug APK
```bash
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```
Output APK:
`android/app/build/outputs/apk/debug/app-debug.apk`

Install on a connected phone via ADB:
```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 4. Configuring Signed Release APKs

Generate an upload/release keystore (keep `.jks` private — **never commit it to Git**):
```bash
keytool -genkeypair -v \
  -keystore cxplayer-release.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias cxplayer
```

`android/app/build.gradle` reads release credentials from environment variables or untracked `~/.gradle/gradle.properties`:
```bash
export CXPLAYER_KEYSTORE_PATH="/absolute/path/to/cxplayer-release.jks"
export CXPLAYER_KEYSTORE_PASSWORD="your-keystore-password"
export CXPLAYER_KEY_ALIAS="cxplayer"
export CXPLAYER_KEY_PASSWORD="your-key-password"

cd android
./gradlew assembleRelease
```
Signed Release APK output:
`android/app/build/outputs/apk/release/app-release.apk`

---

## 5. Automated APK Builds via GitHub Actions

Push this project to GitHub (`main` branch). The workflow at `.github/workflows/android-apk.yml` automatically:
1. Runs `npm test`, `npm run lint`, and `npm run build`
2. Syncs `dist/` into Android via `npx cap sync android`
3. Compiles and uploads `cxplayer-debug-apk`

To enable automated **Signed Release APK** builds in GitHub Actions, add these **Repository Secrets** in GitHub Settings:
- `ANDROID_KEYSTORE_BASE64` (`base64 -w 0 cxplayer-release.jks`)
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`
