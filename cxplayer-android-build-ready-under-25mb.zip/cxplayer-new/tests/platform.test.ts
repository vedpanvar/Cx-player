import test from 'node:test';
import assert from 'node:assert/strict';
import { PlayerController, detectPlatform } from '../src/platform/PlayerController';
import { CrossPlatformStateSyncAdapter } from '../src/platform/StateSyncAdapter';
import {
  AudioAdapter,
  AudioAdapterEventMap,
  AudioTrackPayload,
  PersistedAppState,
  PlatformKind
} from '../src/platform/types';

function createMockAdapter(kind: PlatformKind, duration = 120): {
  adapter: AudioAdapter;
  calls: string[];
  emit: <K extends keyof AudioAdapterEventMap>(
    event: K,
    ...args: Parameters<AudioAdapterEventMap[K]>
  ) => void;
  resolveLoad?: () => void;
  setAsyncLoad: (enabled: boolean) => void;
} {
  const calls: string[] = [];
  let currentTime = 0;
  let currentDuration = duration;
  let asyncLoad = false;
  let pendingResolve: (() => void) | undefined;

  const listeners: {
    [K in keyof AudioAdapterEventMap]: Set<AudioAdapterEventMap[K]>;
  } = {
    timeupdate: new Set(),
    loadedmetadata: new Set(),
    ended: new Set(),
    play: new Set(),
    pause: new Set(),
    remoteNext: new Set(),
    remotePrevious: new Set(),
    remoteTogglePlay: new Set(),
    audioFocusLost: new Set(),
    error: new Set()
  };

  const adapter: AudioAdapter = {
    kind,
    async loadTrack(track: AudioTrackPayload) {
      calls.push(`loadTrack:${track.id}`);
      currentDuration = track.duration ?? duration;
      if (asyncLoad) {
        await new Promise<void>((resolve) => {
          pendingResolve = resolve;
        });
      }
    },
    async play() {
      calls.push('play');
    },
    async pause() {
      calls.push('pause');
    },
    async seek(seconds: number) {
      currentTime = seconds;
      calls.push(`seek:${seconds}`);
    },
    async setVolume(volume: number) {
      calls.push(`volume:${volume}`);
    },
    async setMuted(muted: boolean) {
      calls.push(`muted:${muted}`);
    },
    async setPlaybackRate(rate: number) {
      calls.push(`rate:${rate}`);
    },
    getCurrentTime() {
      return currentTime;
    },
    getDuration() {
      return currentDuration;
    },
    getAnalyserNode() {
      return null;
    },
    getAudioElement() {
      return null;
    },
    on(event, handler) {
      listeners[event].add(handler);
      return () => listeners[event].delete(handler);
    },
    dispose() {
      calls.push('dispose');
      Object.values(listeners).forEach((set) => set.clear());
    }
  };

  return {
    adapter,
    calls,
    setAsyncLoad(enabled: boolean) {
      asyncLoad = enabled;
    },
    resolveLoad() {
      pendingResolve?.();
      pendingResolve = undefined;
    },
    emit(event, ...args) {
      listeners[event].forEach((fn) => {
        (fn as (...a: Parameters<AudioAdapterEventMap[typeof event]>) => void)(...args);
      });
    }
  };
}

test('detectPlatform defaults safely to web in non-native Node/browser environments', () => {
  assert.equal(detectPlatform(), 'web');
});

test('PlayerController clamps seek positions and deduplicates identical track loads', async () => {
  const mock = createMockAdapter('web', 180);
  const controller = new PlayerController(mock.adapter);

  const track: AudioTrackPayload = {
    id: 'track-1',
    title: 'After Hours',
    artist: 'Lumen Drive',
    album: 'Night Optics',
    audioUrl: 'https://example.com/audio.mp3',
    duration: 180
  };

  await controller.loadTrack(track);
  await controller.loadTrack(track);
  assert.deepEqual(mock.calls, ['loadTrack:track-1']);

  await controller.loadTrack(track, true);
  assert.deepEqual(mock.calls, ['loadTrack:track-1', 'loadTrack:track-1']);

  const clampedLow = await controller.seek(-15);
  assert.equal(clampedLow, 0);

  const clampedHigh = await controller.seek(500);
  assert.equal(clampedHigh, 180);

  controller.dispose();
});

test('PlayerController serializes play/seek behind async native track preparation', async () => {
  const mock = createMockAdapter('android', 95);
  mock.setAsyncLoad(true);
  const controller = new PlayerController(mock.adapter);
  assert.equal(controller.platform, 'android');

  const track: AudioTrackPayload = {
    id: 'local-1',
    title: 'Amber Run',
    artist: 'Phase North',
    album: 'Session 02',
    audioUrl: 'blob:http://localhost:3000/abc',
    duration: 95
  };

  const loadPromise = controller.loadTrack(track);
  const playPromise = controller.play();

  // Play must not run while native track data is still caching
  await Promise.resolve();
  assert.deepEqual(mock.calls, ['loadTrack:local-1']);

  mock.resolveLoad();
  await Promise.all([loadPromise, playPromise]);
  assert.deepEqual(mock.calls, ['loadTrack:local-1', 'play']);

  controller.dispose();
});

test('PlayerController forwards native lock-screen and focus events consistently', () => {
  const mock = createMockAdapter('android', 200);
  const controller = new PlayerController(mock.adapter);

  const received: string[] = [];
  controller.on('remoteNext', () => received.push('next'));
  controller.on('remotePrevious', () => received.push('prev'));
  controller.on('audioFocusLost', (transient) => received.push(`focus:${transient}`));

  mock.emit('remoteNext');
  mock.emit('remotePrevious');
  mock.emit('audioFocusLost', true);

  assert.deepEqual(received, ['next', 'prev', 'focus:true']);
  controller.dispose();
});

test('CrossPlatformStateSyncAdapter persists, exports, and validates imported JSON state', async () => {
  const storageMap = new Map<string, string>();
  const prevStorage = (globalThis as Record<string, unknown>).localStorage;
  (globalThis as Record<string, unknown>).localStorage = {
    getItem: (k: string) => storageMap.get(k) ?? null,
    setItem: (k: string, v: string) => {
      storageMap.set(k, v);
    }
  };

  try {
    const sync = new CrossPlatformStateSyncAdapter();
    const sampleState: PersistedAppState = {
      version: 1,
      updatedAt: 1700000000000,
      currentTrackId: 'cd-after-hours',
      currentTime: 42.5,
      queueTrackIds: ['cd-after-hours', 'cd-amber-run'],
      queueIndex: 0,
      likedSongIds: ['cd-after-hours'],
      downloadedSongIds: ['cd-amber-run'],
      djControlsEnabled: true,
      volume: 0.75,
      isMuted: false,
      isShuffle: true,
      repeatMode: 'all',
      pitchRate: 1.05,
      equalizerPreset: 'Warm Vinyl'
    };

    await sync.save(sampleState);
    const loaded = await sync.load();
    assert.deepEqual(loaded, sampleState);

    const exported = sync.exportJson(sampleState);
    const reimported = sync.importJson(exported);
    assert.deepEqual(reimported, sampleState);

    assert.equal(sync.importJson('{invalid-json'), null);
    assert.equal(sync.importJson('{"version": 99}'), null);

    sync.dispose();
  } finally {
    if (prevStorage === undefined) {
      delete (globalThis as Record<string, unknown>).localStorage;
    } else {
      (globalThis as Record<string, unknown>).localStorage = prevStorage;
    }
  }
});
