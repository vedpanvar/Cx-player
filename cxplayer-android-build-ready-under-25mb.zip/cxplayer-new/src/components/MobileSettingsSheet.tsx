import React, { useRef } from 'react';
import {
  X,
  Disc3,
  Volume2,
  VolumeX,
  Sliders,
  Search,
  Library,
  Upload,
  Download,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAudio } from '../context/AudioContext';
import { PhoneFileScanner } from './PhoneFileScanner';
import { PWAInstallCard } from './PWAInstallCard';

interface MobileSettingsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSearch: () => void;
  onOpenLibrary: () => void;
  onOpenEqualizer: () => void;
}

export const MobileSettingsSheet: React.FC<MobileSettingsSheetProps> = ({
  isOpen,
  onClose,
  onOpenSearch,
  onOpenLibrary,
  onOpenEqualizer
}) => {
  const {
    djControlsEnabled,
    toggleDjControls,
    volume,
    setVolumeLevel,
    isMuted,
    toggleMute,
    exportSyncState,
    importSyncState
  } = useAudio();
  const syncInputRef = useRef<HTMLInputElement>(null);

  const handleExportProfile = () => {
    const json = exportSyncState();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'cxplayer-sync-profile.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const handleImportProfile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        importSyncState(reader.result);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/30 backdrop-blur-md">
        <div className="absolute inset-0" onClick={onClose} />

        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 28, stiffness: 260 }}
          className="relative z-10 w-full max-w-lg bg-[#f6f6fa]/95 backdrop-blur-2xl border-t border-white rounded-t-[30px] p-4 sm:p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] shadow-[0_-16px_48px_rgba(15,23,42,0.16)] flex flex-col max-h-[86dvh] overflow-y-auto custom-scrollbar space-y-3.5 text-neutral-900"
        >
          <div className="w-10 h-1 rounded-full bg-neutral-300 mx-auto shrink-0" />

          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-black/[0.07]">
            <div>
              <h2 className="text-base font-semibold text-neutral-900">Settings</h2>
              <p className="text-xs text-neutral-500 mt-0.5">
                Upload songs, playback mode & sound
              </p>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="min-w-[44px] min-h-[44px] flex items-center justify-center text-neutral-600 hover:text-neutral-950 rounded-full bg-black/[0.05] transition-colors cursor-pointer"
              aria-label="Close Settings"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Upload Songs */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-neutral-800">
              <Upload className="w-3.5 h-3.5 text-orange-600" />
              <span>Upload Songs</span>
            </div>
            <PhoneFileScanner onSongUploadedPlay={onClose} />
          </div>

          {/* Persistent DJ Controls Toggle */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-white/80 border border-white shadow-sm flex items-center justify-between gap-4">
            <div className="flex items-start gap-3 min-w-0">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                  djControlsEnabled
                    ? 'bg-orange-600 text-white'
                    : 'bg-neutral-100 text-neutral-600'
                }`}
              >
                <Disc3 className="w-5 h-5" />
              </div>

              <div className="min-w-0">
                <div className="text-sm font-semibold text-neutral-900">DJ controls</div>
                <p className="text-xs text-neutral-500 mt-0.5 leading-snug">
                  Drop or lift the gold tonearm to play/pause and rotate the CD rim to seek.
                </p>
              </div>
            </div>

            <button
              type="button"
              role="switch"
              aria-checked={djControlsEnabled}
              aria-label="Toggle DJ controls"
              onClick={toggleDjControls}
              className={`relative w-12 h-7 rounded-full transition-colors cursor-pointer shrink-0 p-1 ${
                djControlsEnabled ? 'bg-orange-600' : 'bg-neutral-300'
              }`}
            >
              <span
                className={`block w-5 h-5 rounded-full bg-white shadow-md transition-transform ${
                  djControlsEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Quick Actions: Library, Search, Equalizer */}
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenLibrary();
              }}
              className="min-h-[46px] px-2.5 py-2 rounded-2xl bg-white/75 hover:bg-white border border-white shadow-sm text-xs font-medium text-neutral-800 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Library className="w-4 h-4 text-orange-600" />
              <span>Library</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenSearch();
              }}
              className="min-h-[46px] px-2.5 py-2 rounded-2xl bg-white/75 hover:bg-white border border-white shadow-sm text-xs font-medium text-neutral-800 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Search className="w-4 h-4 text-orange-600" />
              <span>Search</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenEqualizer();
              }}
              className="min-h-[46px] px-2.5 py-2 rounded-2xl bg-white/75 hover:bg-white border border-white shadow-sm text-xs font-medium text-neutral-800 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Sliders className="w-4 h-4 text-orange-600" />
              <span>Equalizer</span>
            </button>
          </div>

          {/* Volume Control */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-white/75 border border-white shadow-sm space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-neutral-700">Output Volume</span>
              <span className="tabular-nums text-neutral-500">
                {isMuted ? 'Muted' : `${Math.round(volume * 100)}%`}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={toggleMute}
                className="min-w-[44px] min-h-[44px] flex items-center justify-center text-neutral-600 hover:text-neutral-900 rounded-lg cursor-pointer"
                aria-label={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-4 h-4 text-orange-600" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={isMuted ? 0 : volume}
                onChange={(e) => setVolumeLevel(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-neutral-300 rounded-lg appearance-none cursor-pointer accent-orange-600"
              />
            </div>
          </div>

          {/* Cross-Platform State Backup & Sync */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-white/75 border border-white shadow-sm space-y-2.5">
            <div className="flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 text-orange-600" />
              <span className="text-xs font-semibold text-neutral-800">
                Cross-Platform Sync Backup
              </span>
            </div>
            <p className="text-[11px] text-neutral-500 leading-snug">
              Transfer your DJ controls, liked songs, equalizer, and queue preferences between Web and Android APK.
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleExportProfile}
                className="min-h-[40px] px-3 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export JSON</span>
              </button>
              <button
                type="button"
                onClick={() => syncInputRef.current?.click()}
                className="min-h-[40px] px-3 py-2 rounded-xl bg-black/[0.06] hover:bg-black/[0.1] text-neutral-800 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Import JSON</span>
              </button>
              <input
                ref={syncInputRef}
                type="file"
                accept="application/json,.json"
                onChange={handleImportProfile}
                className="hidden"
              />
            </div>
          </div>

          <PWAInstallCard />
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
