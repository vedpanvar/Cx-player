import React from 'react';
import { motion } from 'motion/react';
import { Play, Pause, Heart, ArrowDownToLine, CheckCircle2 } from 'lucide-react';
import { Song } from '../types';
import { useAudio } from '../context/AudioContext';

interface SongRowProps {
  song: Song;
  index?: number;
  songList?: Song[];
  showAlbum?: boolean;
}

export const SongRow: React.FC<SongRowProps> = ({
  song,
  index,
  songList,
  showAlbum = true
}) => {
  const {
    currentSong,
    isPlaying,
    playSong,
    togglePlay,
    likedSongIds,
    toggleLikeSong,
    downloadedSongIds,
    downloadSong,
    navigateTo
  } = useAudio();

  const isCurrent = currentSong?.id === song.id;
  const isLiked = likedSongIds.has(song.id);
  const isDownloaded = downloadedSongIds.has(song.id);

  const handlePlayClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isCurrent) {
      togglePlay();
    } else {
      playSong(song, songList || [song]);
    }
  };

  return (
    <div
      className={`group relative flex items-center justify-between p-2.5 sm:p-3 rounded-2xl transition-all duration-200 select-none ${
        isCurrent
          ? 'bg-purple-500/15 border border-purple-500/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]'
          : 'hover:bg-white/[0.06] border border-transparent'
      }`}
    >
      {/* Left: Index / Play Icon & Track Info */}
      <div className="flex items-center gap-3 sm:gap-4 min-w-0 flex-1 cursor-pointer" onClick={handlePlayClick}>
        {index !== undefined && (
          <div className="w-6 text-center flex-shrink-0">
            {isCurrent && isPlaying ? (
              <div className="flex items-end justify-center gap-0.5 h-4 w-4 mx-auto">
                <motion.span animate={{ height: ['20%', '100%', '30%'] }} transition={{ repeat: Infinity, duration: 0.6 }} className="w-1 bg-purple-400 rounded-full" />
                <motion.span animate={{ height: ['80%', '20%', '90%'] }} transition={{ repeat: Infinity, duration: 0.8 }} className="w-1 bg-indigo-400 rounded-full" />
                <motion.span animate={{ height: ['40%', '90%', '20%'] }} transition={{ repeat: Infinity, duration: 0.7 }} className="w-1 bg-pink-400 rounded-full" />
              </div>
            ) : (
              <span className={`font-mono text-xs ${isCurrent ? 'text-purple-400 font-bold' : 'text-neutral-500 group-hover:hidden'}`}>
                {index + 1}
              </span>
            )}
            <button
              onClick={handlePlayClick}
              className={`hidden group-hover:flex items-center justify-center w-6 h-6 rounded-full text-white mx-auto ${
                isCurrent ? 'text-purple-400' : 'text-neutral-300 hover:text-white'
              }`}
            >
              {isCurrent && isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>
          </div>
        )}

        {/* Cover Art with Hover Play */}
        <div className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-xl overflow-hidden flex-shrink-0 border border-white/10 shadow-md">
          <img src={song.coverUrl} alt={song.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
          <div className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${isCurrent ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
            {isCurrent && isPlaying ? (
              <Pause className="w-5 h-5 text-white" />
            ) : (
              <Play className="w-5 h-5 text-white fill-white ml-0.5" />
            )}
          </div>
        </div>

        {/* Title, Artist, Album */}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className={`font-bold text-sm truncate ${isCurrent ? 'text-purple-300' : 'text-white group-hover:text-purple-200'}`}>
              {song.title}
            </span>
            {song.isExplicit && (
              <span className="text-[9px] bg-white/15 text-neutral-300 font-mono px-1 py-0.2 rounded uppercase">
                EXPLICIT
              </span>
            )}
          </div>
          <div className="text-xs text-neutral-400 truncate mt-0.5 flex items-center gap-1">
            <span
              onClick={(e) => { e.stopPropagation(); navigateTo('artist', song.artistId); }}
              className="hover:underline hover:text-white transition-colors"
            >
              {song.artist}
            </span>
            {showAlbum && song.album && (
              <>
                <span className="text-neutral-600">•</span>
                <span className="text-neutral-500 truncate">{song.album}</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Right Controls: Like, Download, Duration */}
      <div className="flex items-center gap-1.5 sm:gap-3 ml-3">
        {/* Heart Like Button */}
        <motion.button
          whileTap={{ scale: 0.8 }}
          onClick={(e) => {
            e.stopPropagation();
            toggleLikeSong(song.id);
          }}
          className={`p-2 rounded-full transition-all ${
            isLiked ? 'text-rose-500 hover:scale-110' : 'text-neutral-500 hover:text-white hover:bg-white/10'
          }`}
          title={isLiked ? 'Remove from Liked' : 'Save to Liked Songs'}
        >
          <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
        </motion.button>

        {/* Download Track Button */}
        <motion.button
          whileTap={{ scale: 0.8 }}
          onClick={(e) => {
            e.stopPropagation();
            downloadSong(song);
          }}
          className={`p-2 rounded-full transition-all ${
            isDownloaded
              ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20'
              : 'text-neutral-500 hover:text-purple-300 hover:bg-white/10'
          }`}
          title={isDownloaded ? 'Downloaded (Offline Ready)' : 'Download MP3 to device'}
        >
          {isDownloaded ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          ) : (
            <ArrowDownToLine className="w-4 h-4" />
          )}
        </motion.button>

        {/* Duration */}
        <span className="text-xs font-mono text-neutral-400 w-10 text-right">
          {song.durationFormatted}
        </span>
      </div>
    </div>
  );
};
