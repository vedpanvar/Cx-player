import React, { useState, useMemo } from 'react';
import { 
  Music, 
  Play, 
  Pause, 
  Shuffle, 
  Folder, 
  HardDrive, 
  Heart, 
  Plus, 
  Search, 
  SlidersHorizontal, 
  Trash2, 
  FileAudio,
  Sparkles,
  ArrowUpDown,
  Smartphone
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { Song } from '../types';
import { PhoneFileScanner } from './PhoneFileScanner';

export const TracksView: React.FC = () => {
  const { 
    allSongs, 
    localSongs, 
    currentSong, 
    isPlaying, 
    playSong, 
    togglePlay, 
    toggleLikeSong, 
    likedSongIds, 
    addToQueue,
    deleteSong,
    folders,
    currentView
  } = useAudio();

  const isLikedView = currentView === 'liked';
  const baseSongs = useMemo(() => {
    return isLikedView 
      ? allSongs.filter((s) => likedSongIds.has(s.id))
      : allSongs;
  }, [allSongs, likedSongIds, isLikedView]);

  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<'title' | 'artist' | 'duration' | 'size'>('title');
  const [filterFolder, setFilterFolder] = useState<string>('all');

  const filteredSongs = useMemo(() => {
    return baseSongs
      .filter((song) => {
        const matchesSearch = 
          song.title.toLowerCase().includes(search.toLowerCase()) ||
          song.artist.toLowerCase().includes(search.toLowerCase()) ||
          (song.album && song.album.toLowerCase().includes(search.toLowerCase())) ||
          (song.fileName && song.fileName.toLowerCase().includes(search.toLowerCase()));

        const matchesFolder = 
          filterFolder === 'all' || 
          (song.folderName && song.folderName === filterFolder);

        return matchesSearch && matchesFolder;
      })
      .sort((a, b) => {
        if (sortBy === 'title') return a.title.localeCompare(b.title);
        if (sortBy === 'artist') return a.artist.localeCompare(b.artist);
        if (sortBy === 'duration') return b.duration - a.duration;
        if (sortBy === 'size') return (b.fileSize || 0) - (a.fileSize || 0);
        return 0;
      });
  }, [baseSongs, search, sortBy, filterFolder]);

  const handlePlayAll = () => {
    if (filteredSongs.length > 0) {
      playSong(filteredSongs[0], filteredSongs);
    }
  };

  const handleShufflePlay = () => {
    if (filteredSongs.length > 0) {
      const shuffled = [...filteredSongs].sort(() => Math.random() - 0.5);
      playSong(shuffled[0], shuffled);
    }
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-white/10">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight flex items-center gap-2.5">
            {isLikedView ? (
              <>
                <Heart className="w-6 h-6 text-rose-500 fill-rose-500" />
                <span>Favorites</span>
              </>
            ) : (
              <span>Tracks</span>
            )}
          </h1>
          <p className="text-xs text-neutral-400 mt-1">
            {baseSongs.length} track(s) {isLikedView ? 'in favorites' : 'available'}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={handlePlayAll}
            disabled={filteredSongs.length === 0}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>Play All</span>
          </button>

          <button
            onClick={handleShufflePlay}
            disabled={filteredSongs.length === 0}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-50 text-white font-medium text-xs border border-white/10 transition-colors cursor-pointer"
          >
            <Shuffle className="w-3.5 h-3.5 text-purple-400" />
            <span>Shuffle</span>
          </button>
        </div>
      </div>

      {/* Phone Audio File Scanner Dropzone */}
      <PhoneFileScanner />

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-2xl bg-white/[0.03] border border-white/5">
        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search title, artist, or file..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-black/40 border border-white/10 text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500 transition-colors"
          />
        </div>

        {/* Folder Filter & Sort Options */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          {folders.length > 1 && (
            <select
              value={filterFolder}
              onChange={(e) => setFilterFolder(e.target.value)}
              className="px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-xs text-neutral-300 focus:outline-none focus:border-purple-500 cursor-pointer"
            >
              <option value="all">All Folders ({baseSongs.length})</option>
              {folders.map((f) => (
                <option key={f.id} value={f.name}>
                  {f.name} ({f.songCount})
                </option>
              ))}
            </select>
          )}

          <div className="flex items-center gap-1 bg-black/40 border border-white/10 rounded-xl px-2 py-1">
            <ArrowUpDown className="w-3.5 h-3.5 text-purple-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent text-xs text-neutral-300 focus:outline-none cursor-pointer pr-1"
            >
              <option value="title">Sort: Title</option>
              <option value="artist">Sort: Artist</option>
              <option value="duration">Sort: Duration</option>
              <option value="size">Sort: Size</option>
            </select>
          </div>
        </div>
      </div>

      {/* Tracks List */}
      <div className="rounded-3xl bg-white/[0.02] border border-white/5 p-2 sm:p-4 divide-y divide-white/5">
        {filteredSongs.length === 0 ? (
          <div className="py-16 text-center text-neutral-400 space-y-3">
            {isLikedView ? (
              <>
                <Heart className="w-12 h-12 mx-auto text-rose-500/40" />
                <div className="text-base font-bold text-white">No Favorite Tracks Yet</div>
                <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                  Click the heart icon on any song to save it to your Favorites.
                </p>
              </>
            ) : (
              <>
                <Music className="w-12 h-12 mx-auto text-purple-400/40" />
                <div className="text-base font-bold text-white">No Audio Files Found</div>
                <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                  {search ? 'Try adjusting your search query.' : 'Use the file access button above to select audio files from your device.'}
                </p>
              </>
            )}
          </div>
        ) : (
          filteredSongs.map((song, idx) => {
            const isCurrent = currentSong?.id === song.id;
            const isLiked = likedSongIds.has(song.id);
            const sizeFormatted = song.fileSize 
              ? `${(song.fileSize / (1024 * 1024)).toFixed(1)} MB` 
              : null;

            return (
              <div
                key={song.id}
                className={`group flex items-center justify-between py-3 px-3 sm:px-4 rounded-2xl hover:bg-white/[0.06] transition-all ${
                  isCurrent ? 'bg-purple-600/15 border border-purple-500/30' : ''
                }`}
              >
                {/* Left: Index, Thumbnail & Metadata */}
                <div className="flex items-center gap-3 sm:gap-4 min-w-0 flex-1">
                  <span className="font-mono text-xs font-bold text-neutral-500 w-6 text-center flex-shrink-0">
                    {idx + 1}
                  </span>

                  <div
                    onClick={() => playSong(song, filteredSongs)}
                    className="relative w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 cursor-pointer shadow-md group/img"
                  >
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      className="w-full h-full object-cover"
                    />
                    <div className={`absolute inset-0 bg-black/50 flex items-center justify-center transition-opacity ${
                      isCurrent && isPlaying ? 'opacity-100' : 'opacity-0 group-hover/img:opacity-100'
                    }`}>
                      {isCurrent && isPlaying ? (
                        <Pause className="w-5 h-5 fill-white text-white" />
                      ) : (
                        <Play className="w-5 h-5 fill-white text-white ml-0.5" />
                      )}
                    </div>
                  </div>

                  <div className="min-w-0 flex-1">
                    <div
                      onClick={() => playSong(song, filteredSongs)}
                      className={`font-bold text-sm truncate cursor-pointer hover:text-purple-300 transition-colors flex items-center gap-2 ${
                        isCurrent ? 'text-purple-300' : 'text-white'
                      }`}
                    >
                      <span className="truncate">{song.title}</span>
                      {song.isLocal && (
                        <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-purple-500/20 border border-purple-500/30 text-purple-300 flex-shrink-0">
                          LOCAL
                        </span>
                      )}
                    </div>
                    
                    <div className="text-xs text-neutral-400 truncate flex items-center gap-2 mt-0.5">
                      <span>{song.artist}</span>
                      {song.folderName && (
                        <>
                          <span className="text-neutral-600">•</span>
                          <span className="text-neutral-500 truncate">{song.folderName}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right: Size, Format, Liked, Duration & Actions */}
                <div className="flex items-center gap-3 sm:gap-5 flex-shrink-0 ml-2">
                  {sizeFormatted && (
                    <span className="hidden md:inline-block font-mono text-[11px] text-neutral-400">
                      {sizeFormatted}
                    </span>
                  )}

                  <button
                    onClick={() => addToQueue(song)}
                    className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
                    title="Add to Up Next Queue"
                  >
                    <Plus className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => toggleLikeSong(song.id)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      isLiked ? 'text-rose-500' : 'text-neutral-500 hover:text-white hover:bg-white/10'
                    }`}
                    title={isLiked ? 'Remove from Favorites' : 'Add to Favorites'}
                  >
                    <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500' : ''}`} />
                  </button>

                  {song.isLocal && (
                    <button
                      onClick={() => deleteSong(song.id)}
                      className="p-1.5 rounded-lg text-neutral-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      title="Remove from Library"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <span className="font-mono text-xs text-neutral-300 w-10 text-right">
                    {song.durationFormatted}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
