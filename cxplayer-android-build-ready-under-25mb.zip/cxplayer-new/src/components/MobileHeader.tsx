import React from 'react';
import { MoreVertical } from 'lucide-react';

interface MobileHeaderProps {
  isUpNextOpen: boolean;
  onToggleUpNext: () => void;
  onOpenSettings: () => void;
}

export const MobileHeader: React.FC<MobileHeaderProps> = ({
  isUpNextOpen,
  onToggleUpNext,
  onOpenSettings
}) => {
  return (
    <header className="sticky top-0 z-30 w-full h-11 sm:h-12 px-4 shrink-0 select-none flex items-center justify-between bg-transparent">
      {/* Left: Compact Cxplayer Wordmark */}
      <div className="flex items-center shrink-0">
        <span className="text-xl font-semibold tracking-tight text-neutral-900 whitespace-nowrap">
          Cxplayer
        </span>
      </div>

      {/* Right: Stacked-Disc Up Next Button + Settings */}
      <div className="flex items-center gap-0.5 shrink-0">
        <button
          type="button"
          onClick={onToggleUpNext}
          className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full hover:bg-black/[0.05] transition-colors cursor-pointer active:scale-95"
          title={isUpNextOpen ? 'Close Up Next' : 'Open Up Next'}
          aria-label={isUpNextOpen ? 'Close Up Next sidebar' : 'Open Up Next sidebar'}
          aria-expanded={isUpNextOpen}
        >
          {/* Small Stacked-Disc Icon — turns burnt-orange when Up Next sidebar is open */}
          <svg
            width="24"
            height="22"
            viewBox="0 0 28 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
            className="transition-transform duration-200"
          >
            <defs>
              <linearGradient id="discSilver" x1="2" y1="2" x2="26" y2="20" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
                <stop offset="50%" stopColor="#d4d4d8" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#a1a1aa" stopOpacity="0.9" />
              </linearGradient>
              <linearGradient id="discOrange" x1="2" y1="2" x2="26" y2="20" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#fb923c" />
                <stop offset="55%" stopColor="#ea580c" />
                <stop offset="100%" stopColor="#c2410c" />
              </linearGradient>
            </defs>

            {/* Bottom Disc */}
            <ellipse
              cx="14"
              cy="17"
              rx="10.5"
              ry="4.2"
              fill={isUpNextOpen ? 'url(#discOrange)' : 'url(#discSilver)'}
              stroke={isUpNextOpen ? '#c2410c' : '#a1a1aa'}
              strokeWidth="1"
            />
            {/* Middle Disc */}
            <ellipse
              cx="14"
              cy="12.5"
              rx="10.5"
              ry="4.2"
              fill={isUpNextOpen ? 'url(#discOrange)' : 'url(#discSilver)'}
              stroke={isUpNextOpen ? '#fb923c' : '#d4d4d8'}
              strokeWidth="1"
            />
            {/* Top Disc */}
            <ellipse
              cx="14"
              cy="8"
              rx="10.5"
              ry="4.2"
              fill={isUpNextOpen ? 'url(#discOrange)' : 'url(#discSilver)'}
              stroke={isUpNextOpen ? '#fed7aa' : '#ffffff'}
              strokeWidth="1"
            />
            {/* Center Spindle Hole */}
            <ellipse
              cx="14"
              cy="8"
              rx="2.6"
              ry="1.1"
              fill={isUpNextOpen ? '#7c2d12' : '#71717a'}
            />
          </svg>
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          className="min-w-[40px] min-h-[44px] flex items-center justify-center rounded-full text-neutral-700 hover:text-neutral-950 hover:bg-black/[0.05] transition-colors cursor-pointer active:scale-95"
          title="Settings"
          aria-label="Open Settings"
        >
          <MoreVertical className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};
