import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  Trash2, 
  Plus, 
  BookmarkPlus, 
  MoreVertical, 
  GripVertical,
  Navigation,
  Check,
  Disc,
  FolderPlus,
  Sparkles
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { Song } from '../types';

interface UpNextQueuePanelProps {
  className?: string;
}

export const UpNextQueuePanel: React.FC<UpNextQueuePanelProps> = ({ className = '' }) => {
  const {
    queue,
    queueIndex,
    currentSong,
    isPlaying,
    isNeedleDown,
    playSong,
    removeFromQueue,
    clearQueue,
    togglePlay,
    toggleNeedle,
    addToQueue,
    allSongs
  } = useAudio();

  const [activeTab, setActiveTab] = useState<'up-next' | 'playlist'>('up-next');
  const [showAddModal, setShowAddModal] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const activeSong = currentSong || (queue ? queue[queueIndex] : undefined);
  const queueList = queue.length > 0 ? queue : allSongs;
  const currentIndex = activeSong ? queueList.findIndex(s => s.id === activeSong.id) : 0;
  const currentActualIndex = currentIndex !== -1 ? currentIndex : queueIndex;

  const handleSavePlaylist = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <aside className={`w-80 lg:w-[340px] xl:w-[360px] bg-[#0c0d16]/90 backdrop-blur-2xl border-l border-white/[0.08] flex flex-col h-full select-none shrink-0 ${className}`}>
      
      {/* Header with UP NEXT / PLAYLIST Tabs & Clear */}
      <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-white/[0.06]">
        <div className="flex items-center gap-6">
          <button
            onClick={() => setActiveTab('up-next')}
            className={`text-xs font-bold tracking-wider uppercase transition-all relative pb-1 cursor-pointer ${
              activeTab === 'up-next'
                ? 'text-white'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            UP NEXT
            {activeTab === 'up-next' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-indigo-400 rounded-full shadow-[0_0_8px_#a855f7]" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('playlist')}
            className={`text-xs font-bold tracking-wider uppercase transition-all relative pb-1 cursor-pointer ${
              activeTab === 'playlist'
                ? 'text-white'
                : 'text-neutral-500 hover:text-neutral-300'
            }`}
          >
            PLAYLIST
            {activeTab === 'playlist' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-indigo-400 rounded-full shadow-[0_0_8px_#a855f7]" />
            )}
          </button>
        </div>

        {/* Clear button */}
        {queue.length > 1 && (
          <button
            onClick={clearQueue}
            className="px-2.5 py-1 rounded-lg bg-white/[0.04] hover:bg-rose-500/20 text-neutral-400 hover:text-rose-300 border border-white/[0.06] hover:border-rose-500/30 text-[11px] font-medium transition-colors cursor-pointer"
          >
            Clear
          </button>
        )}
      </div>

      {/* Queue Track List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar px-3 py-3 space-y-1.5">
        {queueList.map((song, idx) => {
          const isCurrent = song.id === activeSong?.id;

          if (isCurrent) {
            return (
              /* Currently Playing Active Card */
              <div
                key={`${song.id}-${idx}-active`}
                onClick={() => toggleNeedle()}
                className="relative rounded-2xl p-2.5 bg-gradient-to-r from-purple-950/60 via-purple-900/30 to-indigo-950/40 border border-purple-500/40 shadow-[0_0_25px_rgba(168,85,247,0.15)] flex items-center justify-between gap-3 group cursor-pointer transition-all"
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  {/* Playing Airplane / Pointer Indicator */}
                  <div className="text-purple-400 flex-shrink-0">
                    <Navigation className="w-3.5 h-3.5 fill-purple-400 rotate-45" />
                  </div>

                  {/* Album Cover / CD Thumbnail */}
                  <div className="relative w-10 h-10 rounded-xl overflow-hidden border border-purple-500/40 flex-shrink-0 bg-neutral-900 shadow-md">
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/20" />
                  </div>

                  {/* Song Title & Artist */}
                  <div className="min-w-0 flex-1">
                    <div className="font-bold text-xs text-white truncate flex items-center gap-1.5">
                      <span>{song.title}</span>
                    </div>
                    <div className="text-[11px] text-purple-300 truncate">
                      {song.artist}
                    </div>
                    <div className="text-[10px] font-mono text-neutral-400">
                      {song.durationFormatted}
                    </div>
                  </div>
                </div>

                {/* Animated Purple Visualizer Bars */}
                <div className="flex items-end gap-1 h-4 pr-2">
                  <span className={`w-1 bg-purple-400 rounded-full ${isPlaying && isNeedleDown ? 'h-full animate-pulse' : 'h-1.5'}`} />
                  <span className={`w-1 bg-purple-400 rounded-full ${isPlaying && isNeedleDown ? 'h-2/3 animate-pulse delay-100' : 'h-2.5'}`} />
                  <span className={`w-1 bg-purple-400 rounded-full ${isPlaying && isNeedleDown ? 'h-full animate-pulse delay-200' : 'h-2'}`} />
                  <span className={`w-1 bg-purple-400 rounded-full ${isPlaying && isNeedleDown ? 'h-1/2 animate-pulse delay-75' : 'h-1'}`} />
                </div>
              </div>
            );
          }

          /* Inactive Queued Track Item */
          return (
            <div
              key={`${song.id}-${idx}`}
              className="group rounded-xl p-2 hover:bg-white/[0.04] transition-colors flex items-center justify-between gap-2.5 cursor-pointer"
            >
              {/* Drag Handle & Album Cover */}
              <div 
                onClick={() => playSong(song, queueList)}
                className="flex items-center gap-2.5 min-w-0 flex-1"
              >
                <div className="text-neutral-600 group-hover:text-neutral-400 cursor-grab flex-shrink-0">
                  <GripVertical className="w-3.5 h-3.5" />
                </div>

                <img
                  src={song.coverUrl}
                  alt={song.title}
                  className="w-10 h-10 rounded-xl object-cover border border-white/[0.08] flex-shrink-0"
                />

                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-xs text-neutral-200 group-hover:text-white truncate">
                    {song.title}
                  </div>
                  <div className="text-[11px] text-neutral-400 truncate">
                    {song.artist}
                  </div>
                </div>
              </div>

              {/* Duration & 3-dots Menu */}
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-mono text-neutral-500">
                  {song.durationFormatted}
                </span>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    removeFromQueue(idx);
                  }}
                  className="p-1 text-neutral-500 hover:text-white hover:bg-white/[0.08] rounded-lg opacity-60 group-hover:opacity-100 transition-all"
                  title="Remove"
                >
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Panel Actions */}
      <div className="p-4 border-t border-white/[0.06] grid grid-cols-2 gap-2.5 bg-black/20">
        <button
          onClick={() => {
            // Add a recommended track to queue
            const notInQueue = allSongs.find(s => !queue.some(q => q.id === s.id));
            if (notInQueue) addToQueue(notInQueue);
          }}
          className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-neutral-300 hover:text-white border border-white/[0.08] text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
        >
          <Plus className="w-3.5 h-3.5 text-purple-400" />
          <span>Add to Queue</span>
        </button>

        <button
          onClick={handleSavePlaylist}
          className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-neutral-300 hover:text-white border border-white/[0.08] text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
        >
          {saveSuccess ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-300">Saved!</span>
            </>
          ) : (
            <>
              <BookmarkPlus className="w-3.5 h-3.5 text-purple-400" />
              <span>Save as Playlist</span>
            </>
          )}
        </button>
      </div>

    </aside>
  );
};
