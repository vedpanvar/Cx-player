import React from 'react';

interface CxLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const CxLogo: React.FC<CxLogoProps> = ({
  size = 'md',
  showText = true,
  className = ''
}) => {
  const sizeMap = {
    sm: { container: 'w-8 h-8 rounded-lg', text: 'text-sm font-black', brandText: 'text-base font-extrabold' },
    md: { container: 'w-10 h-10 rounded-xl', text: 'text-lg font-black', brandText: 'text-xl font-extrabold' },
    lg: { container: 'w-12 h-12 rounded-2xl', text: 'text-xl font-black', brandText: 'text-2xl font-black' },
    xl: { container: 'w-16 h-16 rounded-3xl', text: 'text-3xl font-black', brandText: 'text-4xl font-black' },
  };

  const currentSize = sizeMap[size];

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Icon Badge */}
      <div
        className={`relative ${currentSize.container} bg-gradient-to-tr from-neutral-950 via-purple-950 to-indigo-950 border border-purple-500/40 p-0.5 shadow-[0_0_20px_rgba(168,85,247,0.45)] group-hover:scale-105 group-hover:shadow-[0_0_28px_rgba(168,85,247,0.7)] transition-all duration-300 flex items-center justify-center overflow-hidden flex-shrink-0`}
      >
        {/* Glowing Background Orbs */}
        <div className="absolute inset-0 bg-gradient-to-tr from-purple-600/40 via-indigo-600/30 to-blue-500/40 opacity-80" />
        <div className="absolute -bottom-2 -right-2 w-full h-full bg-cyan-500/30 blur-md rounded-full" />

        {/* Cx Monogram */}
        <span
          className={`relative z-10 ${currentSize.text} tracking-tighter bg-gradient-to-r from-white via-purple-100 to-indigo-300 bg-clip-text text-transparent font-sans italic group-hover:rotate-3 transition-transform duration-300 drop-shadow-[0_2px_10px_rgba(168,85,247,0.8)]`}
          style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}
        >
          Cx
        </span>
      </div>

      {/* Brand Text Name */}
      {showText && (
        <div className="flex flex-col">
          <span className={`${currentSize.brandText} tracking-tight leading-none bg-gradient-to-r from-white via-purple-100 to-purple-400 bg-clip-text text-transparent`}>
            Cxplayer
          </span>
        </div>
      )}
    </div>
  );
};
