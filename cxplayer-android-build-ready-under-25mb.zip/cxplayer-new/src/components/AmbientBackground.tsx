import React from 'react';
import { motion } from 'motion/react';
import { useAudio } from '../context/AudioContext';

export const AmbientBackground: React.FC = () => {
  const { isPlaying, currentSong, theme } = useAudio();

  // Dynamic gradient colors based on genre
  const getGenreGradient = () => {
    if (!currentSong) return 'from-purple-900/30 via-indigo-950/20 to-neutral-950';
    const genre = currentSong.genre.toLowerCase();
    if (genre.includes('synth') || genre.includes('electronic')) return 'from-purple-900/40 via-pink-900/20 to-indigo-950';
    if (genre.includes('hip hop') || genre.includes('rap')) return 'from-amber-900/30 via-orange-950/20 to-neutral-950';
    if (genre.includes('r&b') || genre.includes('soul')) return 'from-rose-900/30 via-purple-950/20 to-neutral-950';
    if (genre.includes('pop') || genre.includes('dance')) return 'from-cyan-900/30 via-indigo-950/20 to-neutral-950';
    if (genre.includes('rock') || genre.includes('indie')) return 'from-emerald-900/30 via-teal-950/20 to-neutral-950';
    return 'from-purple-900/30 via-indigo-950/20 to-neutral-950';
  };

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none">
      {/* Dynamic Background Base Gradient */}
      <div
        className={`absolute inset-0 bg-gradient-to-b ${getGenreGradient()} transition-colors duration-1000`}
      />

      {/* Floating Animated Ambient Glow Orbs */}
      <motion.div
        animate={{
          scale: isPlaying ? [1, 1.25, 1] : 1,
          opacity: isPlaying ? [0.35, 0.55, 0.35] : 0.25,
          x: [0, 30, -20, 0],
          y: [0, -20, 20, 0]
        }}
        transition={{
          repeat: Infinity,
          duration: 10,
          ease: 'easeInOut'
        }}
        className="absolute -top-40 -left-20 w-[500px] h-[500px] rounded-full bg-purple-600/30 blur-[140px]"
      />

      <motion.div
        animate={{
          scale: isPlaying ? [1.2, 1, 1.2] : 1,
          opacity: isPlaying ? [0.25, 0.45, 0.25] : 0.2,
          x: [0, -30, 20, 0],
          y: [0, 30, -20, 0]
        }}
        transition={{
          repeat: Infinity,
          duration: 12,
          ease: 'easeInOut'
        }}
        className="absolute top-1/2 -right-40 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-indigo-600/30 blur-[150px]"
      />

      <motion.div
        animate={{
          scale: isPlaying ? [1, 1.3, 1] : 1,
          opacity: isPlaying ? [0.2, 0.4, 0.2] : 0.15
        }}
        transition={{
          repeat: Infinity,
          duration: 8,
          ease: 'easeInOut'
        }}
        className="absolute -bottom-40 left-1/3 w-[550px] h-[550px] rounded-full bg-pink-600/20 blur-[130px]"
      />

      {/* Subtle Noise Texture Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-black/20 to-black/60 opacity-60 pointer-events-none" />
    </div>
  );
};
