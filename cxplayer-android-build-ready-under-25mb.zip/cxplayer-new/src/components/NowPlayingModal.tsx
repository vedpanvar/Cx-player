import React, { useState } from 'react';
import {
  ChevronDown,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Heart,
  Volume2,
  VolumeX,
  SlidersHorizontal,
  Mic2,
  ListMusic,
  Share2,
  Clock,
  Sparkles,
  Check,
  Moon,
  Sun,
  Plus,
  ArrowDownToLine,
  CheckCircle2
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { Visualizer } from './Visualizer';
import { CxLogo } from './CxLogo';
import { motion, AnimatePresence, PanInfo } from 'motion/react';
import { VinylTurntable } from './VinylTurntable';

export const NowPlayingModal: React.FC = () => {
  const {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    isShuffle,
    repeatMode,
    togglePlay,
    seek,
    setVolumeLevel,
    toggleMute,
    playNext,
    playPrevious,
    toggleShuffle,
    toggleRepeat,
    toggleLikeSong,
    likedSongIds,
    downloadSong,
    downloadedSongIds,
    isNowPlayingOpen,
    setIsNowPlayingOpen,
    audioVisualizerData,
    queue,
    queueIndex,
    playSong,
    sleepTimerSeconds,
    startSleepTimer,
    cancelSleepTimer,
    theme,
    toggleTheme
  } = useAudio();

  const [activeTab, setActiveTab] = useState<'cover' | 'lyrics' | 'queue'>('cover');
  const [eqPreset, setEqPreset] = useState<'normal' | 'bass' | 'vocal' | 'spatial'>('normal');
  const [copiedLink, setCopiedLink] = useState(false);
  const [showSleepMenu, setShowSleepMenu] = useState(false);

  if (!isNowPlayingOpen || !currentSong) return null;

  const isLiked = likedSongIds.has(currentSong.id);
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const formatSleepTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}m ${s < 10 ? '0' : ''}${s}s`;
  };

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleDragEnd = (_: any, info: PanInfo) => {
    if (info.offset.y > 120 || info.velocity.y > 500) {
      setIsNowPlayingOpen(false);
    }
  };

  const handleLyricClick = (idx: number) => {
    if (currentSong.lyrics && currentSong.lyrics.length > 0) {
      const targetTime = (idx / currentSong.lyrics.length) * duration;
      seek(targetTime);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 0.05, bottom: 0.6 }}
        onDragEnd={handleDragEnd}
        initial={{ opacity: 0, y: '100%' }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 220 }}
        className="fixed inset-0 z-50 bg-neutral-950/95 backdrop-blur-3xl flex flex-col justify-between overflow-hidden select-none text-white"
      >
        {/* Swipe Handle Indicator */}
        <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto mt-3 cursor-grab active:cursor-grabbing hover:bg-white/40 transition-colors" />

        {/* Dynamic Background Aura Glow */}
        <div className="absolute inset-0 pointer-events-none opacity-40 blur-[130px]">
          <div
            className="absolute -top-40 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-purple-600 via-pink-600 to-indigo-700 animate-pulse"
            style={{ animationDuration: '6s' }}
          />
        </div>

        {/* Top Header Controls */}
        <header className="relative z-10 flex items-center justify-between px-6 sm:px-8 py-4 max-w-5xl w-full mx-auto">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsNowPlayingOpen(false)}
              className="p-3 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white transition-all hover:scale-105"
              title="Swipe down or tap to close"
            >
              <ChevronDown className="w-6 h-6" />
            </button>
            <CxLogo size="sm" showText={false} className="hidden sm:flex" />
          </div>

          {/* Mode Tabs */}
          <div className="flex items-center gap-1 p-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
            <button
              onClick={() => setActiveTab('cover')}
              className={`px-4 sm:px-5 py-1.5 rounded-full text-xs font-semibold transition-all ${
                activeTab === 'cover'
                  ? 'bg-purple-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Cover
            </button>
            <button
              onClick={() => setActiveTab('lyrics')}
              className={`px-4 sm:px-5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'lyrics'
                  ? 'bg-purple-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Mic2 className="w-3.5 h-3.5" />
              <span>Lyrics</span>
            </button>
            <button
              onClick={() => setActiveTab('queue')}
              className={`px-4 sm:px-5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'queue'
                  ? 'bg-purple-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <ListMusic className="w-3.5 h-3.5" />
              <span>Queue</span>
            </button>
          </div>

          {/* Action Tools: Sleep Timer & Share */}
          <div className="flex items-center gap-2">
            {/* Sleep Timer Popover */}
            <div className="relative">
              <button
                onClick={() => setShowSleepMenu(!showSleepMenu)}
                className={`p-2.5 rounded-full border transition-all flex items-center gap-1.5 ${
                  sleepTimerSeconds !== null
                    ? 'bg-purple-600 text-white border-purple-400 shadow-[0_0_10px_rgba(168,85,247,0.5)]'
                    : 'bg-white/5 hover:bg-white/10 border-white/10 text-neutral-300 hover:text-white'
                }`}
                title="Sleep Timer"
              >
                <Clock className="w-4 h-4" />
                {sleepTimerSeconds !== null && (
                  <span className="text-[10px] font-mono font-bold">{formatSleepTime(sleepTimerSeconds)}</span>
                )}
              </button>

              <AnimatePresence>
                {showSleepMenu && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, y: 10 }}
                    className="absolute right-0 top-12 w-48 bg-neutral-900 border border-white/15 rounded-2xl shadow-2xl p-2 z-50 text-xs"
                  >
                    <div className="font-bold text-purple-400 uppercase text-[10px] tracking-wider px-2 py-1 border-b border-white/10 mb-1">
                      Sleep Timer
                    </div>
                    {[5, 15, 30, 45, 60].map((mins) => (
                      <button
                        key={mins}
                        onClick={() => {
                          startSleepTimer(mins);
                          setShowSleepMenu(false);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-xl text-neutral-300 hover:text-white hover:bg-white/10 flex items-center justify-between"
                      >
                        <span>{mins} minutes</span>
                        {sleepTimerSeconds === mins * 60 && <Check className="w-3.5 h-3.5 text-purple-400" />}
                      </button>
                    ))}
                    {sleepTimerSeconds !== null && (
                      <button
                        onClick={() => {
                          cancelSleepTimer();
                          setShowSleepMenu(false);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-xl text-rose-400 hover:bg-rose-500/20 mt-1 border-t border-white/10"
                      >
                        Turn off timer
                      </button>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Share */}
            <button
              onClick={handleShare}
              className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 hover:text-white transition-all relative"
              title="Share Track"
            >
              <Share2 className="w-4 h-4" />
              {copiedLink && (
                <span className="absolute top-12 right-0 text-[10px] bg-purple-600 text-white px-2 py-1 rounded-md shadow-lg whitespace-nowrap z-50">
                  Link Copied!
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Center Main Content Area */}
        <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 max-w-4xl w-full mx-auto my-auto py-2 overflow-y-auto custom-scrollbar">
          {activeTab === 'cover' && (
            <div className="flex flex-col items-center text-center my-auto">
              {/* Interactive Vinyl Record Turntable */}
              <div className="my-2 flex justify-center">
                <VinylTurntable size="lg" />
              </div>

              {/* Title & Artist */}
              <div className="mt-4 space-y-1 max-w-md">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight truncate">
                  {currentSong.title}
                </h1>
                <p className="text-base text-purple-300 font-medium truncate">
                  {currentSong.artist} • <span className="text-neutral-400">{currentSong.album}</span>
                </p>
              </div>

              {/* Equalizer FX Selector */}
              <div className="flex items-center justify-center gap-1.5 mt-3 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-neutral-300">
                <SlidersHorizontal className="w-3.5 h-3.5 text-purple-400" />
                {(['normal', 'bass', 'vocal'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setEqPreset(mode)}
                    className={`px-2.5 py-0.5 rounded-full capitalize text-[11px] font-medium transition-colors ${
                      eqPreset === mode
                        ? 'bg-purple-600 text-white'
                        : 'hover:text-white text-neutral-400'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'lyrics' && (
            <div className="w-full max-w-lg h-80 sm:h-96 overflow-y-auto px-4 space-y-6 text-center custom-scrollbar my-auto py-4">
              {currentSong.lyrics && currentSong.lyrics.length > 0 ? (
                currentSong.lyrics.map((line, idx) => {
                  const isActive = Math.floor((currentTime / duration) * currentSong.lyrics!.length) === idx;
                  return (
                    <motion.p
                      key={idx}
                      whileHover={{ scale: 1.05 }}
                      onClick={() => handleLyricClick(idx)}
                      className={`text-lg sm:text-2xl font-extrabold cursor-pointer transition-all duration-300 ${
                        isActive
                          ? 'text-purple-300 scale-105 drop-shadow-[0_0_15px_rgba(168,85,247,0.8)]'
                          : 'text-neutral-500 hover:text-neutral-300'
                      }`}
                    >
                      {line}
                    </motion.p>
                  );
                })
              ) : (
                <div className="text-neutral-500 py-16 text-sm">
                  No lyrics available for this track. Relax and enjoy the beats!
                </div>
              )}
            </div>
          )}

          {activeTab === 'queue' && (
            <div className="w-full max-w-lg h-80 sm:h-96 overflow-y-auto space-y-2 custom-scrollbar px-2 my-auto py-2">
              <div className="text-xs font-semibold text-purple-400 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>Up Next ({queue.length - queueIndex - 1})</span>
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              </div>
              {(queue || []).slice(queueIndex + 1).map((song, idx) => (
                <div
                  key={`${song.id}-${idx}`}
                  onClick={() => playSong(song, queue)}
                  className="flex items-center justify-between p-3 rounded-2xl bg-white/5 hover:bg-white/10 cursor-pointer border border-white/5 transition-colors group"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      className="w-10 h-10 rounded-xl object-cover flex-shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="font-bold text-sm text-white group-hover:text-purple-300 truncate">{song.title}</div>
                      <div className="text-xs text-neutral-400 truncate">{song.artist}</div>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-neutral-400 ml-2">{song.durationFormatted}</span>
                </div>
              ))}
            </div>
          )}
        </main>

        {/* Bottom Controls Bar */}
        <footer className="relative z-10 w-full max-w-2xl mx-auto px-6 pb-8 space-y-4">
          {/* Audio Visualizer Spectrum Bar */}
          <div className="flex justify-center">
            <Visualizer data={audioVisualizerData} isPlaying={isPlaying} barCount={28} height={26} />
          </div>

          {/* Timeline Seek */}
          <div className="space-y-1">
            <input
              type="range"
              min="0"
              max="100"
              value={progressPercent}
              onChange={(e) => seek((parseFloat(e.target.value) / 100) * duration)}
              className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
            />
            <div className="flex justify-between text-xs font-mono text-neutral-400">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Playback Action Buttons */}
          <div className="flex items-center justify-between">
            {/* Like */}
            <button
              onClick={() => toggleLikeSong(currentSong.id)}
              className={`p-2.5 rounded-full transition-transform ${
                isLiked ? 'text-rose-500 scale-110' : 'text-neutral-400 hover:text-white'
              }`}
              title={isLiked ? 'Unlike' : 'Like'}
            >
              <Heart className={`w-6 h-6 ${isLiked ? 'fill-rose-500' : ''}`} />
            </button>

            {/* Download */}
            <button
              onClick={() => downloadSong(currentSong)}
              className={`p-2.5 rounded-full transition-transform ${
                downloadedSongIds.has(currentSong.id)
                  ? 'text-emerald-400 scale-110'
                  : 'text-neutral-400 hover:text-purple-300'
              }`}
              title={downloadedSongIds.has(currentSong.id) ? 'Downloaded (Offline Ready)' : 'Download MP3 to device'}
            >
              {downloadedSongIds.has(currentSong.id) ? (
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
              ) : (
                <ArrowDownToLine className="w-6 h-6" />
              )}
            </button>

            {/* Shuffle */}
            <button
              onClick={toggleShuffle}
              className={`p-2 transition-colors ${
                isShuffle ? 'text-purple-400' : 'text-neutral-400 hover:text-white'
              }`}
              title="Shuffle"
            >
              <Shuffle className="w-5 h-5" />
            </button>

            {/* Previous */}
            <button
              onClick={playPrevious}
              className="p-2 text-white hover:scale-110 transition-transform active:scale-95"
              title="Previous"
            >
              <SkipBack className="w-7 h-7" />
            </button>

            {/* Play/Pause Main */}
            <button
              onClick={togglePlay}
              className="w-16 h-16 rounded-full bg-gradient-to-tr from-purple-500 via-indigo-500 to-pink-500 text-white flex items-center justify-center shadow-[0_0_30px_rgba(168,85,247,0.7)] hover:scale-105 active:scale-95 transition-all"
            >
              {isPlaying ? (
                <Pause className="w-7 h-7 fill-white" />
              ) : (
                <Play className="w-7 h-7 fill-white ml-1" />
              )}
            </button>

            {/* Next */}
            <button
              onClick={playNext}
              className="p-2 text-white hover:scale-110 transition-transform active:scale-95"
              title="Next"
            >
              <SkipForward className="w-7 h-7" />
            </button>

            {/* Repeat */}
            <button
              onClick={toggleRepeat}
              className={`p-2 transition-colors ${
                repeatMode !== 'off' ? 'text-purple-400' : 'text-neutral-400 hover:text-white'
              }`}
              title="Repeat"
            >
              {repeatMode === 'one' ? <Repeat1 className="w-5 h-5" /> : <Repeat className="w-5 h-5" />}
            </button>

            {/* Volume */}
            <div className="flex items-center gap-2">
              <button onClick={toggleMute} className="text-neutral-400 hover:text-white">
                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </footer>
      </motion.div>
    </AnimatePresence>
  );
};
