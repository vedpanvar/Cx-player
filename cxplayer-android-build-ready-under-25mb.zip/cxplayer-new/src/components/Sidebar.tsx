import React from 'react';
import {
  Disc,
  Music2,
  Compass,
  User,
  Folder,
  ListMusic,
  Heart,
  Sliders,
  Clock,
  Star,
  Activity,
  ArrowDownToLine
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { CxLogo } from './CxLogo';
import { ViewType } from '../types';

export const Sidebar: React.FC = () => {
  const {
    currentView,
    navigateTo,
    selectedEntityId,
    likedSongIds,
    allSongs,
    folders,
    currentSong,
    isPlaying,
    currentTime,
    duration
  } = useAudio();

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const navItems: { id: string; label: string; icon: React.FC<{ className?: string }>; view: ViewType; count?: number }[] = [
    { id: 'player', label: 'Player', icon: Disc, view: 'home' },
    { id: 'tracks', label: 'Tracks', icon: Music2, view: 'tracks', count: allSongs.length > 0 ? allSongs.length : 128 },
    { id: 'albums', label: 'Albums', icon: Compass, view: 'albums', count: 36 },
    { id: 'artists', label: 'Artists', icon: User, view: 'artists', count: 24 },
    { id: 'folders', label: 'Folders', icon: Folder, view: 'folders', count: folders.length > 0 ? folders.length : 12 },
    { id: 'playlists', label: 'Playlists', icon: ListMusic, view: 'playlists', count: 8 },
    { id: 'favorites', label: 'Favorites', icon: Heart, view: 'liked' },
    { id: 'equalizer', label: 'Equalizer', icon: Sliders, view: 'profile' },
  ];

  const libraryItems: { id: string; label: string; icon: React.FC<{ className?: string }>; view: ViewType }[] = [
    { id: 'recent', label: 'Recently Played', icon: Clock, view: 'recent' },
    { id: 'top-rated', label: 'Top Rated', icon: Star, view: 'top-rated' },
    { id: 'most-played', label: 'Most Played', icon: Activity, view: 'most-played' },
    { id: 'downloads', label: 'Downloads', icon: ArrowDownToLine, view: 'downloads' },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 bg-[#0a0b12]/95 backdrop-blur-2xl border-r border-white/[0.07] px-4 py-5 h-full select-none z-30 justify-between shrink-0 overflow-y-auto custom-scrollbar">
      <div className="space-y-6">
        
        {/* Brand Header */}
        <div className="px-2 pt-1">
          <div
            onClick={() => navigateTo('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <CxLogo size="md" showText={false} />
            <span className="font-extrabold text-xl tracking-tight text-white flex items-center">
              <span>Cx</span>
              <span className="text-neutral-200 font-normal">player</span>
            </span>
          </div>
        </div>

        {/* Primary Navigation Menu */}
        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isPlayerActive = (item.view === 'home' || item.view === 'player') && (currentView === 'home' || currentView === 'player' || currentView === 'turntable') && !selectedEntityId;
            const isActive = isPlayerActive || (currentView === item.view && !selectedEntityId);

            return (
              <button
                key={item.id}
                onClick={() => navigateTo(item.view)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all duration-200 cursor-pointer group ${
                  isActive
                    ? 'bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 text-white shadow-[0_0_24px_rgba(168,85,247,0.45)]'
                    : 'text-neutral-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 transition-colors ${
                    isActive 
                      ? 'text-white' 
                      : item.id === 'favorites' 
                      ? 'text-rose-400 group-hover:text-rose-300' 
                      : 'text-neutral-400 group-hover:text-white'
                  }`} />
                  <span className="text-[13.5px] font-medium">{item.label}</span>
                </div>

                {item.count !== undefined && (
                  <span className={`text-[11px] font-mono px-2 py-0.5 rounded-full transition-colors ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : 'bg-white/[0.05] text-neutral-400 group-hover:text-neutral-200'
                  }`}>
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* YOUR LIBRARY Section */}
        <div className="space-y-2 pt-2 border-t border-white/[0.06]">
          <div className="px-3 text-[11px] font-bold tracking-widest text-neutral-500 uppercase flex items-center gap-1.5">
            <span className="w-1 h-1 rounded-full bg-purple-500" />
            <span>YOUR LIBRARY</span>
          </div>

          <div className="space-y-0.5">
            {libraryItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.view;

              return (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.view)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-[13px] font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30'
                      : 'text-neutral-400 hover:text-white hover:bg-white/[0.04]'
                  }`}
                >
                  <Icon className="w-4 h-4 text-neutral-400 group-hover:text-white" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

      </div>

      {/* CURRENTLY PLAYING Mini Card (Bottom of Sidebar) */}
      {currentSong && (
        <div className="mt-4 pt-3 border-t border-white/[0.06]">
          <div className="text-[10px] font-bold tracking-wider uppercase text-neutral-500 mb-2 px-1">
            CURRENTLY PLAYING
          </div>
          
          <div 
            onClick={() => navigateTo('home')}
            className="p-2.5 rounded-2xl bg-white/[0.03] border border-white/[0.07] hover:border-purple-500/30 transition-all cursor-pointer flex items-center gap-3 group"
          >
            {/* Spinning Vinyl Cover */}
            <div className="relative w-11 h-11 rounded-full bg-neutral-900 border-2 border-white/20 overflow-hidden flex-shrink-0 flex items-center justify-center shadow-lg">
              <img
                src={currentSong.coverUrl}
                alt={currentSong.title}
                className={`w-full h-full object-cover transition-transform duration-500 ${isPlaying ? 'animate-spin-slow' : ''}`}
                style={{ animationDuration: '8s' }}
              />
              <div className="absolute w-3 h-3 rounded-full bg-neutral-950 border border-white/40 shadow-inner" />
            </div>

            {/* Track Info */}
            <div className="min-w-0 flex-1">
              <div className="font-bold text-xs text-white truncate group-hover:text-purple-300 transition-colors">
                {currentSong.title}
              </div>
              <div className="text-[11px] text-neutral-400 truncate">
                {currentSong.artist}
              </div>
              
              {/* Mini Spectrum & Time */}
              <div className="flex items-center gap-2 mt-1">
                <div className="flex items-end gap-0.5 h-2.5">
                  <span className={`w-0.5 bg-purple-400 rounded-full ${isPlaying ? 'h-full animate-pulse' : 'h-1'}`} />
                  <span className={`w-0.5 bg-purple-400 rounded-full ${isPlaying ? 'h-2/3 animate-pulse delay-75' : 'h-1.5'}`} />
                  <span className={`w-0.5 bg-purple-400 rounded-full ${isPlaying ? 'h-full animate-pulse delay-150' : 'h-2'}`} />
                </div>
                <span className="text-[10px] font-mono text-neutral-400">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </span>
              </div>
            </div>

          </div>
        </div>
      )}
    </aside>
  );
};
