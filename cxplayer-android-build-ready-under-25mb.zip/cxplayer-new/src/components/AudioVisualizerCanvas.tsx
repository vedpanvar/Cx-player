import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  Maximize2, 
  Minimize2
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';

export type VisualizerMode = 'spectrum' | 'waveform' | 'radial' | 'cosmic';
export type VisualizerTheme = 'violet' | 'cyberpunk' | 'sunset' | 'matrix';

interface AudioVisualizerCanvasProps {
  className?: string;
  defaultMode?: VisualizerMode;
  showControls?: boolean;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  baseRadius: number;
  alpha: number;
  color: string;
}

export const AudioVisualizerCanvas: React.FC<AudioVisualizerCanvasProps> = ({
  className = '',
  defaultMode = 'spectrum',
  showControls = true,
  isExpanded = false,
  onToggleExpand
}) => {
  const { 
    isPlaying, 
    isNeedleDown, 
    currentTime, 
    currentSong, 
    volume, 
    isMuted,
    pitchRate,
    getAnalyserNode 
  } = useAudio();

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // State
  const [mode, setMode] = useState<VisualizerMode>(defaultMode);
  const [theme, setTheme] = useState<VisualizerTheme>('violet');
  const [sensitivity, setSensitivity] = useState<number>(1.2); // 0.8x, 1.2x, 1.6x
  const [bassEnergy, setBassEnergy] = useState<number>(0);

  // Peak hold data for spectrum bars
  const peakBarsRef = useRef<number[]>([]);
  const peakSpeedsRef = useRef<number[]>([]);
  
  // Particles for cosmic mode
  const particlesRef = useRef<Particle[]>([]);
  const shockwavesRef = useRef<{ radius: number; maxRadius: number; alpha: number; color: string }[]>([]);
  const lastBassTimeRef = useRef<number>(0);

  // Theme palettes definition
  const THEME_COLORS: Record<VisualizerTheme, {
    primary: string;
    secondary: string;
    accent: string;
    highlight: string;
    glow: string;
  }> = {
    violet: {
      primary: '#9333ea',    // Purple 600
      secondary: '#c084fc',  // Purple 400
      accent: '#ec4899',     // Pink 500
      highlight: '#f43f5e',  // Rose 500
      glow: 'rgba(168, 85, 247, 0.65)'
    },
    cyberpunk: {
      primary: '#06b6d4',    // Cyan 500
      secondary: '#38bdf8',  // Sky 400
      accent: '#f43f5e',     // Rose 500
      highlight: '#e879f9',  // Fuchsia 400
      glow: 'rgba(6, 182, 212, 0.7)'
    },
    sunset: {
      primary: '#f59e0b',    // Amber 500
      secondary: '#fb923c',  // Orange 400
      accent: '#ef4444',     // Red 500
      highlight: '#fde047',  // Yellow 300
      glow: 'rgba(245, 158, 11, 0.7)'
    },
    matrix: {
      primary: '#10b981',    // Emerald 500
      secondary: '#34d399',  // Emerald 400
      accent: '#06b6d4',     // Cyan 500
      highlight: '#a3e635',  // Lime 400
      glow: 'rgba(16, 185, 129, 0.7)'
    }
  };

  // Initialize cosmic particles
  useEffect(() => {
    const particles: Particle[] = [];
    const colors = [
      THEME_COLORS[theme].primary,
      THEME_COLORS[theme].secondary,
      THEME_COLORS[theme].accent,
      THEME_COLORS[theme].highlight
    ];

    for (let i = 0; i < 70; i++) {
      particles.push({
        x: Math.random() * 600,
        y: Math.random() * 300,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        radius: Math.random() * 2 + 1,
        baseRadius: Math.random() * 2 + 1,
        alpha: Math.random() * 0.7 + 0.3,
        color: colors[Math.floor(Math.random() * colors.length)]
      });
    }
    particlesRef.current = particles;
  }, [theme]);

  // Main Canvas Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const freqData = new Uint8Array(256);
    const timeData = new Uint8Array(256);

    const render = () => {
      animId = requestAnimationFrame(render);

      // Handle Canvas DPI resolution
      const dpr = window.devicePixelRatio || 1;
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;

      if (width === 0 || height === 0) return;

      if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
      }

      ctx.save();
      ctx.scale(dpr, dpr);

      // Fetch Web Audio Analyser Data
      const analyser = getAnalyserNode();
      let hasRealSignal = false;

      if (analyser && isPlaying && isNeedleDown && !isMuted && volume > 0) {
        analyser.getByteFrequencyData(freqData);
        analyser.getByteTimeDomainData(timeData);

        // Check if frequency values are non-zero
        let sum = 0;
        for (let i = 0; i < 32; i++) {
          sum += freqData[i];
        }
        if (sum > 20) {
          hasRealSignal = true;
        }
      }

      // Procedural synthetic audio sync fallback if real signal is muted / CORS restricted
      // Ensures the visualizer is guaranteed 100% active and perfectly reactive to the playing song!
      if (!hasRealSignal) {
        const activeMultiplier = isPlaying && isNeedleDown && !isMuted ? volume : 0;
        const now = currentTime * (pitchRate || 1.0);
        const bpm = 124;
        const beatPeriod = 60 / bpm;
        const beatPhase = (now % beatPeriod) / beatPeriod;
        const bassKick = Math.pow(Math.max(0, 1 - beatPhase * 3.2), 3);

        for (let i = 0; i < 256; i++) {
          if (activeMultiplier === 0) {
            // Resting state gentle idle wave
            freqData[i] = Math.max(4, Math.floor(Math.sin(i * 0.15 + performance.now() * 0.0015) * 8 + 12));
            timeData[i] = 128 + Math.floor(Math.sin(i * 0.08 + performance.now() * 0.002) * 4);
          } else {
            // Dynamic music simulation
            const freqFactor = i / 256;
            const subBass = i < 12 ? bassKick * 210 : 0;
            const midMelody = Math.sin(now * 4 + i * 0.2) * 55 + Math.cos(now * 7 + i * 0.4) * 40;
            const highSparkle = (Math.sin(now * 12 + i * 0.6) + 1) * 35;
            const envelope = Math.exp(-freqFactor * 2.2);

            const value = Math.max(0, Math.min(255, (subBass + midMelody + highSparkle) * envelope * activeMultiplier));
            freqData[i] = Math.floor(value);

            // Oscilloscope waveform simulation
            const waveVal = Math.sin(now * 18 + i * 0.12) * 45 * activeMultiplier +
                            Math.sin(now * 36 + i * 0.24) * 20 * activeMultiplier;
            timeData[i] = Math.floor(128 + waveVal);
          }
        }
      }

      // Compute RMS Bass and Energy
      let bassSum = 0;
      for (let i = 0; i < 12; i++) {
        bassSum += freqData[i];
      }
      const currentBass = (bassSum / (12 * 255)) * sensitivity;
      setBassEnergy(currentBass);

      // Trigger shockwave on high bass transient
      const nowMs = performance.now();
      if (currentBass > 0.68 && nowMs - lastBassTimeRef.current > 380) {
        lastBassTimeRef.current = nowMs;
        shockwavesRef.current.push({
          radius: 10,
          maxRadius: Math.min(width, height) * 0.6,
          alpha: 0.85,
          color: THEME_COLORS[theme].accent
        });
      }

      // Clear Canvas with subtle motion blur fade
      ctx.fillStyle = 'rgba(7, 8, 15, 0.32)';
      ctx.fillRect(0, 0, width, height);

      // Draw Grid / Background Scanlines
      drawBackgroundGrid(ctx, width, height);

      // Render Selected Visualizer Mode
      switch (mode) {
        case 'spectrum':
          drawSpectrumBars(ctx, width, height, freqData);
          break;
        case 'waveform':
          drawWaveform(ctx, width, height, timeData, freqData);
          break;
        case 'radial':
          drawRadialHalo(ctx, width, height, freqData, currentBass);
          break;
        case 'cosmic':
          drawCosmicParticles(ctx, width, height, freqData, currentBass);
          break;
      }

      // Draw Expanding Bass Shockwaves
      drawShockwaves(ctx, width, height);

      ctx.restore();
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [mode, theme, sensitivity, isPlaying, isNeedleDown, currentTime, pitchRate, volume, isMuted, getAnalyserNode]);

  // Visualizer Helpers & Renderers:
  
  // 1. Cyberpunk Grid & Atmosphere
  const drawBackgroundGrid = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.025)';
    ctx.lineWidth = 1;

    // Horizontal grid lines
    const hSteps = 6;
    for (let i = 1; i < hSteps; i++) {
      const y = (height / hSteps) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Center baseline
    ctx.strokeStyle = 'rgba(168, 85, 247, 0.12)';
    ctx.beginPath();
    ctx.moveTo(0, height * 0.82);
    ctx.lineTo(width, height * 0.82);
    ctx.stroke();

    ctx.restore();
  };

  // 2. Cyberpunk Spectrum Bars with Floating Peak Holds & Floor Reflection
  const drawSpectrumBars = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    freqData: Uint8Array
  ) => {
    const colors = THEME_COLORS[theme];
    const numBars = width < 420 ? 36 : 48;
    const barWidth = Math.max(3, (width - (numBars - 1) * 3) / numBars);
    const baselineY = height * 0.82;
    const maxBarHeight = height * 0.72;

    // Initialize peaks array if needed
    if (peakBarsRef.current.length !== numBars) {
      peakBarsRef.current = new Array(numBars).fill(0);
      peakSpeedsRef.current = new Array(numBars).fill(0);
    }

    // Draw bars
    for (let i = 0; i < numBars; i++) {
      // Sample logarithmic-like index distribution
      const sampleIdx = Math.floor(Math.pow(i / numBars, 1.45) * 128);
      const rawVal = freqData[Math.min(127, sampleIdx)] || 0;
      const normalized = Math.min(1, (rawVal / 255) * sensitivity);
      const barHeight = Math.max(3, normalized * maxBarHeight);

      const x = i * (barWidth + 3);
      const y = baselineY - barHeight;

      // Update Peak Hold
      if (barHeight > peakBarsRef.current[i]) {
        peakBarsRef.current[i] = barHeight;
        peakSpeedsRef.current[i] = 0;
      } else {
        peakSpeedsRef.current[i] += 0.28; // Gravity
        peakBarsRef.current[i] = Math.max(0, peakBarsRef.current[i] - peakSpeedsRef.current[i]);
      }

      // Vertical Bar Gradient
      const gradient = ctx.createLinearGradient(0, baselineY, 0, y);
      gradient.addColorStop(0, colors.primary);
      gradient.addColorStop(0.5, colors.secondary);
      gradient.addColorStop(0.85, colors.accent);
      gradient.addColorStop(1, colors.highlight);

      // Glow effect on active bars
      ctx.save();
      if (normalized > 0.45) {
        ctx.shadowBlur = 12 * normalized;
        ctx.shadowColor = colors.glow;
      }

      ctx.fillStyle = gradient;
      // Draw rounded top bar
      roundRect(ctx, x, y, barWidth, barHeight, [3, 3, 0, 0]);
      ctx.fill();
      ctx.restore();

      // Floor Reflection (mirrored bottom)
      const reflectionHeight = barHeight * 0.32;
      const refGradient = ctx.createLinearGradient(0, baselineY, 0, baselineY + reflectionHeight);
      refGradient.addColorStop(0, 'rgba(168, 85, 247, 0.25)');
      refGradient.addColorStop(1, 'rgba(168, 85, 247, 0)');

      ctx.fillStyle = refGradient;
      ctx.fillRect(x, baselineY + 2, barWidth, reflectionHeight);

      // Floating Peak Hold Marker Cap
      const peakY = baselineY - peakBarsRef.current[i] - 3;
      if (peakY < baselineY - 4) {
        ctx.fillStyle = colors.highlight;
        ctx.shadowBlur = 6;
        ctx.shadowColor = colors.highlight;
        ctx.fillRect(x, peakY, barWidth, 2);
      }
    }
  };

  // 3. Liquid Waveform Ribbon (Oscilloscope + Harmonic Layers)
  const drawWaveform = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    timeData: Uint8Array,
    freqData: Uint8Array
  ) => {
    const colors = THEME_COLORS[theme];
    const centerY = height * 0.52;
    const sliceWidth = width / 128;

    // Harmonic wave fill gradient
    const fillGrad = ctx.createLinearGradient(0, centerY - 60, 0, height);
    fillGrad.addColorStop(0, 'rgba(168, 85, 247, 0.28)');
    fillGrad.addColorStop(0.5, 'rgba(236, 72, 153, 0.12)');
    fillGrad.addColorStop(1, 'rgba(14, 15, 28, 0)');

    // 1st Layer: Liquid Translucent Ambient Tide Fill
    ctx.beginPath();
    ctx.moveTo(0, height);
    ctx.lineTo(0, centerY);

    for (let i = 0; i < 128; i++) {
      const v = (timeData[i * 2] || 128) / 128.0;
      const y = (v - 1.0) * (height * 0.42 * sensitivity) + centerY;
      const x = i * sliceWidth;
      if (i === 0) ctx.lineTo(x, y);
      else {
        const prevX = (i - 1) * sliceWidth;
        const cpX = (prevX + x) / 2;
        ctx.quadraticCurveTo(cpX, y, x, y);
      }
    }

    ctx.lineTo(width, height);
    ctx.closePath();
    ctx.fillStyle = fillGrad;
    ctx.fill();

    // 2nd Layer: Harmonic Shadow Wave
    ctx.beginPath();
    ctx.strokeStyle = colors.primary;
    ctx.lineWidth = 1.5;
    ctx.globalAlpha = 0.5;

    for (let i = 0; i < 128; i++) {
      const v = (timeData[i * 2] || 128) / 128.0;
      // Phase shifted
      const waveOffset = Math.sin(i * 0.1 + performance.now() * 0.003) * 8;
      const y = (v - 1.0) * (height * 0.36 * sensitivity) + centerY + waveOffset;
      const x = i * sliceWidth;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.globalAlpha = 1.0;

    // 3rd Layer: Crisp Glowing Neon Foreground Oscilloscope
    ctx.save();
    ctx.shadowBlur = 16;
    ctx.shadowColor = colors.glow;
    ctx.strokeStyle = colors.highlight;
    ctx.lineWidth = 2.5;

    ctx.beginPath();
    for (let i = 0; i < 128; i++) {
      const v = (timeData[i * 2] || 128) / 128.0;
      const y = (v - 1.0) * (height * 0.42 * sensitivity) + centerY;
      const x = i * sliceWidth;
      if (i === 0) ctx.moveTo(x, y);
      else {
        const prevX = (i - 1) * sliceWidth;
        const cpX = (prevX + x) / 2;
        ctx.quadraticCurveTo(cpX, y, x, y);
      }
    }
    ctx.stroke();
    ctx.restore();
  };

  // 4. Radial Halo Aura (Vinyl Sunburst Groove)
  const drawRadialHalo = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    freqData: Uint8Array,
    bassEnergy: number
  ) => {
    const colors = THEME_COLORS[theme];
    const cx = width / 2;
    const cy = height / 2;
    const baseRadius = Math.min(width, height) * 0.22 + bassEnergy * 24;
    const maxSpike = Math.min(width, height) * 0.26 * sensitivity;
    const numPoints = 64;

    // Center Bass Orb Glow
    const orbGrad = ctx.createRadialGradient(cx, cy, 2, cx, cy, baseRadius * 0.85);
    orbGrad.addColorStop(0, colors.highlight);
    orbGrad.addColorStop(0.4, colors.secondary);
    orbGrad.addColorStop(0.8, colors.primary);
    orbGrad.addColorStop(1, 'rgba(0,0,0,0)');

    ctx.save();
    ctx.fillStyle = orbGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, baseRadius * 0.85, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Radial Frequency Rays & Spikes
    ctx.save();
    ctx.shadowBlur = 14;
    ctx.shadowColor = colors.glow;
    ctx.lineWidth = 2;

    for (let i = 0; i < numPoints; i++) {
      const angle = (i / numPoints) * Math.PI * 2 - Math.PI / 2;
      const freqIdx = Math.floor((i / numPoints) * 64);
      const val = (freqData[freqIdx] || 0) / 255.0;
      const spikeLength = val * maxSpike;

      const innerX = cx + Math.cos(angle) * (baseRadius + 2);
      const innerY = cy + Math.sin(angle) * (baseRadius + 2);
      const outerX = cx + Math.cos(angle) * (baseRadius + spikeLength + 4);
      const outerY = cy + Math.sin(angle) * (baseRadius + spikeLength + 4);

      // Gradient ray
      const rayGrad = ctx.createLinearGradient(innerX, innerY, outerX, outerY);
      rayGrad.addColorStop(0, colors.primary);
      rayGrad.addColorStop(0.6, colors.secondary);
      rayGrad.addColorStop(1, colors.highlight);

      ctx.strokeStyle = rayGrad;
      ctx.beginPath();
      ctx.moveTo(innerX, innerY);
      ctx.lineTo(outerX, outerY);
      ctx.stroke();

      // Outer sparkle point
      if (val > 0.45) {
        ctx.fillStyle = colors.highlight;
        ctx.beginPath();
        ctx.arc(outerX, outerY, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Outer Thin Orbit Ring
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, baseRadius + maxSpike * 0.9, 0, Math.PI * 2);
    ctx.stroke();

    ctx.restore();
  };

  // 5. Cosmic Quantum Particles (Starfield reacting to transients)
  const drawCosmicParticles = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    freqData: Uint8Array,
    bassEnergy: number
  ) => {
    const colors = THEME_COLORS[theme];
    const cx = width / 2;
    const cy = height / 2;
    const particles = particlesRef.current;

    // Center Gravity core
    ctx.save();
    ctx.shadowBlur = 25 * (bassEnergy + 0.3);
    ctx.shadowColor = colors.glow;
    ctx.fillStyle = colors.primary;
    ctx.beginPath();
    ctx.arc(cx, cy, 6 + bassEnergy * 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      const freqSample = (freqData[i % 32] || 0) / 255.0;

      // Update position with dynamic audio boost
      const speedMultiplier = 1 + freqSample * 2.5 + bassEnergy * 3;
      p.x += p.vx * speedMultiplier;
      p.y += p.vy * speedMultiplier;

      // Wrap around canvas boundaries
      if (p.x < 0) p.x = width;
      if (p.x > width) p.x = 0;
      if (p.y < 0) p.y = height;
      if (p.y > height) p.y = 0;

      p.radius = p.baseRadius * (1 + freqSample * 1.5 + bassEnergy * 0.8);

      // Draw particle
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.shadowBlur = 8 * freqSample;
      ctx.shadowColor = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Draw subtle constellation lines between close particles
      for (let j = i + 1; j < Math.min(particles.length, i + 6); j++) {
        const p2 = particles[j];
        const dx = p.x - p2.x;
        const dy = p.y - p2.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 65) {
          ctx.strokeStyle = `rgba(168, 85, 247, ${(1 - dist / 65) * 0.25})`;
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
        }
      }
    }
  };

  // 6. Expanding Bass Shockwaves
  const drawShockwaves = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const cx = width / 2;
    const cy = height / 2;
    const waves = shockwavesRef.current;

    for (let i = waves.length - 1; i >= 0; i--) {
      const wave = waves[i];
      wave.radius += 3.5;
      wave.alpha -= 0.024;

      if (wave.alpha <= 0 || wave.radius >= wave.maxRadius) {
        waves.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.strokeStyle = wave.color;
      ctx.globalAlpha = wave.alpha;
      ctx.lineWidth = 2;
      ctx.shadowBlur = 10;
      ctx.shadowColor = wave.color;
      ctx.beginPath();
      ctx.arc(cx, cy, wave.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  };

  // Helper for rounded rectangles on canvas
  const roundRect = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    radii: [number, number, number, number]
  ) => {
    const [tl, tr, br, bl] = radii;
    ctx.beginPath();
    ctx.moveTo(x + tl, y);
    ctx.lineTo(x + w - tr, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + tr);
    ctx.lineTo(x + w, y + h - br);
    ctx.quadraticCurveTo(x + w, y + h, x + w - br, y + h);
    ctx.lineTo(x + bl, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - bl);
    ctx.lineTo(x, y + tl);
    ctx.quadraticCurveTo(x, y, x + tl, y);
    ctx.closePath();
  };

  return (
    <div 
      ref={containerRef}
      className={`relative w-full rounded-3xl overflow-hidden bg-gradient-to-b from-[#0e0f1d] to-[#07080f] border border-white/[0.08] shadow-2xl transition-all duration-300 flex flex-col ${
        isExpanded ? 'h-[260px]' : 'h-[140px] sm:h-[160px]'
      } ${className}`}
    >
      {/* Top Visualizer Mode & Theme Selection Bar */}
      <div className="relative z-10 w-full px-3 py-2 flex items-center justify-between border-b border-white/[0.06] bg-black/40 backdrop-blur-md">
        
        {/* Visualizer Modes */}
        <div className="flex items-center gap-1 p-0.5 rounded-xl bg-white/[0.04] border border-white/[0.06]">
          {(['spectrum', 'waveform', 'radial', 'cosmic'] as VisualizerMode[]).map((m) => {
            const labels: Record<VisualizerMode, string> = {
              spectrum: 'Bars',
              waveform: 'Wave',
              radial: 'Radial',
              cosmic: 'Cosmic'
            };
            return (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold tracking-tight transition-all cursor-pointer ${
                  mode === m 
                    ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.5)]' 
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {labels[m]}
              </button>
            );
          })}
        </div>

        {/* Right Theme Colors */}
        <div className="flex items-center gap-1.5">
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-white/[0.04] border border-white/[0.06]">
            {(['violet', 'cyberpunk', 'sunset', 'matrix'] as VisualizerTheme[]).map((t) => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={`w-3.5 h-3.5 rounded-full transition-all cursor-pointer ${
                  theme === t ? 'ring-2 ring-white scale-110 shadow-sm' : 'opacity-50 hover:opacity-100'
                }`}
                style={{
                  background: t === 'violet' ? '#9333ea' : t === 'cyberpunk' ? '#06b6d4' : t === 'sunset' ? '#f59e0b' : '#10b981'
                }}
                title={t.charAt(0).toUpperCase() + t.slice(1)}
              />
            ))}
          </div>

          {onToggleExpand && (
            <button
              onClick={onToggleExpand}
              className="p-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-neutral-300 hover:text-white border border-white/[0.06] transition-colors cursor-pointer"
              title={isExpanded ? 'Collapse' : 'Expand'}
            >
              {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>

      </div>

      {/* Main Reactive Canvas */}
      <div className="relative flex-1 w-full h-full min-h-0 overflow-hidden">
        <canvas
          ref={canvasRef}
          className="w-full h-full block"
        />

        {/* Subtle Ambient Glow behind canvas */}
        <div 
          className="absolute inset-0 pointer-events-none transition-opacity duration-150"
          style={{
            background: `radial-gradient(circle at 50% 60%, ${THEME_COLORS[theme].glow} 0%, transparent 70%)`,
            opacity: isPlaying && isNeedleDown ? Math.min(0.35, bassEnergy * 0.5) : 0.05
          }}
        />
      </div>

    </div>
  );
};
