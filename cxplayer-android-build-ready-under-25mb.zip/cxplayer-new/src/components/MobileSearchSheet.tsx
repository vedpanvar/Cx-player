import React, { useState } from 'react';
import { Search, X, Play, Pause, Disc3 } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { motion, AnimatePresence } from 'motion/react';
import { MiniPlayerBar } from './MiniPlayerBar';

interface MobileSearchSheetProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileSearchSheet: React.FC<MobileSearchSheetProps> = ({ isOpen, onClose }) => {
  const { allSongs, playSong, currentSong, isPlaying, togglePlay } = useAudio();
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const results = allSongs.filter(
    (s) =>
      s.title.toLowerCase().includes(query.toLowerCase()) ||
      s.artist.toLowerCase().includes(query.toLowerCase()) ||
      s.genre.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end justify-center bg-neutral-900/25 backdrop-blur-md">
        <div className="absolute inset-0" onClick={onClose} />

        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 28, stiffness: 250 }}
          className="relative z-10 w-full max-w-lg bg-[#f6f6fa]/95 backdrop-blur-2xl border-t border-white rounded-t-[30px] p-4 sm:p-5 pb-[max(1rem,env(safe-area-inset-bottom))] shadow-[0_-16px_48px_rgba(15,23,42,0.16)] flex flex-col max-h-[86dvh] select-none"
        >
          <div className="w-10 h-1 rounded-full bg-neutral-300 mx-auto mb-3" />

          <div className="flex items-center justify-between pb-3 border-b border-black/[0.06] mb-3">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-orange-600" />
              <h2 className="font-semibold text-base text-neutral-900">Search Music</h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="min-w-[40px] min-h-[40px] flex items-center justify-center text-neutral-600 hover:text-neutral-900 rounded-full bg-white border border-black/[0.06] shadow-sm cursor-pointer"
              aria-label="Close Search"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="relative mb-3">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <input
              autoFocus
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by song, artist, or genre..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/85 border border-black/[0.08] text-neutral-900 text-sm placeholder-neutral-400 focus:outline-none focus:border-orange-500"
            />
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar space-y-1.5">
            {results.length === 0 ? (
              <div className="text-center py-10 text-neutral-500 text-xs">
                No tracks found matching "{query}"
              </div>
            ) : (
              results.map((song) => {
                const isCurrent = song.id === currentSong?.id;
                return (
                  <div
                    key={song.id}
                    onClick={() => {
                      if (isCurrent) {
                        togglePlay();
                      } else {
                        playSong(song, allSongs);
                      }
                    }}
                    className={`flex items-center justify-between p-2.5 rounded-2xl transition-colors cursor-pointer group ${
                      isCurrent
                        ? 'bg-white border border-orange-500/35 shadow-sm'
                        : 'border border-transparent hover:bg-white/75'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="w-11 h-11 rounded-xl overflow-hidden border border-black/[0.06] bg-neutral-200 shrink-0 flex items-center justify-center">
                        {song.coverUrl ? (
                          <img
                            src={song.coverUrl}
                            alt={song.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Disc3 className="w-4 h-4 text-neutral-500" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="font-semibold text-sm text-neutral-900 truncate">
                          {song.title}
                        </div>
                        <div className="text-xs text-neutral-500 truncate mt-0.5">
                          {song.artist} · {song.genre}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 shrink-0">
                      <span className="text-xs tabular-nums text-neutral-500">
                        {song.durationFormatted}
                      </span>
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                          isCurrent
                            ? 'bg-orange-600 text-white'
                            : 'bg-black/[0.05] group-hover:bg-orange-600 text-neutral-700 group-hover:text-white'
                        }`}
                      >
                        {isCurrent && isPlaying ? (
                          <Pause className="w-3.5 h-3.5 fill-current" />
                        ) : (
                          <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <MiniPlayerBar onExpandPlayer={onClose} />
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
