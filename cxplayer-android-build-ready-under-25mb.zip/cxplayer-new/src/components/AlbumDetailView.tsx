import React from 'react';
import { motion } from 'motion/react';
import {
  Play,
  ArrowLeft
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { MOCK_SONGS, MOCK_ALBUMS } from '../data/mockData';
import { SongRow } from './SongRow';

export const AlbumDetailView: React.FC = () => {
  const {
    selectedEntityId,
    playSong,
    navigateTo
  } = useAudio();

  const album = MOCK_ALBUMS.find((a) => a.id === selectedEntityId);

  if (!album) {
    return (
      <div className="text-center py-20 text-neutral-400">
        Album not found.
        <button
          onClick={() => navigateTo('tracks')}
          className="block mx-auto mt-4 px-4 py-2 bg-purple-600 text-white rounded-full text-xs font-bold"
        >
          Back to Tracks
        </button>
      </div>
    );
  }

  const title = album.title;
  const description = `${album.genre} • ${album.year}`;
  const coverUrl = album.coverUrl;
  const songIds = album.songIds;

  const albumSongs = MOCK_SONGS.filter((s) => songIds.includes(s.id));
  const totalDuration = albumSongs.reduce((acc, s) => acc + s.duration, 0);

  const formatTotalTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    return `${mins} mins`;
  };

  const handlePlayAll = () => {
    if (albumSongs.length > 0) {
      playSong(albumSongs[0], albumSongs);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.2 }}
      className="space-y-8 pb-12"
    >
      {/* Back button */}
      <button
        onClick={() => navigateTo('tracks')}
        className="flex items-center gap-2 text-xs font-semibold text-neutral-400 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Tracks</span>
      </button>

      {/* Album Header */}
      <div className="flex flex-col md:flex-row items-center md:items-end gap-6 sm:gap-8 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-purple-900/40 via-indigo-950/60 to-neutral-950 border border-purple-500/20 shadow-2xl">
        <img
          src={coverUrl}
          alt={title}
          className="w-44 h-44 sm:w-52 sm:h-52 rounded-2xl object-cover border-2 border-white/20 shadow-2xl flex-shrink-0"
        />

        <div className="space-y-3 text-center md:text-left flex-1 min-w-0">
          <span className="text-xs font-bold uppercase tracking-wider text-purple-400">
            Album
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight truncate">
            {title}
          </h1>
          <p className="text-sm text-neutral-300 max-w-xl">{description}</p>

          <div className="flex items-center justify-center md:justify-start gap-2 text-xs text-neutral-400">
            <span>{albumSongs.length} tracks</span>
            <span>•</span>
            <span>{formatTotalTime(totalDuration)}</span>
          </div>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 pt-2">
            {albumSongs.length > 0 && (
              <button
                onClick={handlePlayAll}
                className="flex items-center gap-2 px-7 py-3 rounded-full bg-gradient-to-r from-purple-500 via-indigo-500 to-pink-500 text-white font-bold text-sm shadow-[0_0_20px_rgba(168,85,247,0.5)] hover:scale-105 transition-all"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Play Album</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Song List */}
      <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-2 sm:p-3 divide-y divide-white/5">
        {albumSongs.length === 0 ? (
          <div className="text-center py-12 text-neutral-500 text-xs">
            No tracks in this album.
          </div>
        ) : (
          albumSongs.map((song, i) => (
            <SongRow
              key={song.id}
              song={song}
              index={i}
              songList={albumSongs}
            />
          ))
        )}
      </div>
    </motion.div>
  );
};
