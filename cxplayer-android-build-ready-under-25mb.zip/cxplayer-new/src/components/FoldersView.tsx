import React, { useState } from 'react';
import { 
  Folder, 
  FolderOpen, 
  Play, 
  Shuffle, 
  Music, 
  ChevronRight, 
  HardDrive, 
  ArrowLeft,
  Smartphone,
  Plus
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { AudioFolder, Song } from '../types';
import { PhoneFileScanner } from './PhoneFileScanner';

export const FoldersView: React.FC = () => {
  const { folders, playSong, currentSong, isPlaying, likedSongIds, toggleLikeSong } = useAudio();
  const [selectedFolder, setSelectedFolder] = useState<AudioFolder | null>(null);

  const handlePlayFolder = (folder: AudioFolder) => {
    if (folder.songs.length > 0) {
      playSong(folder.songs[0], folder.songs);
    }
  };

  const handleShuffleFolder = (folder: AudioFolder) => {
    if (folder.songs.length > 0) {
      const shuffled = [...folder.songs].sort(() => Math.random() - 0.5);
      playSong(shuffled[0], shuffled);
    }
  };

  if (selectedFolder) {
    return (
      <div className="space-y-6 pb-24 animate-in fade-in duration-300">
        {/* Back Button & Folder Header */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSelectedFolder(null)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 text-xs font-semibold transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Folders</span>
          </button>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <FolderOpen className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {selectedFolder.name}
              </h1>
              <p className="text-xs text-neutral-400">
                {selectedFolder.songs.length} track(s)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => handlePlayFolder(selectedFolder)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-purple-600/30 active:scale-95 transition-all cursor-pointer"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Play All</span>
            </button>
            <button
              onClick={() => handleShuffleFolder(selectedFolder)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-white/5 hover:bg-white/10 text-white font-semibold text-xs sm:text-sm border border-white/10 active:scale-95 transition-all cursor-pointer"
            >
              <Shuffle className="w-4 h-4 text-purple-400" />
              <span>Shuffle</span>
            </button>
          </div>
        </div>

        {/* Songs in selected folder */}
        <div className="rounded-3xl bg-white/[0.02] border border-white/5 p-2 sm:p-4 divide-y divide-white/5">
          {selectedFolder.songs.map((song, idx) => {
            const isCurrent = currentSong?.id === song.id;
            const isLiked = likedSongIds.has(song.id);

            return (
              <div
                key={song.id}
                className={`group flex items-center justify-between py-3 px-3 sm:px-4 rounded-2xl hover:bg-white/[0.06] transition-all ${
                  isCurrent ? 'bg-purple-600/15 border border-purple-500/30' : ''
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <span className="font-mono text-xs text-neutral-500 w-5 text-center flex-shrink-0">
                    {idx + 1}
                  </span>

                  <div
                    onClick={() => playSong(song, selectedFolder.songs)}
                    className="relative w-10 h-10 rounded-xl overflow-hidden flex-shrink-0 cursor-pointer shadow group/img"
                  >
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover/img:opacity-100 transition-opacity">
                      <Play className="w-4 h-4 fill-white text-white" />
                    </div>
                  </div>

                  <div className="min-w-0 flex-1">
                    <div
                      onClick={() => playSong(song, selectedFolder.songs)}
                      className={`font-bold text-sm truncate cursor-pointer hover:text-purple-300 ${
                        isCurrent ? 'text-purple-300' : 'text-white'
                      }`}
                    >
                      {song.title}
                    </div>
                    <div className="text-xs text-neutral-400 truncate">
                      {song.artist}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => toggleLikeSong(song.id)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      isLiked ? 'text-rose-500' : 'text-neutral-500 hover:text-white'
                    }`}
                  >
                    <Music className="w-3.5 h-3.5" />
                  </button>
                  <span className="font-mono text-xs text-neutral-400">
                    {song.durationFormatted}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Header */}
      <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-white/10">
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Folders
        </h1>
        <p className="text-xs text-neutral-400 mt-1">
          {folders.length} folder(s) found
        </p>
      </div>

      <PhoneFileScanner />

      {/* Folders Grid */}
      {folders.length === 0 ? (
        <div className="rounded-3xl bg-white/[0.02] border border-white/5 p-12 text-center text-neutral-400 space-y-3">
          <Folder className="w-12 h-12 mx-auto text-purple-400/40" />
          <div className="text-base font-bold text-white">No Audio Folders Found</div>
          <p className="text-xs text-neutral-400 max-w-sm mx-auto">
            Use the scanner above or select folder access to organize tracks by directory.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {folders.map((folder) => (
            <div
              key={folder.id}
              onClick={() => setSelectedFolder(folder)}
              className="group relative flex items-center justify-between p-5 rounded-3xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 hover:border-purple-500/40 cursor-pointer transition-all duration-300 shadow-lg"
            >
              <div className="flex items-center gap-4 min-w-0">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600/30 to-indigo-600/30 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-105 group-hover:bg-purple-600/40 transition-all flex-shrink-0">
                  <Folder className="w-7 h-7" />
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-base text-white group-hover:text-purple-300 transition-colors truncate">
                    {folder.name}
                  </div>
                  <div className="text-xs text-neutral-400 mt-1 flex items-center gap-1.5">
                    <Music className="w-3.5 h-3.5 text-purple-400" />
                    <span>{folder.songCount} track(s)</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePlayFolder(folder);
                  }}
                  className="w-9 h-9 rounded-full bg-purple-600/20 hover:bg-purple-600 text-purple-300 hover:text-white border border-purple-500/30 flex items-center justify-center transition-all opacity-0 group-hover:opacity-100"
                  title="Play Entire Folder"
                >
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                </button>
                <ChevronRight className="w-5 h-5 text-neutral-500 group-hover:text-purple-300 transition-colors" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
