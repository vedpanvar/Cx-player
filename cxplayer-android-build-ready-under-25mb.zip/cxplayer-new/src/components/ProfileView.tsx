import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  Sliders, Headphones, Sparkles, 
  Heart, Music, CheckCircle2, Award, 
  Radio, Zap
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';

export const ProfileView: React.FC = () => {
  const { likedSongIds, allSongs, navigateTo } = useAudio();
  const [audioQuality, setAudioQuality] = useState<'lossless' | 'high' | 'normal'>('lossless');
  const [equalizerPreset, setEqualizerPreset] = useState('Bass Boost');
  const [crossfade, setCrossfade] = useState(3); // seconds

  const likedSongs = useMemo(() => {
    return allSongs.filter(s => likedSongIds.has(s.id));
  }, [allSongs, likedSongIds]);

  const uniqueArtists = useMemo(() => {
    const artistMap = new Map<string, number>();
    allSongs.forEach(song => {
      const art = song.artist || 'Unknown Artist';
      artistMap.set(art, (artistMap.get(art) || 0) + 1);
    });
    return Array.from(artistMap.entries()).map(([name, count]) => ({
      name,
      count
    }));
  }, [allSongs]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="space-y-8 pb-24"
    >
      {/* Audio Studio Header Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-purple-900/60 via-indigo-900/40 to-neutral-900 p-6 sm:p-8 border border-white/10 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col sm:flex-row items-center sm:items-center gap-6 z-10 relative">
          <div className="relative group">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-emerald-500 p-0.5 shadow-2xl relative flex items-center justify-center">
              <div className="w-full h-full bg-neutral-950 rounded-[22px] flex items-center justify-center text-purple-400 group-hover:scale-95 transition-transform">
                <Sliders className="w-12 h-12" />
              </div>
            </div>
          </div>

          <div className="flex-1 text-center sm:text-left space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold tracking-wide">
              <Zap className="w-3.5 h-3.5 text-emerald-400" /> CXPLAYER HI-FI AUDIO ENGINE
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Audio Studio & Settings
            </h1>
            <p className="text-neutral-300 text-xs sm:text-sm max-w-xl leading-relaxed">
              Configure equalizer profiles, audio bitrates, crossfade intervals, and view storage statistics.
            </p>
          </div>

          <div className="flex sm:flex-col gap-2 w-full sm:w-auto">
            <button 
              onClick={() => navigateTo('tracks')}
              className="flex-1 sm:flex-initial px-5 py-2.5 rounded-full bg-white text-neutral-950 hover:bg-neutral-200 font-bold text-xs sm:text-sm transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <Music className="w-4 h-4" /> Open Tracks
            </button>
          </div>
        </div>
      </div>

      {/* Stats & Engine Status Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 sm:p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-purple-500/30 transition-all group">
          <div className="flex items-center justify-between mb-2">
            <span className="text-neutral-400 text-xs font-medium">Audio Engine</span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 group-hover:bg-purple-500 group-hover:text-white transition-all">
              <Radio className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white">24-Bit / 192kHz</div>
          <div className="text-xs text-emerald-400 mt-1 font-medium flex items-center gap-1">
            <Zap className="w-3 h-3" /> Hi-Fi FLAC Enabled
          </div>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-purple-500/30 transition-all group">
          <div className="flex items-center justify-between mb-2">
            <span className="text-neutral-400 text-xs font-medium">Favorites</span>
            <div className="p-2 rounded-xl bg-pink-500/10 text-pink-400 group-hover:bg-pink-500 group-hover:text-white transition-all">
              <Heart className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-white">{likedSongs.length}</div>
          <div className="text-xs text-neutral-400 mt-1">Favorite tracks saved</div>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-purple-500/30 transition-all group">
          <div className="flex items-center justify-between mb-2">
            <span className="text-neutral-400 text-xs font-medium">Total Tracks</span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 group-hover:bg-indigo-500 group-hover:text-white transition-all">
              <Music className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-white">{allSongs.length}</div>
          <div className="text-xs text-neutral-400 mt-1">Available in library</div>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-purple-500/30 transition-all group">
          <div className="flex items-center justify-between mb-2">
            <span className="text-neutral-400 text-xs font-medium">Active Preset</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-all">
              <Sliders className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white truncate">{equalizerPreset}</div>
          <div className="text-xs text-purple-400 mt-1 font-medium">Acoustic Optimized</div>
        </div>
      </div>

      {/* Audio & Playback Preferences */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-6 rounded-3xl bg-neutral-900/70 border border-white/10 space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-purple-500/20 text-purple-400">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Playback & Audio Quality</h2>
              <p className="text-xs text-neutral-400">Configure spatial sound and bitrate</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-neutral-300 mb-2 block">Audio Bitrate</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'lossless', label: 'FLAC Lossless', sub: '24-bit/192kHz' },
                  { id: 'high', label: 'High Quality', sub: '320 kbps AAC' },
                  { id: 'normal', label: 'Standard', sub: '160 kbps' }
                ].map((q) => (
                  <button
                    key={q.id}
                    onClick={() => setAudioQuality(q.id as any)}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                      audioQuality === q.id
                        ? 'bg-purple-600/20 border-purple-500 text-white shadow-lg'
                        : 'bg-white/5 border-white/10 text-neutral-400 hover:border-white/20'
                    }`}
                  >
                    <div className="text-xs font-bold text-white flex items-center justify-between">
                      {q.label}
                      {audioQuality === q.id && <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />}
                    </div>
                    <div className="text-[10px] text-neutral-400 mt-0.5">{q.sub}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2">
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-semibold text-neutral-300">Crossfade Gapless Transition</label>
                <span className="text-xs text-purple-400 font-bold">{crossfade}s</span>
              </div>
              <input
                type="range"
                min="0"
                max="12"
                value={crossfade}
                onChange={(e) => setCrossfade(Number(e.target.value))}
                className="w-full accent-purple-500 bg-neutral-800 h-2 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Equalizer & Sound Profile */}
        <div className="p-6 rounded-3xl bg-neutral-900/70 border border-white/10 space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-500/20 text-indigo-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Equalizer Presets</h2>
              <p className="text-xs text-neutral-400">Tailor frequency response for your headphones</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {['Bass Boost', 'Acoustic', 'Club', 'Vocal Enhancement', 'Electronic Hi-Fi', 'Flat Studio'].map((preset) => (
              <button
                key={preset}
                onClick={() => setEqualizerPreset(preset)}
                className={`px-3.5 py-2 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                  equalizerPreset === preset
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                    : 'bg-white/5 border-white/10 text-neutral-400 hover:bg-white/10 hover:text-white'
                }`}
              >
                {preset}
              </button>
            ))}
          </div>

          {/* Equalizer Frequency Graphic Representation */}
          <div className="p-4 rounded-2xl bg-black/40 border border-white/5 flex items-end justify-between h-28 gap-2 pt-6">
            {[40, 65, 80, 50, 35, 70, 90, 85, 60, 45, 75, 95].map((val, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                <div 
                  className="w-full rounded-t-sm bg-gradient-to-t from-purple-600 to-indigo-400 transition-all duration-300" 
                  style={{ height: `${val}%` }} 
                />
                <span className="text-[9px] text-neutral-500 font-mono">
                  {i === 0 ? '60' : i === 4 ? '1k' : i === 8 ? '6k' : i === 11 ? '16k' : ''}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Library Artists Summary */}
      {uniqueArtists.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-400" /> Library Artists ({uniqueArtists.length})
            </h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {uniqueArtists.map((artist) => (
              <div
                key={artist.name}
                className="p-4 rounded-2xl bg-neutral-900/60 border border-white/5 hover:border-purple-500/30 hover:bg-neutral-800/80 transition-all text-center group"
              >
                <div className="w-16 h-16 mx-auto rounded-full bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-3 group-hover:scale-105 transition-transform">
                  <Music className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors truncate">
                  {artist.name}
                </h3>
                <p className="text-[11px] text-neutral-400 mt-0.5 truncate">
                  {artist.count} track(s)
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
};
