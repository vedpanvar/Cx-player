import React, { useState } from 'react';
import { 
  Sliders, 
  RotateCcw,
  Check,
  Disc
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';

const PRESETS = [
  'Flat',
  'Bass Boost',
  'Vocal',
  'Rock',
  'Pop',
  'Electronic',
  'Jazz',
  'Classical'
];

export const EqualizerView: React.FC = () => {
  const { equalizerPreset, setEqualizerPreset, pitchRate, setPitchRate } = useAudio();

  const [bands, setBands] = useState<number[]>([4, 6, 2, 5, 7]);
  const [bass, setBass] = useState<number>(60);
  const [treble, setTreble] = useState<number>(50);

  const bandFrequencies = ['60 Hz', '230 Hz', '910 Hz', '3.6 kHz', '14 kHz'];

  const handleBandChange = (index: number, val: number) => {
    setBands((prev) => {
      const next = [...prev];
      next[index] = val;
      return next;
    });
  };

  const handleReset = () => {
    setBands([0, 0, 0, 0, 0]);
    setBass(50);
    setTreble(50);
    setEqualizerPreset('Flat');
  };

  const applyPreset = (preset: string) => {
    setEqualizerPreset(preset);
    switch (preset) {
      case 'Bass Boost':
        setBands([8, 6, 2, 2, 3]);
        setBass(85);
        break;
      case 'Vocal':
        setBands([2, 5, 7, 6, 4]);
        setBass(50);
        break;
      case 'Rock':
        setBands([6, 4, -1, 5, 7]);
        setBass(70);
        break;
      case 'Jazz':
        setBands([4, 3, 2, 3, 3]);
        setBass(55);
        break;
      case 'Electronic':
        setBands([7, 5, 1, 5, 8]);
        setBass(80);
        break;
      default:
        setBands([0, 0, 0, 0, 0]);
        setBass(50);
        break;
    }
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex items-center justify-between p-5 rounded-2xl bg-neutral-900/80 border border-white/10">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Equalizer
          </h1>
          <p className="text-xs text-neutral-400 mt-0.5">
            Adjust sound frequencies and playback presets
          </p>
        </div>

        <button
          onClick={handleReset}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 text-xs transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Main Equalizer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Bands */}
        <div className="lg:col-span-2 p-5 sm:p-6 rounded-2xl bg-neutral-900/60 border border-white/10 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm text-white">Frequency Bands</h3>
            <span className="text-xs font-mono text-purple-300">
              {equalizerPreset}
            </span>
          </div>

          {/* Sliders */}
          <div className="grid grid-cols-5 gap-2 py-4 px-2 bg-black/20 rounded-xl border border-white/5">
            {bandFrequencies.map((freq, index) => {
              const val = bands[index] || 0;
              return (
                <div key={freq} className="flex flex-col items-center gap-3">
                  <span className="text-xs font-mono text-purple-300">
                    {val > 0 ? `+${val}` : val}dB
                  </span>

                  <div className="h-40 flex items-center justify-center">
                    <input
                      type="range"
                      min="-12"
                      max="12"
                      step="1"
                      value={val}
                      onChange={(e) => handleBandChange(index, parseInt(e.target.value, 10))}
                      className="w-36 h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer -rotate-90 accent-purple-500"
                    />
                  </div>

                  <span className="text-[11px] font-mono text-neutral-400 text-center">
                    {freq}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Bass & Treble */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3.5 rounded-xl bg-black/20 border border-white/5 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-neutral-300 font-medium">Bass</span>
                <span className="font-mono text-purple-300">{bass}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={bass}
                onChange={(e) => setBass(parseInt(e.target.value, 10))}
                className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-purple-500"
              />
            </div>

            <div className="p-3.5 rounded-xl bg-black/20 border border-white/5 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-neutral-300 font-medium">Treble</span>
                <span className="font-mono text-purple-300">{treble}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={treble}
                onChange={(e) => setTreble(parseInt(e.target.value, 10))}
                className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-purple-500"
              />
            </div>
          </div>
        </div>

        {/* Presets & Speed */}
        <div className="space-y-4">
          <div className="p-5 rounded-2xl bg-neutral-900/60 border border-white/10 space-y-3">
            <h3 className="font-semibold text-sm text-white">Presets</h3>

            <div className="space-y-1.5 max-h-64 overflow-y-auto custom-scrollbar pr-1">
              {PRESETS.map((p) => {
                const isSelected = equalizerPreset === p;
                return (
                  <button
                    key={p}
                    onClick={() => applyPreset(p)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-purple-600 text-white'
                        : 'bg-white/5 text-neutral-300 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <span>{p}</span>
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-neutral-900/60 border border-white/10 space-y-3">
            <h3 className="font-semibold text-sm text-white">Playback Speed</h3>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-neutral-400">Speed:</span>
                <span className="font-mono text-purple-300 font-medium">
                  {pitchRate.toFixed(2)}x
                </span>
              </div>

              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.05"
                value={pitchRate}
                onChange={(e) => setPitchRate(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-purple-500"
              />

              <div className="flex items-center justify-between text-[10px] text-neutral-400 font-mono">
                <span>0.5x</span>
                <span>1.0x</span>
                <span>2.0x</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
