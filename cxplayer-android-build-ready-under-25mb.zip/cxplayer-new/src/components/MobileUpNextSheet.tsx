import React, { useState } from 'react';
import {
  X,
  Play,
  Pause,
  Heart,
  Search,
  Disc3
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { motion, AnimatePresence } from 'motion/react';
import { PhoneFileScanner } from './PhoneFileScanner';
import { MiniPlayerBar } from './MiniPlayerBar';

interface MobileUpNextSheetProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileUpNextSheet: React.FC<MobileUpNextSheetProps> = ({ isOpen, onClose }) => {
  const {
    queue,
    queueIndex,
    currentSong,
    isPlaying,
    playSong,
    removeFromQueue,
    clearQueue,
    togglePlay,
    allSongs,
    likedSongIds,
    toggleLikeSong
  } = useAudio();

  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'liked' | 'queue'>('all');

  if (!isOpen) return null;

  const currentTrack = currentSong || (queue ? queue[queueIndex] : undefined);
  const likedSongs = allSongs.filter((s) => likedSongIds.has(s.id));

  const activeList =
    activeTab === 'liked'
      ? likedSongs
      : activeTab === 'queue'
      ? queue.length > 0
        ? queue
        : allSongs
      : allSongs;

  const filteredList = activeList.filter(
    (s) =>
      s.title.toLowerCase().includes(search.toLowerCase()) ||
      s.artist.toLowerCase().includes(search.toLowerCase()) ||
      s.album.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end justify-center bg-neutral-900/25 backdrop-blur-md">
        <div className="absolute inset-0" onClick={onClose} />

        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 28, stiffness: 250 }}
          className="relative z-10 w-full max-w-lg bg-[#f6f6fa]/95 backdrop-blur-2xl border-t border-white rounded-t-[30px] p-4 sm:p-5 pb-[max(1rem,env(safe-area-inset-bottom))] shadow-[0_-16px_48px_rgba(15,23,42,0.16)] flex flex-col max-h-[86dvh] select-none"
        >
          <div className="w-10 h-1 rounded-full bg-neutral-300 mx-auto mb-3.5" />

          {/* Header & Segmented Tabs */}
          <div className="flex items-center justify-between pb-3 border-b border-black/[0.06] gap-2">
            <div className="flex items-center gap-1 p-1 rounded-xl bg-black/[0.04] border border-black/[0.05] overflow-x-auto">
              <button
                type="button"
                onClick={() => setActiveTab('all')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  activeTab === 'all'
                    ? 'bg-orange-600 text-white shadow-sm'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                Tracks ({allSongs.length})
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('liked')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  activeTab === 'liked'
                    ? 'bg-orange-600 text-white shadow-sm'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                Liked ({likedSongs.length})
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('queue')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  activeTab === 'queue'
                    ? 'bg-orange-600 text-white shadow-sm'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                Up Next ({queue.length})
              </button>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {queue.length > 1 && activeTab === 'queue' && (
                <button
                  type="button"
                  onClick={clearQueue}
                  className="px-2.5 py-1.5 rounded-xl bg-black/[0.05] hover:bg-rose-500/15 text-neutral-600 hover:text-rose-600 text-xs font-medium transition-colors cursor-pointer"
                >
                  Clear
                </button>
              )}

              <button
                type="button"
                onClick={onClose}
                className="min-w-[40px] min-h-[40px] flex items-center justify-center text-neutral-600 hover:text-neutral-900 rounded-full bg-white border border-black/[0.06] shadow-sm transition-colors cursor-pointer"
                aria-label="Close Music Library"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Search Input + Add Audio */}
          <div className="my-3 flex items-center gap-2">
            <div className="relative flex-1 min-w-0">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search tracks or artists..."
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/80 border border-black/[0.08] text-neutral-900 text-xs placeholder-neutral-400 focus:outline-none focus:border-orange-500"
              />
            </div>

            <PhoneFileScanner compact />
          </div>

          {/* Track List */}
          <div className="flex-1 overflow-y-auto custom-scrollbar space-y-1 pr-1 py-1">
            {filteredList.length === 0 ? (
              <div className="text-center py-10 text-neutral-500 text-xs">
                {activeTab === 'liked' && !search
                  ? 'Tap the heart on any track to save it here'
                  : `No tracks matching "${search}"`}
              </div>
            ) : (
              filteredList.map((song, idx) => {
                const isCurrent = song.id === currentTrack?.id;
                const isLiked = likedSongIds.has(song.id);

                return (
                  <div
                    key={`${song.id}-${idx}`}
                    onClick={() => {
                      if (isCurrent) {
                        togglePlay();
                      } else {
                        playSong(song, activeList);
                      }
                    }}
                    className={`group flex items-center justify-between p-2 rounded-2xl transition-colors cursor-pointer ${
                      isCurrent
                        ? 'bg-white border border-orange-500/35 shadow-sm'
                        : 'border border-transparent hover:bg-white/70'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="w-10 h-10 rounded-xl overflow-hidden border border-black/[0.06] bg-neutral-200 shrink-0 flex items-center justify-center">
                        {song.coverUrl ? (
                          <img
                            src={song.coverUrl}
                            alt={song.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <Disc3 className="w-4 h-4 text-neutral-500" />
                        )}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="font-semibold text-sm text-neutral-900 truncate">
                          {song.title}
                        </div>
                        <div className="text-xs text-neutral-500 truncate mt-0.5">
                          {song.artist}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleLikeSong(song.id);
                        }}
                        className={`min-w-[36px] min-h-[36px] flex items-center justify-center rounded-full transition-colors cursor-pointer ${
                          isLiked ? 'text-orange-600' : 'text-neutral-400 hover:text-neutral-700'
                        }`}
                        aria-label={isLiked ? `Unlike ${song.title}` : `Like ${song.title}`}
                      >
                        <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-orange-600' : ''}`} />
                      </button>

                      <span className="text-[11px] tabular-nums text-neutral-500 hidden sm:inline">
                        {song.durationFormatted}
                      </span>

                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          isCurrent
                            ? 'bg-orange-600 text-white'
                            : 'bg-black/[0.05] text-neutral-700'
                        }`}
                      >
                        {isCurrent && isPlaying ? (
                          <Pause className="w-3.5 h-3.5 fill-current" />
                        ) : (
                          <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                        )}
                      </div>

                      {activeTab === 'queue' && !isCurrent && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeFromQueue(idx);
                          }}
                          className="p-1.5 text-neutral-400 hover:text-rose-600 transition-colors cursor-pointer"
                          aria-label={`Remove ${song.title} from queue`}
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <MiniPlayerBar onExpandPlayer={onClose} />
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
