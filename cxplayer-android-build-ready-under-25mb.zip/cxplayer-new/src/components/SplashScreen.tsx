import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CxLogo } from './CxLogo';

export const SplashScreen: React.FC = () => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 1200);

    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.5, ease: 'easeInOut' }}
          className="fixed inset-0 z-50 bg-neutral-950 flex flex-col items-center justify-center select-none overflow-hidden"
        >
          {/* Ambient Background Aura */}
          <div className="absolute inset-0 pointer-events-none opacity-50 blur-[120px]">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 animate-pulse" />
          </div>

          {/* Logo Container */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', damping: 20, stiffness: 200 }}
            className="relative z-10 flex flex-col items-center gap-4"
          >
            <CxLogo size="xl" showText={true} />
            <div className="flex items-center gap-2 mt-2">
              <div className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-ping" />
              <span className="text-xs font-semibold text-purple-300 tracking-widest uppercase">
                High Fidelity Sound
              </span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
