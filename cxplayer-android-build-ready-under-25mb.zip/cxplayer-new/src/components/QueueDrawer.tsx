import React from 'react';
import { X, Trash2, Play, Pause, Music, Sparkles } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { motion, AnimatePresence } from 'motion/react';

export const QueueDrawer: React.FC = () => {
  const {
    isQueueOpen,
    setIsQueueOpen,
    queue,
    queueIndex,
    currentSong,
    isPlaying,
    playSong,
    removeFromQueue,
    clearQueue,
    togglePlay
  } = useAudio();

  if (!isQueueOpen) return null;

  const currentTrack = currentSong || (queue ? queue[queueIndex] : undefined);
  const upNextTracks = (queue || []).slice(queueIndex + 1);

  return (
    <AnimatePresence>
      <motion.aside
        initial={{ x: '100%', opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: '100%', opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="fixed top-0 right-0 bottom-24 w-80 sm:w-96 bg-neutral-950/95 backdrop-blur-2xl border-l border-white/10 z-30 flex flex-col p-5 shadow-2xl select-none"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
          <div className="flex items-center gap-2">
            <Music className="w-5 h-5 text-purple-400" />
            <h2 className="font-bold text-lg text-white">Play Queue</h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-semibold">
              {queue.length} tracks
            </span>
          </div>
          <div className="flex items-center gap-2">
            {queue.length > 1 && (
              <button
                onClick={clearQueue}
                className="p-1.5 text-neutral-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors text-xs flex items-center gap-1"
                title="Clear queue"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
            <button
              onClick={() => setIsQueueOpen(false)}
              className="p-1.5 text-neutral-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Now Playing Section */}
        {currentTrack && (
          <div className="mb-6">
            <div className="text-xs font-semibold uppercase tracking-wider text-purple-400 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Now Playing</span>
            </div>
            <div className="flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-purple-900/40 to-indigo-900/30 border border-purple-500/30 shadow-lg">
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={currentTrack.coverUrl}
                  alt={currentTrack.title}
                  className="w-12 h-12 rounded-xl object-cover border border-white/10 flex-shrink-0"
                />
                <div className="min-w-0">
                  <div className="font-bold text-sm text-white truncate">
                    {currentTrack.title}
                  </div>
                  <div className="text-xs text-purple-300 truncate">
                    {currentTrack.artist}
                  </div>
                </div>
              </div>

              <button
                onClick={togglePlay}
                className="p-2.5 rounded-full bg-purple-500 text-white shadow-md hover:scale-105 transition-transform flex-shrink-0 ml-2"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
              </button>
            </div>
          </div>
        )}

        {/* Up Next List */}
        <div className="flex-1 overflow-y-auto custom-scrollbar space-y-1">
          <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2 px-1">
            Up Next ({upNextTracks.length})
          </div>

          {upNextTracks.length === 0 ? (
            <div className="text-center py-10 text-neutral-500 text-xs">
              No upcoming tracks in queue. Add songs from Search or Library!
            </div>
          ) : (
            upNextTracks.map((song, idx) => {
              const actualQueueIndex = queueIndex + 1 + idx;

              return (
                <div
                  key={`${song.id}-${idx}`}
                  className="group flex items-center justify-between p-2 rounded-xl hover:bg-white/[0.06] transition-colors"
                >
                  <div
                    onClick={() => playSong(song, queue)}
                    className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                  >
                    <span className="text-xs text-neutral-500 w-4 text-center font-mono">
                      {idx + 1}
                    </span>
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      className="w-10 h-10 rounded-lg object-cover border border-white/10 flex-shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-xs text-neutral-200 group-hover:text-white truncate">
                        {song.title}
                      </div>
                      <div className="text-[11px] text-neutral-400 truncate">
                        {song.artist}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-neutral-500 font-mono">
                      {song.durationFormatted}
                    </span>
                    <button
                      onClick={() => removeFromQueue(actualQueueIndex)}
                      className="p-1 text-neutral-500 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Remove from queue"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </motion.aside>
    </AnimatePresence>
  );
};
