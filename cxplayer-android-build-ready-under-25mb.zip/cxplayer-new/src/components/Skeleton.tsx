import React from 'react';

export const Skeleton: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div
      className={`animate-pulse bg-white/10 rounded-2xl ${className}`}
    />
  );
};

export const SongRowSkeleton: React.FC = () => {
  return (
    <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.02] border border-white/5 my-1">
      <div className="flex items-center gap-3.5 flex-1 min-w-0">
        <Skeleton className="w-12 h-12 rounded-xl flex-shrink-0" />
        <div className="space-y-2 flex-1">
          <Skeleton className="h-4 w-1/3 rounded-md" />
          <Skeleton className="h-3 w-1/4 rounded-md" />
        </div>
      </div>
      <div className="flex items-center gap-4">
        <Skeleton className="w-5 h-5 rounded-full" />
        <Skeleton className="w-8 h-3 rounded-md" />
      </div>
    </div>
  );
};

export const CardSkeleton: React.FC = () => {
  return (
    <div className="p-4 rounded-3xl bg-white/[0.03] border border-white/5 space-y-3">
      <Skeleton className="w-full aspect-square rounded-2xl" />
      <Skeleton className="h-4 w-3/4 rounded-md" />
      <Skeleton className="h-3 w-1/2 rounded-md" />
    </div>
  );
};
