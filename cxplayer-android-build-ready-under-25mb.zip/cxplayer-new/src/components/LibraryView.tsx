import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import {
  Heart,
  Music,
  Grid,
  List,
  Folder,
  User,
  Disc
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { SongRow } from './SongRow';

export const LibraryView: React.FC = () => {
  const {
    libraryTab,
    setLibraryTab,
    likedSongIds,
    allSongs,
    folders,
    navigateTo
  } = useAudio();

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');

  const likedSongs = useMemo(() => {
    return allSongs.filter((s) => likedSongIds.has(s.id));
  }, [allSongs, likedSongIds]);

  const uniqueArtists = useMemo(() => {
    const artistMap = new Map<string, { name: string; count: number }>();
    allSongs.forEach((song) => {
      const art = song.artist || 'Unknown Artist';
      if (!artistMap.has(art)) {
        artistMap.set(art, { name: art, count: 0 });
      }
      artistMap.get(art)!.count += 1;
    });
    return Array.from(artistMap.values());
  }, [allSongs]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.2 }}
      className="space-y-6 pb-24"
    >
      {/* Header & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Your Music</span>
          </h1>
          <p className="text-xs text-neutral-400 mt-1">Browse your tracks, favorites, and folders.</p>
        </div>

        <div className="flex items-center gap-3">
          {/* View Mode Toggle */}
          <div className="bg-white/5 p-1 rounded-xl border border-white/10 flex items-center gap-1">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'grid' ? 'bg-purple-600 text-white' : 'text-neutral-400 hover:text-white'
              }`}
              title="Grid View"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'list' ? 'bg-purple-600 text-white' : 'text-neutral-400 hover:text-white'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Tabs Row */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 custom-scrollbar">
        {[
          { id: 'songs' as const, label: 'All Tracks', icon: Music, count: allSongs.length },
          { id: 'liked' as const, label: 'Favorites', icon: Heart, count: likedSongs.length },
          { id: 'folders' as const, label: 'Folders', icon: Folder, count: folders.length },
          { id: 'artists' as const, label: 'Artists', icon: User, count: uniqueArtists.length }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = (libraryTab as string) === tab.id || (tab.id === 'songs' && (libraryTab as string) === 'playlists');

          return (
            <button
              key={tab.id}
              onClick={() => setLibraryTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_15px_rgba(168,85,247,0.4)]'
                  : 'bg-white/5 text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              <span className="px-1.5 py-0.2 rounded-full bg-black/30 text-[10px]">
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* 1. All Songs Tab */}
      {((libraryTab as string) === 'songs' || (libraryTab as string) === 'playlists') && (
        <div className="space-y-4">
          {allSongs.length === 0 ? (
            <div className="text-center py-16 text-neutral-400 space-y-2">
              <Music className="w-10 h-10 mx-auto text-neutral-600" />
              <p className="text-sm font-semibold text-white">No tracks in library</p>
              <p className="text-xs text-neutral-500">Add tracks from your phone storage to start listening.</p>
            </div>
          ) : (
            <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-2 sm:p-3 divide-y divide-white/5">
              {allSongs.map((song, i) => (
                <SongRow key={song.id} song={song} index={i} songList={allSongs} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. Liked Songs Tab */}
      {libraryTab === 'liked' && (
        <div className="space-y-4">
          {likedSongs.length === 0 ? (
            <div className="text-center py-16 text-neutral-400 space-y-2">
              <Heart className="w-10 h-10 mx-auto text-rose-500/40" />
              <p className="text-sm font-semibold text-white">No favorites saved yet</p>
              <p className="text-xs text-neutral-500">Tap the heart icon on any song to save it here.</p>
            </div>
          ) : (
            <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-2 sm:p-3 divide-y divide-white/5">
              {likedSongs.map((song, i) => (
                <SongRow key={song.id} song={song} index={i} songList={likedSongs} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* 3. Folders Tab */}
      {libraryTab === 'folders' && (
        <div className="space-y-4">
          {folders.length === 0 ? (
            <div className="text-center py-16 text-neutral-400 space-y-2">
              <Folder className="w-10 h-10 mx-auto text-neutral-600" />
              <p className="text-sm font-semibold text-white">No folders found</p>
              <p className="text-xs text-neutral-500">Import music folders using the Folders view.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {folders.map((f) => (
                <div
                  key={f.id}
                  onClick={() => navigateTo('folders')}
                  className="p-5 rounded-3xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 hover:border-purple-500/40 cursor-pointer transition-all flex items-center gap-4"
                >
                  <div className="w-12 h-12 rounded-2xl bg-purple-600/20 text-purple-400 flex items-center justify-center flex-shrink-0">
                    <Folder className="w-6 h-6" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-bold text-sm text-white truncate">{f.name}</div>
                    <div className="text-xs text-neutral-400">{f.songCount} track(s)</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 4. Artists Tab */}
      {libraryTab === 'artists' && (
        <div className="space-y-4">
          {uniqueArtists.length === 0 ? (
            <div className="text-center py-16 text-neutral-400 space-y-2">
              <User className="w-10 h-10 mx-auto text-neutral-600" />
              <p className="text-sm font-semibold text-white">No artists found</p>
              <p className="text-xs text-neutral-500">Tracks will be categorized by artist once imported.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {uniqueArtists.map((artist) => (
                <div
                  key={artist.name}
                  className="group p-4 rounded-2xl bg-white/[0.02] hover:bg-white/[0.06] border border-white/5 text-center transition-all"
                >
                  <div className="w-16 h-16 rounded-full bg-purple-600/20 text-purple-400 flex items-center justify-center mx-auto mb-2">
                    <Music className="w-6 h-6" />
                  </div>
                  <div className="font-bold text-xs text-white truncate">{artist.name}</div>
                  <div className="text-[10px] text-neutral-400 mt-0.5">{artist.count} track(s)</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
};
