import React from 'react';
import { Play, Pause, SkipForward, Disc3 } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { useChromaTheme } from '../utils/themeColors';

interface MiniPlayerBarProps {
  onExpandPlayer?: () => void;
}

export const MiniPlayerBar: React.FC<MiniPlayerBarProps> = ({ onExpandPlayer }) => {
  const {
    currentSong,
    isPlaying,
    togglePlay,
    playNext,
    currentTime,
    duration
  } = useAudio();

  const theme = useChromaTheme(currentSong?.id, currentSong?.coverUrl);

  if (!currentSong) return null;

  const effectiveDuration = duration > 0 ? duration : currentSong.duration || 1;
  const pct = Math.min(100, Math.max(0, (currentTime / effectiveDuration) * 100));

  return (
    <div className="mt-3 rounded-2xl bg-white/85 border border-white shadow-[0_8px_24px_rgba(15,23,42,0.08)] overflow-hidden">
      <div className="w-full h-[2.5px] bg-neutral-200">
        <div
          className="h-full transition-[width] duration-150"
          style={{ width: `${pct}%`, background: theme.scrubberGradient }}
        />
      </div>

      <div className="flex items-center justify-between gap-3 px-3 py-2">
        <button
          type="button"
          onClick={onExpandPlayer}
          className="flex items-center gap-2.5 min-w-0 flex-1 text-left cursor-pointer"
        >
          <div className="w-9 h-9 rounded-lg overflow-hidden border border-black/5 bg-neutral-200 shrink-0 flex items-center justify-center">
            {currentSong.coverUrl ? (
              <img
                src={currentSong.coverUrl}
                alt={currentSong.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            ) : (
              <Disc3 className="w-4 h-4 text-neutral-500" />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="text-xs font-semibold text-neutral-900 truncate">{currentSong.title}</div>
            <div className="text-[11px] text-neutral-500 truncate">{currentSong.artist}</div>
          </div>
        </button>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={togglePlay}
            className="min-w-[40px] min-h-[40px] rounded-full bg-orange-600 text-white hover:bg-orange-500 flex items-center justify-center transition-colors cursor-pointer active:scale-95"
            aria-label={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}
          </button>

          <button
            type="button"
            onClick={playNext}
            className="min-w-[40px] min-h-[40px] rounded-full text-neutral-700 hover:text-neutral-950 hover:bg-black/[0.06] flex items-center justify-center transition-colors cursor-pointer active:scale-95"
            aria-label="Next track"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
