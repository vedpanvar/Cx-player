import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { Disc3 } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { useChromaTheme } from '../utils/themeColors';

interface VinylTurntableProps {
  className?: string;
  isSidebarDropTarget?: boolean;
  onJogPreviewChange?: (previewTime: number | null) => void;
}

const PARKED_ANGLE = -2; // Rests cleanly inside the right edge on its cradle
const MIN_PLAY_ANGLE = 14;
const MAX_PLAY_ANGLE = 24;
const DROP_THRESHOLD_ANGLE = 7;
const SECONDS_PER_ROTATION = 15; // 1 full 360-deg jog turn = 15s scrub

export const VinylTurntable: React.FC<VinylTurntableProps> = ({
  className = '',
  isSidebarDropTarget = false,
  onJogPreviewChange
}) => {
  const {
    currentSong,
    isPlaying,
    isNeedleDown,
    djControlsEnabled,
    putNeedleDown,
    liftNeedle,
    toggleNeedle,
    seek,
    currentTime,
    duration,
    pitchRate
  } = useAudio();

  const [rotationAngle, setRotationAngle] = useState(0);
  const [imgError, setImgError] = useState(false);

  // Tonearm drag state (used when DJ controls ON)
  const [isDraggingArm, setIsDraggingArm] = useState(false);
  const [dragArmAngle, setDragArmAngle] = useState<number | null>(null);

  // DJ jog wheel state (used when DJ controls ON)
  const [isJogging, setIsJogging] = useState(false);
  const jogStateRef = useRef<{
    lastPointerAngle: number;
    accumulatedTime: number;
    wasPlaying: boolean;
    hasMoved: boolean;
  } | null>(null);

  const discRef = useRef<HTMLDivElement | null>(null);
  const pivotRef = useRef<HTMLDivElement | null>(null);
  const armPointerStartRef = useRef<{ x: number; y: number; moved: boolean } | null>(null);

  const theme = useChromaTheme(currentSong?.id, currentSong?.coverUrl, imgError);
  const effectiveDuration = duration > 0 ? duration : currentSong?.duration || 180;

  useEffect(() => {
    setImgError(false);
  }, [currentSong?.id, currentSong?.coverUrl]);

  // Automatic CD spin strictly while audio is playing and NOT held by DJ jog wheel
  useEffect(() => {
    let animId: number;
    if (isPlaying && !isJogging) {
      let lastTs = performance.now();
      const spin = (ts: number) => {
        const dt = Math.min(50, ts - lastTs);
        lastTs = ts;
        setRotationAngle((prev) => (prev + dt * 0.045 * (pitchRate || 1.0)) % 360);
        animId = requestAnimationFrame(spin);
      };
      animId = requestAnimationFrame(spin);
    }
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, isJogging, pitchRate]);

  // Helper: angle around disc center in degrees [-180..180]
  const getDiscPointerAngle = (clientX: number, clientY: number) => {
    if (!discRef.current) return 0;
    const rect = discRef.current.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    return (Math.atan2(clientY - cy, clientX - cx) * 180) / Math.PI;
  };

  // DJ Jog Wheel handlers (only active when djControlsEnabled === true)
  const handleDiscPointerDown = (e: React.PointerEvent) => {
    if (!djControlsEnabled || !currentSong || !discRef.current) return;

    const rect = discRef.current.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dist = Math.hypot(e.clientX - cx, e.clientY - cy);
    const radius = rect.width / 2;

    // Grab outer part of the CD (outside the spindle hub)
    if (dist < radius * 0.25) return;

    e.stopPropagation();
    setIsJogging(true);

    const startPointerAngle = getDiscPointerAngle(e.clientX, e.clientY);
    jogStateRef.current = {
      lastPointerAngle: startPointerAngle,
      accumulatedTime: currentTime,
      wasPlaying: isPlaying,
      hasMoved: false
    };

    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}
  };

  const handleDiscPointerMove = (e: React.PointerEvent) => {
    if (!djControlsEnabled || !isJogging || !jogStateRef.current) return;

    const currentPointerAngle = getDiscPointerAngle(e.clientX, e.clientY);
    let delta = currentPointerAngle - jogStateRef.current.lastPointerAngle;

    // Smoothly wrap across 0°/360° (-180/+180) boundary
    if (delta > 180) delta -= 360;
    if (delta < -180) delta += 360;

    if (Math.abs(delta) > 0.2) {
      jogStateRef.current.hasMoved = true;
    }

    jogStateRef.current.lastPointerAngle = currentPointerAngle;

    // Artwork rotates smoothly with finger
    setRotationAngle((prev) => (prev + delta + 360) % 360);

    // Clockwise (+) seeks forward, counterclockwise (-) rewinds within current song
    const timeDelta = (delta / 360) * SECONDS_PER_ROTATION;
    const nextTime = Math.max(
      0,
      Math.min(effectiveDuration, jogStateRef.current.accumulatedTime + timeDelta)
    );
    jogStateRef.current.accumulatedTime = nextTime;
    onJogPreviewChange?.(nextTime);
  };

  const handleDiscPointerUp = (e: React.PointerEvent) => {
    if (!isJogging) return;
    setIsJogging(false);

    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}

    const state = jogStateRef.current;
    jogStateRef.current = null;
    onJogPreviewChange?.(null);

    if (state && state.hasMoved) {
      seek(state.accumulatedTime);
    }
  };

  // Tonearm angle calculation from pointer position relative to gimbal pivot
  const computeArmAngleFromPointer = (clientX: number, clientY: number) => {
    if (!pivotRef.current) return PARKED_ANGLE;
    const rect = pivotRef.current.getBoundingClientRect();
    const px = rect.left + rect.width / 2;
    const py = rect.top + rect.height / 2;
    const dx = px - clientX;
    const dy = Math.max(16, clientY - py);
    const deg = (Math.atan2(dx, dy) * 180) / Math.PI;
    return Math.max(-3, Math.min(28, deg));
  };

  const handleArmPointerDown = (e: React.PointerEvent) => {
    if (!djControlsEnabled) return;
    e.stopPropagation();
    setIsDraggingArm(true);
    armPointerStartRef.current = { x: e.clientX, y: e.clientY, moved: false };
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}
  };

  const handleArmPointerMove = (e: React.PointerEvent) => {
    if (!djControlsEnabled || !isDraggingArm || !armPointerStartRef.current) return;
    const dist = Math.hypot(
      e.clientX - armPointerStartRef.current.x,
      e.clientY - armPointerStartRef.current.y
    );
    if (dist > 6) {
      armPointerStartRef.current.moved = true;
    }
    if (armPointerStartRef.current.moved) {
      const nextAngle = computeArmAngleFromPointer(e.clientX, e.clientY);
      setDragArmAngle(nextAngle);
    }
  };

  const handleArmPointerUp = (e: React.PointerEvent) => {
    if (!djControlsEnabled || !isDraggingArm) return;
    setIsDraggingArm(false);

    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}

    const startInfo = armPointerStartRef.current;
    armPointerStartRef.current = null;

    if (!startInfo?.moved) {
      setDragArmAngle(null);
      toggleNeedle();
      return;
    }

    const finalAngle = dragArmAngle ?? computeArmAngleFromPointer(e.clientX, e.clientY);
    setDragArmAngle(null);

    if (finalAngle >= DROP_THRESHOLD_ANGLE) {
      if (!isNeedleDown || !isPlaying) {
        putNeedleDown();
      }
    } else {
      if (isNeedleDown || isPlaying) {
        liftNeedle();
      }
    }
  };

  // In standard mode (DJ off), needle visually follows isPlaying; in DJ mode, follows isNeedleDown
  const needleLowered = djControlsEnabled ? isNeedleDown : isPlaying;
  const progressRatio = effectiveDuration > 0 ? Math.min(1, Math.max(0, currentTime / effectiveDuration)) : 0;
  const targetArmAngle = needleLowered
    ? MIN_PLAY_ANGLE + progressRatio * (MAX_PLAY_ANGLE - MIN_PLAY_ANGLE)
    : PARKED_ANGLE;

  const displayedArmAngle = dragArmAngle !== null ? dragArmAngle : targetArmAngle;
  const armIsOverDisc = displayedArmAngle >= DROP_THRESHOLD_ANGLE;
  const hasArtwork = Boolean(currentSong?.coverUrl) && !imgError;

  return (
    <div className={`relative w-full max-w-[min(100%,calc(100dvh-236px),340px)] sm:max-w-[min(100%,calc(100dvh-250px),368px)] lg:max-w-[380px] mx-auto select-none shrink-0 ${className}`}>
      {/* Clear Acrylic Turntable Housing */}
      <div
        data-turntable-deck="true"
        className="relative w-full aspect-square rounded-[22px] sm:rounded-[24px] p-2 sm:p-3 bg-gradient-to-br from-white/75 via-white/45 to-neutral-200/60 border border-white/95 backdrop-blur-xl shadow-[0_20px_48px_rgba(15,23,42,0.12),inset_0_2px_4px_rgba(255,255,255,0.95),inset_0_-2px_6px_rgba(15,23,42,0.06)] overflow-hidden"
      >
        {/* Specular Acrylic Edge Highlights */}
        <div className="absolute inset-x-4 top-0 h-[1.5px] bg-gradient-to-r from-transparent via-white to-transparent pointer-events-none" />
        <div
          className="absolute inset-x-6 bottom-0 h-[2px] opacity-75 pointer-events-none transition-all duration-500"
          style={{
            background: `linear-gradient(90deg, transparent 5%, ${theme.primary} 45%, ${theme.secondary} 75%, transparent 95%)`
          }}
        />

        {/* Inner Molded Clear Acrylic Well */}
        <div className="relative w-full h-full rounded-[16px] bg-gradient-to-b from-white/50 via-neutral-100/40 to-neutral-200/55 border border-white/80 shadow-[inset_0_2px_10px_rgba(15,23,42,0.08)] overflow-hidden">
          
          {/* Top-Left Polished Gold Speed Knob */}
          <div
            className="absolute top-[5%] left-[5%] z-20 w-[10%] h-[10%] rounded-full bg-gradient-to-br from-amber-200 via-amber-500 to-amber-800 p-[2px] shadow-[0_4px_10px_rgba(120,53,15,0.3)] pointer-events-none flex items-center justify-center"
            aria-hidden="true"
          >
            <div className="w-full h-full rounded-full bg-gradient-to-tr from-amber-600 via-yellow-200 to-amber-500 border border-white/60 flex items-center justify-center">
              <div className="w-[45%] h-[45%] rounded-full bg-gradient-to-b from-amber-700 to-amber-900 shadow-inner" />
            </div>
          </div>

          {/* Bottom-Left & Bottom-Right Polished Gold Corner Screws */}
          {['bottom-[4.5%] left-[4.5%]', 'bottom-[4.5%] right-[4.5%]'].map((pos, idx) => (
            <div
              key={idx}
              className={`absolute ${pos} z-20 w-[5.5%] h-[5.5%] rounded-full bg-gradient-to-br from-amber-100 via-amber-500 to-amber-800 shadow-[0_2px_5px_rgba(120,53,15,0.3)] flex items-center justify-center pointer-events-none`}
              aria-hidden="true"
            >
              <div className="w-[55%] h-[1.5px] bg-amber-950/60 rotate-45 rounded-full" />
            </div>
          ))}

          {/* Recessed Acrylic Platter Ring */}
          <div className="absolute top-[8%] left-[6%] w-[83%] h-[83%] rounded-full bg-gradient-to-b from-neutral-200/90 to-white/75 border border-white/90 shadow-[inset_0_4px_14px_rgba(15,23,42,0.14),0_2px_8px_rgba(255,255,255,0.9)] flex items-center justify-center p-[2.2%]">
            
            {/* Large Spinning Reflective CD */}
            <div
              ref={discRef}
              onPointerDown={handleDiscPointerDown}
              onPointerMove={handleDiscPointerMove}
              onPointerUp={handleDiscPointerUp}
              onPointerCancel={handleDiscPointerUp}
              style={{
                transform: `rotate(${rotationAngle}deg)`,
                touchAction: djControlsEnabled ? 'none' : 'auto'
              }}
              className={`relative w-full h-full rounded-full overflow-hidden border border-white/80 shadow-[0_10px_28px_rgba(15,23,42,0.22)] flex items-center justify-center ${
                djControlsEnabled ? 'cursor-grab active:cursor-grabbing' : ''
              }`}
              title={djControlsEnabled ? 'Rotate outer CD rim to seek forward or rewind' : currentSong?.title}
            >
              {/* Full-Bleed Rotating Cover Art across Whole Disc Face */}
              {hasArtwork ? (
                <img
                  src={currentSong?.coverUrl}
                  alt={currentSong?.title || 'CD Artwork'}
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover scale-[1.03] select-none pointer-events-none"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-neutral-200 via-neutral-300 to-neutral-400 flex items-center justify-center">
                  <Disc3 className="w-16 h-16 text-neutral-500/40" />
                </div>
              )}

              {/* Subtle Fine Grooves */}
              <div
                className="absolute inset-0 rounded-full pointer-events-none opacity-35"
                style={{
                  background:
                    'repeating-radial-gradient(circle at center, rgba(255,255,255,0.28) 0px, rgba(255,255,255,0) 1px, rgba(0,0,0,0.22) 2px, rgba(0,0,0,0) 3.5px)'
                }}
              />

              {/* Reflective Iridescent Rim & Optical CD Sheen */}
              <div
                className="absolute inset-0 rounded-full pointer-events-none mix-blend-screen opacity-45"
                style={{
                  background:
                    'conic-gradient(from 30deg at 50% 50%, rgba(255,255,255,0.05) 0deg, rgba(251,146,60,0.32) 28deg, rgba(255,255,255,0.45) 55deg, rgba(56,189,248,0.26) 85deg, rgba(255,255,255,0.05) 130deg, rgba(255,255,255,0.05) 195deg, rgba(251,146,60,0.3) 225deg, rgba(255,255,255,0.45) 252deg, rgba(56,189,248,0.26) 280deg, rgba(255,255,255,0.05) 330deg)'
                }}
              />

              {/* Subtle Burnt-Orange / Metallic Outer Rim Bevel */}
              <div
                className="absolute inset-0 rounded-full pointer-events-none"
                style={{
                  boxShadow: `inset 0 0 0 2px rgba(255,255,255,0.55), inset 0 0 12px ${theme.rimTint}`
                }}
              />

              {/* Center Spindle Ring & Visible Spindle Hole */}
              <div
                data-turntable-spindle="true"
                className={`relative z-10 w-[26%] h-[26%] rounded-full p-[3px] shadow-[0_4px_14px_rgba(0,0,0,0.32)] flex items-center justify-center pointer-events-none transition-transform duration-200 ${
                  isSidebarDropTarget ? 'scale-110 ring-4 ring-orange-500/60' : ''
                }`}
                style={{
                  background: `linear-gradient(135deg, ${theme.primary}, #fb923c, #e4e4e7)`
                }}
              >
                <div className="w-full h-full rounded-full bg-gradient-to-tr from-neutral-200 via-white to-neutral-300 border border-white/80 flex items-center justify-center shadow-inner">
                  <div className="w-[46%] h-[46%] rounded-full bg-neutral-800 border border-neutral-400 shadow-[inset_0_2px_4px_rgba(0,0,0,0.85)]" />
                </div>
              </div>
            </div>
          </div>

          {/* Tonearm Rest Post (cleanly inside right acrylic edge) */}
          <div
            className="absolute top-[56%] right-[6%] z-10 w-[4.5%] h-[4.5%] rounded-full bg-gradient-to-b from-amber-200 via-amber-500 to-amber-800 border border-white/70 shadow-sm flex items-center justify-center pointer-events-none"
            aria-hidden="true"
          >
            <div className="w-[42%] h-[42%] rounded-full bg-neutral-800" />
          </div>

          {/* Polished Gold Tonearm & Burnt-Orange Headshell */}
          <div
            ref={pivotRef}
            onPointerDown={handleArmPointerDown}
            onPointerMove={handleArmPointerMove}
            onPointerUp={handleArmPointerUp}
            onPointerCancel={handleArmPointerUp}
            role={djControlsEnabled ? 'button' : undefined}
            tabIndex={djControlsEnabled ? 0 : undefined}
            onKeyDown={(e) => {
              if (!djControlsEnabled) return;
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                toggleNeedle();
              }
            }}
            aria-label={
              djControlsEnabled
                ? isNeedleDown
                  ? 'Lift needle to pause'
                  : 'Drop needle to play'
                : undefined
            }
            title={
              djControlsEnabled
                ? 'Drag onto the CD to play, drag back to rest to pause, or tap to toggle'
                : 'Tonearm follows playback state'
            }
            className={`absolute top-[4.5%] right-[4.5%] z-30 w-[18.5%] h-[18.5%] rounded-full ${
              djControlsEnabled
                ? 'cursor-grab active:cursor-grabbing touch-none focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-500'
                : 'pointer-events-none'
            }`}
          >
            {/* Polished Gold Gimbal Housing */}
            <div className="relative w-full h-full rounded-full bg-gradient-to-b from-amber-100 via-amber-400 to-amber-700 p-[2px] shadow-[0_6px_16px_rgba(120,53,15,0.28)]">
              <div className="w-full h-full rounded-full bg-gradient-to-b from-amber-500 via-amber-300 to-amber-700 border border-white/60 flex items-center justify-center">
                <div className="w-[56%] h-[56%] rounded-full bg-gradient-to-tr from-amber-700 via-yellow-200 to-amber-500 border border-white/80 shadow-inner" />
              </div>

              {/* Rotating Gold S-Curve Arm scaled proportionally to stay inside deck at 320px+ */}
              <motion.div
                animate={{ rotate: displayedArmAngle }}
                transition={
                  isDraggingArm
                    ? { type: 'tween', duration: 0.02 }
                    : { type: 'spring', stiffness: 210, damping: 22 }
                }
                style={{ transformOrigin: '50% 9%' }}
                className="absolute top-[24%] left-0 w-full h-[332%] pointer-events-none flex justify-center"
              >
                <svg
                  viewBox="0 0 64 210"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-full h-full drop-shadow-[0_6px_10px_rgba(120,53,15,0.32)] overflow-visible"
                >
                  <defs>
                    <linearGradient id="goldArmGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#b45309" />
                      <stop offset="35%" stopColor="#fef08a" />
                      <stop offset="65%" stopColor="#eab308" />
                      <stop offset="100%" stopColor="#92400e" />
                    </linearGradient>
                    <linearGradient id="orangeHeadshellGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#fb923c" />
                      <stop offset="55%" stopColor="#ea580c" />
                      <stop offset="100%" stopColor="#9a3412" />
                    </linearGradient>
                  </defs>

                  {/* Gold Counterweight */}
                  <rect x="24" y="0" width="16" height="12" rx="3" fill="url(#goldArmGrad)" stroke="#92400e" strokeWidth="0.9" />

                  {/* Polished Gold S-Curve Arm Tube */}
                  <path
                    d="M32 15 C32 54, 41 80, 38 112 C35 138, 28 152, 26 170"
                    stroke="url(#goldArmGrad)"
                    strokeWidth="6"
                    strokeLinecap="round"
                  />

                  {/* Burnt-Orange Headshell & Stylus */}
                  <g transform="translate(26, 166) rotate(12)">
                    <rect x="-7" y="0" width="14" height="26" rx="2.5" fill="url(#orangeHeadshellGrad)" stroke="#fdba74" strokeWidth="0.8" />
                    <circle cx="0" cy="6.5" r="1.5" fill="#7c2d12" />
                    <circle cx="0" cy="12" r="1.5" fill="#7c2d12" />
                    <circle cx="0" cy="17.5" r="1.5" fill="#7c2d12" />
                    <rect x="-5" y="23" width="10" height="7" rx="1.5" fill="#27272a" stroke="#52525b" strokeWidth="0.8" />
                    <circle
                      cx="0"
                      cy="30"
                      r={armIsOverDisc ? 3.2 : 2.2}
                      fill={armIsOverDisc ? '#fb923c' : '#a1a1aa'}
                      style={{
                        filter: armIsOverDisc ? 'drop-shadow(0 0 5px #ea580c)' : 'none'
                      }}
                    />
                  </g>
                </svg>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
