import React from 'react';
import {
  Play,
  Pause,
  Heart,
  ArrowLeft,
  Users,
  CheckCircle,
  Disc
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { MOCK_ARTISTS, MOCK_SONGS } from '../data/mockData';

export const ArtistDetailView: React.FC = () => {
  const {
    selectedEntityId,
    navigateTo,
    playSong,
    currentSong,
    isPlaying,
    likedSongIds,
    toggleLikeSong
  } = useAudio();

  const artist = MOCK_ARTISTS.find((a) => a.id === selectedEntityId);

  if (!artist) {
    return (
      <div className="text-center py-20 text-neutral-400">
        Artist not found.
        <button
          onClick={() => navigateTo('library')}
          className="block mx-auto mt-4 px-4 py-2 bg-purple-600 text-white rounded-full text-xs font-bold"
        >
          Back to Library
        </button>
      </div>
    );
  }

  const popularSongs = MOCK_SONGS.filter((s) => artist.popularSongIds.includes(s.id));

  const handlePlayArtist = () => {
    if (popularSongs.length > 0) {
      playSong(popularSongs[0], popularSongs);
    }
  };

  return (
    <div className="space-y-8 pb-24 animate-in fade-in duration-300">
      <button
        onClick={() => navigateTo('library')}
        className="flex items-center gap-2 text-xs font-semibold text-neutral-400 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Library</span>
      </button>

      {/* Artist Banner */}
      <div className="relative rounded-3xl overflow-hidden h-64 sm:h-80 bg-neutral-900 border border-white/10 shadow-2xl flex items-end p-6 sm:p-10">
        <img
          src={artist.bannerUrl}
          alt={artist.name}
          className="absolute inset-0 w-full h-full object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/60 to-transparent" />

        <div className="relative z-10 flex items-center gap-6">
          <img
            src={artist.avatarUrl}
            alt={artist.name}
            className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover border-4 border-purple-500 shadow-2xl flex-shrink-0"
          />

          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-purple-400">
              <CheckCircle className="w-4 h-4 text-purple-400" />
              <span>Verified Artist</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white">{artist.name}</h1>
            <p className="text-xs sm:text-sm text-neutral-300 flex items-center gap-2">
              <Users className="w-4 h-4 text-purple-400" />
              <span>{(artist.monthlyListeners / 1000000).toFixed(1)}M Monthly Listeners</span>
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons & Bio */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white/[0.02] border border-white/5">
        <div className="flex items-center gap-4">
          <button
            onClick={handlePlayArtist}
            className="flex items-center gap-2 px-7 py-3 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-bold text-sm shadow-[0_0_20px_rgba(168,85,247,0.5)] hover:scale-105 transition-all"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Play Top Songs</span>
          </button>
        </div>

        <div className="flex flex-wrap gap-2">
          {artist.genres.map((g, i) => (
            <span
              key={i}
              className="px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-semibold"
            >
              {g}
            </span>
          ))}
        </div>
      </div>

      {/* Bio text */}
      <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 text-sm text-neutral-300 leading-relaxed">
        <h3 className="font-bold text-white mb-1">About</h3>
        <p>{artist.bio}</p>
      </div>

      {/* Popular Tracks */}
      <section className="space-y-4">
        <h2 className="text-xl font-bold text-white">Popular Tracks</h2>
        <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-3 divide-y divide-white/5">
          {popularSongs.map((song, i) => {
            const isCurrent = currentSong?.id === song.id;
            const isLiked = likedSongIds.has(song.id);

            return (
              <div
                key={song.id}
                className="flex items-center justify-between p-3 rounded-2xl hover:bg-white/[0.06] transition-colors group"
              >
                <div
                  onClick={() => playSong(song, popularSongs)}
                  className="flex items-center gap-3.5 min-w-0 flex-1 cursor-pointer"
                >
                  <span className="font-mono text-xs text-neutral-500 w-5 text-center">
                    {i + 1}
                  </span>
                  <img
                    src={song.coverUrl}
                    alt={song.title}
                    className="w-11 h-11 rounded-xl object-cover border border-white/10"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="font-bold text-sm text-white group-hover:text-purple-300 truncate">
                      {song.title}
                    </div>
                    <div className="text-xs text-neutral-400 truncate">{song.album}</div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <button
                    onClick={() => toggleLikeSong(song.id)}
                    className={`p-2 rounded-full ${isLiked ? 'text-rose-500' : 'text-neutral-500 hover:text-white'}`}
                  >
                    <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500' : ''}`} />
                  </button>
                  <span className="text-xs font-mono text-neutral-400 w-10 text-right">
                    {song.durationFormatted}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Albums */}
      {artist.albums && artist.albums.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Disc className="w-5 h-5 text-purple-400" />
            <span>Discography</span>
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {artist.albums.map((alb) => (
              <div
                key={alb.id}
                onClick={() => navigateTo('album', alb.id)}
                className="p-3.5 rounded-2xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 cursor-pointer group transition-all"
              >
                <img
                  src={alb.coverUrl}
                  alt={alb.title}
                  className="w-full aspect-square rounded-xl object-cover mb-3 group-hover:scale-105 transition-transform"
                />
                <div className="font-bold text-sm text-white truncate">{alb.title}</div>
                <div className="text-xs text-neutral-400">{alb.year} • {alb.genre}</div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
