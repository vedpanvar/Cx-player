import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Disc3, CheckCircle2 } from 'lucide-react';
import { useAudio } from '../context/AudioContext';

export const DownloadToast: React.FC = () => {
  const { downloadToast } = useAudio();

  return (
    <AnimatePresence>
      {downloadToast && (
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.96 }}
          transition={{ duration: 0.18 }}
          className="fixed top-14 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-2 rounded-2xl bg-white/92 border border-white text-neutral-900 shadow-[0_12px_32px_rgba(15,23,42,0.14)] backdrop-blur-xl select-none max-w-[90vw]"
        >
          {downloadToast.includes('Saved') || downloadToast.includes('Loaded') ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <Disc3 className="w-4 h-4 text-orange-600 shrink-0" />
          )}
          <span className="text-xs font-medium text-neutral-800 truncate">
            {downloadToast}
          </span>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
