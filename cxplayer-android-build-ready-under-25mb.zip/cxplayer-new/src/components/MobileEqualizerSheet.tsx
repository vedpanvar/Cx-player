import React, { useState } from 'react';
import { Sliders, RotateCcw, X, Gauge } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { motion, AnimatePresence } from 'motion/react';

interface MobileEqualizerSheetProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESETS = [
  'Flat',
  'Bass Boost',
  'Vocal',
  'Rock',
  'Pop',
  'Electronic',
  'Jazz',
  'Classical'
];

export const MobileEqualizerSheet: React.FC<MobileEqualizerSheetProps> = ({ isOpen, onClose }) => {
  const { equalizerPreset, setEqualizerPreset, pitchRate, setPitchRate } = useAudio();

  const [bands, setBands] = useState<number[]>([4, 6, 2, 5, 7]);
  const [bass, setBass] = useState<number>(60);
  const [treble, setTreble] = useState<number>(50);

  const bandFrequencies = ['60Hz', '230Hz', '910Hz', '3.6kHz', '14kHz'];

  if (!isOpen) return null;

  const handleBandChange = (index: number, val: number) => {
    setBands((prev) => {
      const next = [...prev];
      next[index] = val;
      return next;
    });
  };

  const handleReset = () => {
    setBands([0, 0, 0, 0, 0]);
    setBass(50);
    setTreble(50);
    setEqualizerPreset('Flat');
    setPitchRate(1.0);
  };

  const applyPreset = (preset: string) => {
    setEqualizerPreset(preset);
    switch (preset) {
      case 'Bass Boost':
        setBands([8, 6, 2, 2, 3]);
        setBass(85);
        break;
      case 'Vocal':
        setBands([2, 5, 7, 6, 4]);
        setBass(50);
        break;
      case 'Rock':
        setBands([6, 4, -1, 5, 7]);
        setBass(70);
        break;
      case 'Jazz':
        setBands([4, 3, 2, 3, 3]);
        setBass(55);
        break;
      case 'Electronic':
        setBands([7, 5, 1, 5, 8]);
        setBass(80);
        break;
      default:
        setBands([0, 0, 0, 0, 0]);
        setBass(50);
        break;
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end justify-center bg-neutral-900/25 backdrop-blur-md">
        <div className="absolute inset-0" onClick={onClose} />

        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 28, stiffness: 250 }}
          className="relative z-10 w-full max-w-lg bg-[#f6f6fa]/95 backdrop-blur-2xl border-t border-white rounded-t-[30px] p-4 sm:p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] shadow-[0_-16px_48px_rgba(15,23,42,0.16)] flex flex-col max-h-[86dvh] select-none overflow-y-auto custom-scrollbar"
        >
          <div className="w-10 h-1 rounded-full bg-neutral-300 mx-auto mb-3" />

          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-black/[0.06] mb-4">
            <div className="flex items-center gap-2.5">
              <Sliders className="w-4 h-4 text-orange-600" />
              <h2 className="font-semibold text-base text-neutral-900">Equalizer & Tone</h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleReset}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-neutral-100 border border-black/[0.06] text-neutral-700 text-xs font-medium cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="min-w-[40px] min-h-[40px] flex items-center justify-center text-neutral-600 hover:text-neutral-900 rounded-full bg-white border border-black/[0.06] shadow-sm cursor-pointer"
                aria-label="Close Equalizer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Presets */}
          <div className="mb-4">
            <div className="text-xs font-medium text-neutral-500 mb-2">
              Sound Profile · {equalizerPreset}
            </div>
            <div className="flex items-center gap-2 overflow-x-auto custom-scrollbar pb-2">
              {PRESETS.map((p) => {
                const isSelected = equalizerPreset === p;
                return (
                  <button
                    key={p}
                    type="button"
                    onClick={() => applyPreset(p)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-orange-600 text-white shadow-sm'
                        : 'bg-white/80 border border-black/[0.05] text-neutral-700 hover:bg-white'
                    }`}
                  >
                    {p}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 5-Band Sliders */}
          <div className="p-4 rounded-2xl bg-white/80 border border-white mb-4 shadow-sm">
            <div className="grid grid-cols-5 gap-1 py-2">
              {bandFrequencies.map((freq, index) => {
                const val = bands[index] || 0;
                return (
                  <div key={freq} className="flex flex-col items-center gap-2">
                    <span className="text-[10px] tabular-nums text-neutral-700 font-medium">
                      {val > 0 ? `+${val}` : val}dB
                    </span>

                    <div className="h-28 flex items-center justify-center">
                      <input
                        type="range"
                        min="-12"
                        max="12"
                        step="1"
                        value={val}
                        onChange={(e) => handleBandChange(index, parseInt(e.target.value, 10))}
                        className="w-24 h-1.5 bg-neutral-300 rounded-lg appearance-none cursor-pointer -rotate-90 accent-orange-600"
                      />
                    </div>

                    <span className="text-[10px] tabular-nums text-neutral-500 text-center">
                      {freq}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bass, Treble & Speed */}
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div className="p-3.5 rounded-2xl bg-white/80 border border-white space-y-2 shadow-sm">
              <div className="flex items-center justify-between text-xs">
                <span className="text-neutral-800 font-medium">Bass</span>
                <span className="tabular-nums text-neutral-500">{bass}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={bass}
                onChange={(e) => setBass(parseInt(e.target.value, 10))}
                className="w-full h-1.5 bg-neutral-300 rounded-lg appearance-none cursor-pointer accent-orange-600"
              />
            </div>

            <div className="p-3.5 rounded-2xl bg-white/80 border border-white space-y-2 shadow-sm">
              <div className="flex items-center justify-between text-xs">
                <span className="text-neutral-800 font-medium">Treble</span>
                <span className="tabular-nums text-neutral-500">{treble}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={treble}
                onChange={(e) => setTreble(parseInt(e.target.value, 10))}
                className="w-full h-1.5 bg-neutral-300 rounded-lg appearance-none cursor-pointer accent-orange-600"
              />
            </div>
          </div>

          {/* Speed Pitch */}
          <div className="p-3.5 rounded-2xl bg-white/80 border border-white space-y-2 shadow-sm">
            <div className="flex items-center justify-between text-xs">
              <span className="text-neutral-800 font-medium flex items-center gap-1.5">
                <Gauge className="w-3.5 h-3.5 text-orange-600" />
                <span>Platter Speed</span>
              </span>
              <span className="tabular-nums text-neutral-900 font-semibold">{pitchRate.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="2.0"
              step="0.05"
              value={pitchRate}
              onChange={(e) => setPitchRate(parseFloat(e.target.value))}
              className="w-full h-1.5 bg-neutral-300 rounded-lg appearance-none cursor-pointer accent-orange-600"
            />
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
