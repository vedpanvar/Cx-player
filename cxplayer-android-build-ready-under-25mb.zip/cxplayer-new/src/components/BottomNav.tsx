import React from 'react';
import { Disc, Music, FolderOpen, Sliders, Heart } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { ViewType } from '../types';
import { motion } from 'motion/react';

export const BottomNav: React.FC = () => {
  const { currentView, navigateTo, selectedEntityId } = useAudio();

  const navItems: { id: ViewType; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Player', icon: Disc },
    { id: 'tracks', label: 'Tracks', icon: Music },
    { id: 'folders', label: 'Folders', icon: FolderOpen },
    { id: 'liked', label: 'Favorites', icon: Heart },
    { id: 'profile', label: 'Equalizer', icon: Sliders },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-neutral-950/95 backdrop-blur-2xl border-t border-white/10 px-2 py-1.5 flex items-center justify-around select-none shadow-[0_-5px_25px_rgba(0,0,0,0.9)]">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = (currentView === item.id && !selectedEntityId);

        return (
          <button
            key={item.id}
            onClick={() => navigateTo(item.id)}
            className="relative flex flex-col items-center justify-center py-1 px-2.5 min-w-[56px] transition-all group cursor-pointer"
          >
            {isActive && (
              <motion.div
                layoutId="bottomNavGlow"
                className="absolute inset-0 bg-purple-500/20 rounded-xl border border-purple-500/40"
                transition={{ type: 'spring', stiffness: 350, damping: 30 }}
              />
            )}
            <Icon
              className={`w-5 h-5 transition-transform duration-200 group-active:scale-90 z-10 ${
                isActive ? 'text-purple-400 scale-110 drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]' : 'text-neutral-400'
              }`}
            />
            <span
              className={`text-[10px] font-medium mt-1 z-10 transition-colors ${
                isActive ? 'text-white font-bold' : 'text-neutral-400'
              }`}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
