import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Disc3, Play } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { Song } from '../types';

interface UpNextSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onDropTargetChange: (active: boolean) => void;
}

interface FloatingDragState {
  song: Song;
  x: number;
  y: number;
  isOverDeck: boolean;
  snappingTarget: { x: number; y: number } | null;
}

export const UpNextSidebar: React.FC<UpNextSidebarProps> = ({
  isOpen,
  onClose,
  onDropTargetChange
}) => {
  const { queue, allSongs, currentSong, swapDiscAndPlay } = useAudio();
  const [floatingDrag, setFloatingDrag] = useState<FloatingDragState | null>(null);
  const sidebarRef = useRef<HTMLDivElement | null>(null);

  const pendingDragRef = useRef<{
    song: Song;
    startX: number;
    startY: number;
    active: boolean;
    cancelled: boolean;
  } | null>(null);

  const displayList = queue.length > 0 ? queue : allSongs;

  const isPointOverDeck = (clientX: number, clientY: number): boolean => {
    const deckEl = document.querySelector('[data-turntable-deck="true"]');
    if (!deckEl) return false;
    const rect = deckEl.getBoundingClientRect();
    const sbRect = sidebarRef.current?.getBoundingClientRect();
    const rightLimit = sbRect ? Math.min(rect.right + 8, sbRect.left + 8) : rect.right + 8;
    const inX = clientX >= rect.left - 12 && clientX <= rightLimit;
    const inY = clientY >= rect.top - 12 && clientY <= rect.bottom + 12;
    return inX && inY;
  };

  const getSpindleCenter = (): { x: number; y: number } | null => {
    const spindleEl = document.querySelector('[data-turntable-spindle="true"]');
    if (!spindleEl) return null;
    const rect = spindleEl.getBoundingClientRect();
    return {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2
    };
  };

  const handleDiscPointerDown = (e: React.PointerEvent, song: Song) => {
    pendingDragRef.current = {
      song,
      startX: e.clientX,
      startY: e.clientY,
      active: false,
      cancelled: false
    };
  };

  const handleDiscPointerMove = (e: React.PointerEvent) => {
    const pending = pendingDragRef.current;
    if (!pending || pending.cancelled) return;

    const dx = e.clientX - pending.startX;
    const dy = e.clientY - pending.startY;

    if (!pending.active) {
      const dist = Math.hypot(dx, dy);
      if (dist < 7) return;

      // Separate vertical scroll from horizontal left disc drag
      if (Math.abs(dy) > Math.abs(dx) || dx > -4) {
        pending.cancelled = true;
        return;
      }

      pending.active = true;
      try {
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      } catch {}
    }

    const overDeck = isPointOverDeck(e.clientX, e.clientY);
    onDropTargetChange(overDeck);
    setFloatingDrag({
      song: pending.song,
      x: e.clientX,
      y: e.clientY,
      isOverDeck: overDeck,
      snappingTarget: null
    });
  };

  const handleDiscPointerUp = (e: React.PointerEvent) => {
    const pending = pendingDragRef.current;
    pendingDragRef.current = null;
    onDropTargetChange(false);

    if (!pending || !pending.active) {
      setFloatingDrag(null);
      return;
    }

    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}

    const overDeck = isPointOverDeck(e.clientX, e.clientY);
    const spindle = getSpindleCenter();

    if (overDeck && spindle) {
      // Animate disc snapping onto the main turntable spindle
      setFloatingDrag({
        song: pending.song,
        x: e.clientX,
        y: e.clientY,
        isOverDeck: true,
        snappingTarget: spindle
      });

      setTimeout(() => {
        swapDiscAndPlay(pending.song);
        setFloatingDrag(null);
        onClose();
      }, 220);
    } else {
      // Released early or outside deck: cancel cleanly and keep current track playing
      setFloatingDrag(null);
    }
  };

  const handlePlayNow = (song: Song) => {
    swapDiscAndPlay(song);
    onClose();
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Invisible tap backdrop on far left so tapping outside closes sidebar cleanly */}
            <div
              onClick={onClose}
              className="fixed inset-0 z-30 bg-black/[0.03]"
              aria-hidden="true"
            />

            {/* Transparent Clear-Glass Right Sidebar */}
            <motion.aside
              ref={sidebarRef}
              initial={{ x: '105%', opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '105%', opacity: 0 }}
              transition={{ type: 'spring', stiffness: 320, damping: 30 }}
              aria-label="Up Next Queue"
              className="absolute top-[46px] sm:top-[50px] right-2 sm:right-3 bottom-3 z-40 w-[53%] min-w-[166px] max-w-[218px] rounded-[24px] bg-white/62 backdrop-blur-2xl border border-white/90 shadow-[0_18px_46px_rgba(15,23,42,0.16),inset_0_1.5px_2px_rgba(255,255,255,0.95)] flex flex-col overflow-hidden select-none"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-black/[0.06] shrink-0">
                <h2 className="text-sm font-semibold text-neutral-900">Up Next</h2>
                <button
                  type="button"
                  onClick={onClose}
                  className="min-w-[34px] min-h-[34px] flex items-center justify-center rounded-full text-neutral-600 hover:text-neutral-950 hover:bg-black/[0.06] transition-colors cursor-pointer"
                  aria-label="Close Up Next"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Scrollable Jewel Case Queue */}
              <div
                className="flex-1 overflow-y-auto custom-scrollbar px-3 py-2.5 space-y-3.5"
                style={{ touchAction: 'pan-y' }}
              >
                {displayList.map((song, idx) => {
                  const isCurrent = song.id === currentSong?.id;
                  const isBeingDragged = floatingDrag?.song.id === song.id;

                  return (
                    <div
                      key={`${song.id}-jewel-${idx}`}
                      className="flex flex-col gap-1.5"
                    >
                      {/* Transparent Jewel Case + Peeking CD */}
                      <div
                        onPointerDown={(e) => handleDiscPointerDown(e, song)}
                        onPointerMove={handleDiscPointerMove}
                        onPointerUp={handleDiscPointerUp}
                        onPointerCancel={handleDiscPointerUp}
                        className="relative flex items-center cursor-grab active:cursor-grabbing group"
                        style={{ touchAction: 'pan-y' }}
                        title="Slide disc left onto the turntable spindle to play"
                      >
                        {/* Peeking CD Disc (slides out of right side, hides when dragged out) */}
                        <div
                          className={`absolute left-[38%] w-[64px] h-[64px] sm:w-[70px] sm:h-[70px] rounded-full overflow-hidden border border-white/80 shadow-[0_4px_12px_rgba(15,23,42,0.18)] transition-opacity duration-150 ${
                            isBeingDragged ? 'opacity-0' : 'opacity-100 group-hover:-translate-x-1 transition-transform'
                          }`}
                        >
                          {song.coverUrl ? (
                            <img
                              src={song.coverUrl}
                              alt=""
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full bg-gradient-to-br from-neutral-200 to-neutral-400" />
                          )}
                          {/* Reflective CD sheen & center hole */}
                          <div
                            className="absolute inset-0 pointer-events-none mix-blend-screen opacity-55"
                            style={{
                              background:
                                'conic-gradient(from 45deg, transparent 0deg, rgba(255,255,255,0.6) 45deg, rgba(251,146,60,0.35) 95deg, transparent 160deg, rgba(255,255,255,0.5) 220deg, transparent 300deg)'
                            }}
                          />
                          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <div className="w-4 h-4 rounded-full bg-white/85 border border-neutral-300 flex items-center justify-center">
                              <div className="w-2 h-2 rounded-full bg-neutral-500/70" />
                            </div>
                          </div>
                        </div>

                        {/* Clear Plastic Jewel Case Cover */}
                        <div
                          className={`relative z-10 w-[72px] h-[72px] sm:w-[78px] sm:h-[78px] rounded-[7px] overflow-hidden border shadow-[0_6px_14px_rgba(15,23,42,0.14),inset_0_1px_2px_rgba(255,255,255,0.9)] bg-white/40 backdrop-blur-sm flex ${
                            isCurrent ? 'border-orange-500/80 ring-2 ring-orange-500/25' : 'border-white/90'
                          }`}
                        >
                          {/* Clear Acrylic Hinge Strip */}
                          <div className="w-2 h-full bg-gradient-to-r from-white/75 via-white/30 to-black/10 border-r border-white/60 shrink-0" />

                          {/* Artwork Inside Case (becomes empty transparent molded tray when dragged out!) */}
                          <div className="relative flex-1 h-full overflow-hidden">
                            {isBeingDragged ? (
                              <div className="w-full h-full bg-white/25 flex items-center justify-center">
                                <div className="w-10 h-10 rounded-full border border-dashed border-neutral-400/50 flex items-center justify-center">
                                  <div className="w-2.5 h-2.5 rounded-full border border-neutral-400/60" />
                                </div>
                              </div>
                            ) : song.coverUrl ? (
                              <img
                                src={song.coverUrl}
                                alt={song.title}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full bg-neutral-200 flex items-center justify-center">
                                <Disc3 className="w-6 h-6 text-neutral-400" />
                              </div>
                            )}

                            {/* Glossy Diagonal Jewel Case Plastic Reflection */}
                            <div
                              className="absolute inset-0 pointer-events-none"
                              style={{
                                background:
                                  'linear-gradient(125deg, rgba(255,255,255,0.38) 0%, rgba(255,255,255,0.05) 45%, rgba(255,255,255,0) 60%)'
                              }}
                            />
                          </div>
                        </div>
                      </div>

                      {/* Track Title, Artist, Duration & Accessible Play Now Action */}
                      <div className="flex items-start justify-between gap-1.5 pr-0.5">
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-semibold text-neutral-900 truncate leading-tight">
                            {song.title}
                          </div>
                          <div className="text-[11px] text-neutral-500 truncate mt-0.5">
                            {song.artist}
                          </div>
                        </div>

                        <span className="text-[10px] tabular-nums text-neutral-500 pt-0.5 shrink-0">
                          {song.durationFormatted}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() => handlePlayNow(song)}
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium transition-colors cursor-pointer ${
                            isCurrent
                              ? 'bg-orange-600 text-white'
                              : 'bg-black/[0.06] hover:bg-orange-600 text-neutral-700 hover:text-white'
                          }`}
                          aria-label={`Play now: ${song.title}`}
                        >
                          <Play className="w-2.5 h-2.5 fill-current" />
                          <span>{isCurrent ? 'Playing' : 'Play now'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Floating CD Layer while sliding a queued disc toward the turntable spindle */}
      {floatingDrag && (
        <motion.div
          initial={false}
          animate={
            floatingDrag.snappingTarget
              ? {
                  left: floatingDrag.snappingTarget.x,
                  top: floatingDrag.snappingTarget.y,
                  scale: 1.45,
                  opacity: 0.9
                }
              : {
                  left: floatingDrag.x,
                  top: floatingDrag.y,
                  scale: floatingDrag.isOverDeck ? 1.15 : 1,
                  opacity: 1
                }
          }
          transition={
            floatingDrag.snappingTarget
              ? { type: 'spring', stiffness: 360, damping: 26 }
              : { type: 'tween', duration: 0.02 }
          }
          style={{
            position: 'fixed',
            zIndex: 60,
            marginLeft: '-48px',
            marginTop: '-48px',
            pointerEvents: 'none'
          }}
          className="w-24 h-24 rounded-full overflow-hidden border-2 border-white shadow-[0_14px_34px_rgba(234,88,12,0.45)]"
        >
          {floatingDrag.song.coverUrl ? (
            <img
              src={floatingDrag.song.coverUrl}
              alt={floatingDrag.song.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-neutral-200 to-neutral-400" />
          )}
          <div
            className="absolute inset-0 mix-blend-screen opacity-55"
            style={{
              background:
                'conic-gradient(from 40deg, transparent 0deg, rgba(251,146,60,0.45) 45deg, rgba(255,255,255,0.6) 90deg, transparent 180deg, rgba(251,146,60,0.4) 240deg, transparent 320deg)'
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-6 h-6 rounded-full bg-white/90 border border-orange-500 flex items-center justify-center">
              <div className="w-2.5 h-2.5 rounded-full bg-neutral-800" />
            </div>
          </div>
        </motion.div>
      )}
    </>
  );
};
