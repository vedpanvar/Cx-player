import React, { useState, useEffect } from 'react';
import {
  Heart,
  MoreHorizontal,
  Play,
  Pause,
  Shuffle,
  Repeat,
  Repeat1,
  SkipBack,
  SkipForward,
  Disc3
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { VinylTurntable } from './VinylTurntable';
import { useChromaTheme } from '../utils/themeColors';
import { PhoneFileScanner } from './PhoneFileScanner';

interface HomeViewProps {
  onOpenLibrary: () => void;
  isSidebarDropTarget: boolean;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onOpenLibrary,
  isSidebarDropTarget
}) => {
  const {
    currentSong,
    isPlaying,
    isNeedleDown,
    djControlsEnabled,
    toggleNeedle,
    togglePlay,
    playNext,
    playPrevious,
    currentTime,
    duration,
    seek,
    likedSongIds,
    toggleLikeSong,
    queue,
    allSongs,
    playSong,
    isShuffle,
    toggleShuffle,
    repeatMode,
    toggleRepeat
  } = useAudio();

  const [thumbError, setThumbError] = useState(false);
  const [jogPreviewTime, setJogPreviewTime] = useState<number | null>(null);

  useEffect(() => {
    setThumbError(false);
    setJogPreviewTime(null);
  }, [currentSong?.id, currentSong?.coverUrl]);

  const isLiked = currentSong ? likedSongIds.has(currentSong.id) : false;
  const theme = useChromaTheme(currentSong?.id, currentSong?.coverUrl, thumbError);
  const effectiveDuration = duration > 0 ? duration : currentSong?.duration || 220;

  const displayedTime = jogPreviewTime !== null ? jogPreviewTime : currentTime;
  const progressPercent =
    effectiveDuration > 0 ? Math.min(100, Math.max(0, (displayedTime / effectiveDuration) * 100)) : 0;

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const pct = parseFloat(e.target.value);
    seek((pct / 100) * effectiveDuration);
  };

  const libraryList = queue.length > 0 ? queue : allSongs;

  return (
    <div className="w-full flex-1 min-h-0 flex flex-col justify-between px-4 pb-3 pt-0.5 sm:pb-5 select-none lg:grid lg:grid-cols-[400px_1fr] lg:gap-12 lg:items-center lg:px-8 lg:py-6">
      
      {/* Main Mobile / Left-Column Acrylic Deck */}
      <div className="w-full max-w-[368px] mx-auto flex flex-col items-center justify-evenly sm:justify-between flex-1 min-h-0 gap-2 sm:gap-3">
        
        {/* 1. Clear Acrylic Turntable, Polished Gold Tonearm, & Large Spinning CD */}
        <VinylTurntable
          isSidebarDropTarget={isSidebarDropTarget}
          onJogPreviewChange={setJogPreviewTime}
        />

        {/* 2. Title, Artist, Like Button & Library Menu */}
        <div className="w-full max-w-[340px] sm:max-w-[368px] space-y-1.5 sm:space-y-2.5 px-0.5 shrink-0">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0 flex-1">
              <h1 className="text-[17px] sm:text-xl font-semibold text-neutral-900 tracking-tight leading-tight truncate">
                {currentSong?.title || 'No Track Selected'}
              </h1>
              <p className="text-xs sm:text-[13px] font-normal text-neutral-500 truncate mt-0.5">
                {currentSong?.artist || 'Select a track to play'}
              </p>
            </div>

            <div className="flex items-center shrink-0">
              <button
                type="button"
                onClick={() => currentSong && toggleLikeSong(currentSong.id)}
                className={`min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full transition-colors cursor-pointer active:scale-95 ${
                  isLiked ? 'text-orange-600' : 'text-neutral-600 hover:text-neutral-900'
                }`}
                title={isLiked ? 'Remove from Liked Songs' : 'Save to Liked Songs'}
                aria-label={isLiked ? 'Unlike track' : 'Like track'}
              >
                <Heart className={`w-5 h-5 ${isLiked ? 'fill-orange-600' : ''}`} />
              </button>

              <button
                type="button"
                onClick={onOpenLibrary}
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full text-neutral-600 hover:text-neutral-900 hover:bg-black/[0.04] transition-colors cursor-pointer active:scale-95"
                title="Browse Library & Liked Songs"
                aria-label="Open Library and Search"
              >
                <MoreHorizontal className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* 3. One Draggable Seek Bar (shows live target timestamp during DJ jog wheel rotation) */}
          <div className="space-y-0.5 sm:space-y-1">
            <div className="relative w-full h-5 flex items-center group">
              <div className="w-full h-[3.5px] rounded-full bg-neutral-300/80 overflow-hidden">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${progressPercent}%`,
                    background: theme.scrubberGradient
                  }}
                />
              </div>

              <div
                className="absolute w-3.5 h-3.5 rounded-full pointer-events-none transition-transform group-hover:scale-125 border border-white"
                style={{
                  left: `clamp(0px, calc(${progressPercent}% - 7px), calc(100% - 14px))`,
                  backgroundColor: theme.primary,
                  boxShadow: theme.knobShadow
                }}
              />

              <input
                type="range"
                min="0"
                max="100"
                step="0.2"
                value={progressPercent}
                onChange={handleSeek}
                aria-label="Seek track position"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between text-[11px] font-medium tabular-nums">
              <span
                className={
                  jogPreviewTime !== null
                    ? 'text-orange-600 font-semibold'
                    : 'text-neutral-500'
                }
              >
                {formatTime(displayedTime)}
                {jogPreviewTime !== null ? ' · Jog' : ''}
              </span>

              <span className="text-neutral-500">
                {formatTime(effectiveDuration)}
              </span>
            </div>
          </div>
        </div>

        {/* 4. Mode-Aware Playback Controls */}
        <div className="w-full max-w-[340px] sm:max-w-[368px] flex items-center justify-between px-0.5 pt-0.5 shrink-0">
          {/* Shuffle */}
          <button
            type="button"
            onClick={toggleShuffle}
            className={`min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full transition-colors cursor-pointer ${
              isShuffle
                ? 'text-orange-600 bg-orange-600/10'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
            title="Shuffle"
            aria-label="Toggle shuffle"
          >
            <Shuffle className="w-4 h-4" />
          </button>

          {/* Previous */}
          <button
            type="button"
            onClick={() => playPrevious(true)}
            className="w-11 h-11 rounded-full bg-white/75 hover:bg-white border border-white shadow-[0_6px_16px_rgba(15,23,42,0.08),inset_0_1px_2px_rgba(255,255,255,1)] text-neutral-800 flex items-center justify-center transition-all cursor-pointer active:scale-95"
            title="Previous track"
            aria-label="Previous track"
          >
            <SkipBack className="w-4 h-4 fill-current" />
          </button>

          {/* Center Control: Large Play/Pause (DJ OFF) OR Needle Hint (DJ ON) */}
          {!djControlsEnabled ? (
            <button
              type="button"
              onClick={togglePlay}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-white/85 hover:bg-white border-2 border-orange-400/75 shadow-[0_8px_24px_rgba(234,88,12,0.22),inset_0_2px_4px_rgba(255,255,255,1)] text-neutral-900 flex items-center justify-center transition-all cursor-pointer active:scale-95"
              title={isPlaying ? 'Pause' : 'Play'}
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? (
                <Pause className="w-5 h-5 sm:w-6 sm:h-6 fill-current" />
              ) : (
                <Play className="w-5 h-5 sm:w-6 sm:h-6 fill-current ml-0.5" />
              )}
            </button>
          ) : (
            <button
              type="button"
              onClick={toggleNeedle}
              className="min-h-[44px] px-3 rounded-full bg-white/70 hover:bg-white border border-white shadow-[0_4px_12px_rgba(15,23,42,0.08)] text-[11px] sm:text-xs font-medium text-neutral-700 hover:text-orange-600 transition-colors cursor-pointer whitespace-nowrap"
            >
              {isNeedleDown ? 'Lift needle to pause' : 'Drop needle to play'}
            </button>
          )}

          {/* Next */}
          <button
            type="button"
            onClick={playNext}
            className="w-11 h-11 rounded-full bg-white/75 hover:bg-white border border-white shadow-[0_6px_16px_rgba(15,23,42,0.08),inset_0_1px_2px_rgba(255,255,255,1)] text-neutral-800 flex items-center justify-center transition-all cursor-pointer active:scale-95"
            title="Next track"
            aria-label="Next track"
          >
            <SkipForward className="w-4 h-4 fill-current" />
          </button>

          {/* Repeat */}
          <button
            type="button"
            onClick={toggleRepeat}
            className={`min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full transition-colors cursor-pointer ${
              repeatMode !== 'off'
                ? 'text-orange-600 bg-orange-600/10'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
            title={`Repeat: ${repeatMode}`}
            aria-label={`Repeat mode: ${repeatMode}`}
          >
            {repeatMode === 'one' ? (
              <Repeat1 className="w-4 h-4" />
            ) : (
              <Repeat className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* Desktop Studio Companion Library Panel */}
      <aside className="hidden lg:flex flex-col h-[580px] bg-white/60 border border-white/90 rounded-[28px] p-6 backdrop-blur-2xl shadow-[0_20px_50px_rgba(15,23,42,0.08)] overflow-hidden">
        <div className="flex items-center justify-between pb-4 border-b border-black/[0.06]">
          <div>
            <h2 className="text-base font-semibold text-neutral-900">Library & Queue</h2>
            <p className="text-xs text-neutral-500 mt-0.5">
              {libraryList.length} tracks · {djControlsEnabled ? 'DJ controls active' : 'Standard playback'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <PhoneFileScanner compact />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar py-3 space-y-1.5 pr-1">
          {libraryList.map((song, idx) => {
            const active = song.id === currentSong?.id;
            return (
              <button
                key={`${song.id}-desktop-${idx}`}
                type="button"
                onClick={() => (active ? togglePlay() : playSong(song, libraryList))}
                className={`w-full flex items-center justify-between gap-3 p-3 rounded-2xl text-left transition-all cursor-pointer ${
                  active
                    ? 'bg-white shadow-sm border border-orange-500/30'
                    : 'border border-transparent hover:bg-white/60'
                }`}
              >
                <div className="flex items-center gap-3.5 min-w-0 flex-1">
                  <span className="w-5 text-xs tabular-nums text-neutral-400 text-center shrink-0">
                    {idx + 1}
                  </span>

                  <div className="w-11 h-11 rounded-xl overflow-hidden border border-black/5 bg-neutral-200 shrink-0 flex items-center justify-center">
                    {song.coverUrl ? (
                      <img
                        src={song.coverUrl}
                        alt={song.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Disc3 className="w-5 h-5 text-neutral-500" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-semibold text-neutral-900 truncate">
                      {song.title}
                    </div>
                    <div className="text-xs text-neutral-500 truncate mt-0.5">
                      {song.artist} · {song.genre}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-xs tabular-nums text-neutral-500">
                    {song.durationFormatted}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      active
                        ? 'bg-orange-600 text-white'
                        : 'bg-black/[0.06] text-neutral-700'
                    }`}
                  >
                    {active && isPlaying ? (
                      <Pause className="w-3.5 h-3.5 fill-current" />
                    ) : (
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </aside>
    </div>
  );
};
