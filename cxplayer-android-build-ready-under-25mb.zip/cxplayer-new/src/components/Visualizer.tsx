import React from 'react';
import { motion } from 'motion/react';
import { useAudio } from '../context/AudioContext';

interface VisualizerProps {
  data?: number[];
  isPlaying?: boolean;
  barCount?: number;
  height?: number;
}

export const Visualizer: React.FC<VisualizerProps> = ({
  data,
  isPlaying,
  barCount = 20,
  height = 36,
}) => {
  const audio = useAudio();
  
  const activeData = data !== undefined ? data : (audio?.audioVisualizerData || []);
  const activePlaying = isPlaying !== undefined ? isPlaying : (audio?.isPlaying ?? false);
  const bars = (activeData || []).slice(0, barCount);

  return (
    <div className="flex items-end gap-[3px]" style={{ height: `${height}px` }}>
      {bars.map((value, idx) => (
        <motion.div
          key={idx}
          className="w-1 rounded-full bg-gradient-to-t from-purple-600 via-indigo-500 to-pink-400 shadow-[0_0_8px_rgba(168,85,247,0.5)]"
          animate={{
            height: activePlaying ? `${Math.max(10, value)}%` : '15%',
          }}
          transition={{
            type: 'spring',
            stiffness: 300,
            damping: 20,
          }}
        />
      ))}
    </div>
  );
};
