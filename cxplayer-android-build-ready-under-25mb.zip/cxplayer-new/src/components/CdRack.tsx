import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Disc3, 
  FolderPlus, 
  Search, 
  Sparkles, 
  HardDrive, 
  Heart, 
  Upload, 
  Music,
  Plus
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { CdItem } from './CdItem';
import { PhoneFileScanner } from './PhoneFileScanner';

export const CdRack: React.FC = () => {
  const { 
    allSongs, 
    currentSong, 
    loadCDToTurntable, 
    likedSongIds,
    isScanning,
    importAudioFiles
  } = useAudio();

  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'device' | 'favorites'>('all');

  const filteredSongs = useMemo(() => {
    return allSongs.filter((song) => {
      const matchesSearch =
        song.title.toLowerCase().includes(search.toLowerCase()) ||
        song.artist.toLowerCase().includes(search.toLowerCase()) ||
        (song.folderName && song.folderName.toLowerCase().includes(search.toLowerCase()));

      if (!matchesSearch) return false;
      if (filterType === 'device') return song.isLocal;
      if (filterType === 'favorites') return likedSongIds.has(song.id);
      return true;
    });
  }, [allSongs, search, filterType, likedSongIds]);

  return (
    <div className="space-y-5">
      {/* Rack Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-neutral-900/80 border border-white/10 shadow-lg backdrop-blur-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30">
              <Disc3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>CD & Vinyl Collection</span>
                <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-xs font-mono font-semibold border border-purple-500/30">
                  {allSongs.length} CDs
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Drag any CD to the center turntable deck and put the needle down to play.
              </p>
            </div>
          </div>
        </div>

        {/* Quick Add Audio Files Button */}
        <div className="flex items-center gap-2">
          <PhoneFileScanner compact />
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-neutral-900/60 border border-white/10 overflow-x-auto">
          {[
            { id: 'all', label: 'All CDs', count: allSongs.length },
            { id: 'device', label: 'Device Audio', count: allSongs.filter(s => s.isLocal).length },
            { id: 'favorites', label: 'Favorites', count: allSongs.filter(s => likedSongIds.has(s.id)).length }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                filterType === tab.id
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-neutral-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab.label} ({tab.count})
            </button>
          ))}
        </div>

        {/* Quick Search */}
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter CD collection..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-purple-500"
          />
        </div>
      </div>

      {/* CD Grid Display */}
      {filteredSongs.length === 0 ? (
        <div className="rounded-3xl bg-neutral-900/40 border border-dashed border-white/10 p-10 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-purple-600/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mx-auto">
            <Disc3 className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">No CDs Available</h3>
            <p className="text-xs text-neutral-400 max-w-md mx-auto">
              Select or drop audio files from your phone or device to generate physical interactive CDs.
            </p>
          </div>
          <div className="pt-2">
            <PhoneFileScanner />
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {filteredSongs.map((song) => (
            <CdItem
              key={song.id}
              song={song}
              isCurrent={currentSong?.id === song.id}
              onLoadToPlatter={(s) => loadCDToTurntable(s, false)}
            />
          ))}
        </div>
      )}
    </div>
  );
};
