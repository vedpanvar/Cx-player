import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, X, Music, Sparkles } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { SongRow } from './SongRow';

export const SearchView: React.FC = () => {
  const {
    searchQuery,
    setSearchQuery,
    allSongs,
    navigateTo
  } = useAudio();

  const query = searchQuery.trim().toLowerCase();

  // Filter songs based on search query
  const filteredSongs = allSongs.filter(
    (s) =>
      s.title.toLowerCase().includes(query) ||
      s.artist.toLowerCase().includes(query) ||
      (s.album && s.album.toLowerCase().includes(query)) ||
      (s.genre && s.genre.toLowerCase().includes(query)) ||
      (s.fileName && s.fileName.toLowerCase().includes(query)) ||
      (s.folderName && s.folderName.toLowerCase().includes(query))
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.2 }}
      className="space-y-6 pb-24"
    >
      {/* Search Header */}
      <div className="space-y-4">
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight flex items-center gap-2.5">
          <Search className="w-6 h-6 text-purple-400" />
          <span>Search</span>
        </h1>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-purple-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by track title, artist, album, folder or filename..."
            className="w-full pl-11 pr-10 py-3.5 rounded-2xl bg-white/5 border border-white/10 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-purple-500 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* When Search Query Exists */}
      {query ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-neutral-400 border-b border-white/10 pb-3">
            <span>Results for "{searchQuery}"</span>
            <span className="font-mono">{filteredSongs.length} track(s) found</span>
          </div>

          {filteredSongs.length === 0 ? (
            <div className="text-center py-16 text-neutral-400 space-y-2">
              <Music className="w-10 h-10 mx-auto text-neutral-600" />
              <p className="text-sm font-semibold text-white">No tracks match "{searchQuery}"</p>
              <p className="text-xs text-neutral-500">Check spelling or search for artist name or audio filename.</p>
            </div>
          ) : (
            <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-2 sm:p-3 divide-y divide-white/5">
              {filteredSongs.map((song, i) => (
                <SongRow
                  key={song.id}
                  song={song}
                  index={i}
                  songList={filteredSongs}
                />
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Empty State / Quick Search Overview */
        <div className="rounded-3xl bg-neutral-900/60 border border-white/5 p-8 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-purple-600/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mx-auto">
            <Search className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Search Your Library</h2>
            <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
              Type above to search through all {allSongs.length} audio tracks in your storage.
            </p>
          </div>
        </div>
      )}
    </motion.div>
  );
};
