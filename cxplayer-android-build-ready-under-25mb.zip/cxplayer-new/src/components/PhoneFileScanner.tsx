import React, { useRef, useState } from 'react';
import {
  FolderPlus,
  Upload,
  CheckCircle2,
  RefreshCw,
  Plus,
  Play,
  Trash2,
  Disc3
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';

interface PhoneFileScannerProps {
  compact?: boolean;
  onSongUploadedPlay?: () => void;
}

export const PhoneFileScanner: React.FC<PhoneFileScannerProps> = ({
  compact = false,
  onSongUploadedPlay
}) => {
  const {
    importAudioFiles,
    localSongs,
    isScanning,
    scanProgress,
    clearLocalLibrary,
    playSong,
    deleteSong,
    currentSong
  } = useAudio();

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const uploadedSongs = localSongs.filter((s) => s.id.startsWith('local-'));

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      e.target.value = '';
      await importAudioFiles(files);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await importAudioFiles(Array.from(e.dataTransfer.files));
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const triggerFolderSelect = () => {
    folderInputRef.current?.click();
  };

  const totalSizeBytes = uploadedSongs.reduce((acc, s) => acc + (s.fileSize || 0), 0);
  const totalSizeMB = (totalSizeBytes / (1024 * 1024)).toFixed(1);

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="audio/*,.mp3,.wav,.flac,.m4a,.m4b,.aac,.ogg,.opus,.wma"
          onChange={handleFileChange}
          className="hidden"
        />

        <button
          type="button"
          onClick={triggerFileSelect}
          disabled={isScanning}
          className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-orange-600 text-white hover:bg-orange-700 font-medium text-xs transition-colors cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
        >
          {isScanning ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Plus className="w-3.5 h-3.5" />
          )}
          <span>{isScanning ? 'Uploading...' : 'Upload Songs'}</span>
        </button>
      </div>
    );
  }

  return (
    <div className="w-full space-y-2.5">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="audio/*,.mp3,.wav,.flac,.m4a,.m4b,.aac,.ogg,.opus,.wma"
        onChange={handleFileChange}
        className="hidden"
      />
      <input
        ref={folderInputRef}
        type="file"
        {...({ webkitdirectory: '', directory: '' } as React.InputHTMLAttributes<HTMLInputElement>)}
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Upload Box */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
        className={`rounded-2xl border border-dashed transition-colors p-4 text-center ${
          isDragOver
            ? 'border-orange-500 bg-orange-50/70'
            : 'border-black/15 bg-white/80 hover:border-orange-400'
        }`}
      >
        <div className="flex flex-col items-center">
          <div className="w-10 h-10 rounded-full bg-orange-600/10 text-orange-600 flex items-center justify-center mb-2">
            <Upload className="w-5 h-5" />
          </div>
          <div className="text-sm font-semibold text-neutral-900">
            Upload songs from your device
          </div>
          <div className="text-xs text-neutral-500 mt-0.5">
            MP3, M4A, WAV, FLAC, AAC, OGG
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 mt-3 w-full">
            <button
              type="button"
              onClick={triggerFileSelect}
              disabled={isScanning}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-medium text-xs transition-colors cursor-pointer shadow-sm flex items-center gap-1.5"
            >
              {isScanning ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Upload className="w-3.5 h-3.5" />
              )}
              <span>{isScanning ? 'Uploading...' : 'Choose Songs'}</span>
            </button>

            <button
              type="button"
              onClick={triggerFolderSelect}
              disabled={isScanning}
              className="min-h-[42px] px-3.5 py-2 rounded-xl bg-white hover:bg-neutral-100 text-neutral-800 font-medium text-xs border border-black/10 transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <FolderPlus className="w-3.5 h-3.5 text-neutral-500" />
              <span>Upload Folder</span>
            </button>
          </div>
        </div>

        {/* Scanning Progress */}
        {isScanning && scanProgress && (
          <div className="mt-3 pt-3 border-t border-black/10 max-w-xs mx-auto">
            <div className="flex items-center justify-between text-xs text-neutral-600 mb-1">
              <span>Importing songs...</span>
              <span className="tabular-nums font-medium text-orange-600">
                {scanProgress.current} / {scanProgress.total}
              </span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-neutral-200 overflow-hidden">
              <div
                className="h-full bg-orange-600 rounded-full transition-all duration-200"
                style={{ width: `${(scanProgress.current / scanProgress.total) * 100}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* Uploaded Songs List */}
      {uploadedSongs.length > 0 && (
        <div className="rounded-2xl bg-white/80 border border-white shadow-sm p-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-neutral-800 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                {uploadedSongs.length} uploaded song{uploadedSongs.length === 1 ? '' : 's'}
                {totalSizeBytes > 0 ? ` · ${totalSizeMB} MB` : ''}
              </span>
            </div>

            <button
              type="button"
              onClick={clearLocalLibrary}
              className="px-2 py-1 rounded-lg text-neutral-500 hover:text-rose-600 font-medium transition-colors cursor-pointer"
            >
              Clear
            </button>
          </div>

          <div className="max-h-36 overflow-y-auto custom-scrollbar space-y-1 pr-0.5">
            {uploadedSongs.map((song) => {
              const isCurrent = currentSong?.id === song.id;
              return (
                <div
                  key={song.id}
                  className={`flex items-center justify-between gap-2 p-1.5 rounded-xl border ${
                    isCurrent
                      ? 'bg-orange-50/80 border-orange-200'
                      : 'bg-white/70 border-black/[0.04]'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      playSong(song);
                      onSongUploadedPlay?.();
                    }}
                    className="flex items-center gap-2 min-w-0 flex-1 text-left cursor-pointer"
                  >
                    <div className="w-8 h-8 rounded-lg overflow-hidden bg-neutral-200 border border-black/[0.05] shrink-0 flex items-center justify-center">
                      {song.coverUrl ? (
                        <img
                          src={song.coverUrl}
                          alt={song.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Disc3 className="w-4 h-4 text-neutral-500" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-semibold text-neutral-900 truncate">
                        {song.title}
                      </div>
                      <div className="text-[11px] text-neutral-500 truncate">
                        {song.artist} · {song.durationFormatted}
                      </div>
                    </div>
                  </button>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        playSong(song);
                        onSongUploadedPlay?.();
                      }}
                      className="w-8 h-8 rounded-full bg-orange-600/10 hover:bg-orange-600 text-orange-600 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                      aria-label={`Play ${song.title}`}
                    >
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteSong(song.id)}
                      className="w-8 h-8 rounded-full text-neutral-400 hover:text-rose-600 flex items-center justify-center transition-colors cursor-pointer"
                      aria-label={`Remove ${song.title}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
