import React, { useState } from 'react';
import { Smartphone, Download, Share } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallCard: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showSteps, setShowSteps] = useState(false);

  if (isInstalled) {
    return null;
  }

  return (
    <div className="p-3.5 sm:p-4 rounded-2xl bg-white/80 border border-white shadow-sm space-y-2.5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-start gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-orange-600/10 text-orange-600 flex items-center justify-center shrink-0">
            <Smartphone className="w-5 h-5" />
          </div>

          <div className="min-w-0">
            <div className="text-sm font-semibold text-neutral-900">Install on Phone</div>
            <p className="text-xs text-neutral-500 mt-0.5 leading-snug">
              Add Cxplayer to your home screen to launch full-screen like an app.
            </p>
          </div>
        </div>

        {isInstallable ? (
          <button
            type="button"
            onClick={install}
            className="min-h-[40px] px-3.5 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold flex items-center gap-1.5 shrink-0 cursor-pointer shadow-sm transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Install</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setShowSteps((prev) => !prev)}
            className="min-h-[40px] px-3 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-medium shrink-0 cursor-pointer transition-colors"
          >
            {showSteps ? 'Hide' : 'How to install'}
          </button>
        )}
      </div>

      {showSteps && !isInstallable && (
        <div className="pt-2.5 border-t border-black/[0.06] text-xs text-neutral-600 space-y-2 leading-relaxed">
          {isIOS ? (
            <p>
              <strong className="text-neutral-900">iPhone / iPad (Safari):</strong> Tap the{' '}
              <Share className="inline w-3.5 h-3.5 text-orange-600 mx-0.5" />{' '}
              <strong>Share</strong> button at the bottom, then choose{' '}
              <strong className="text-neutral-900">Add to Home Screen</strong>.
            </p>
          ) : (
            <>
              <p>
                <strong className="text-neutral-900">Android (Chrome):</strong> Open the{' '}
                <strong className="text-neutral-900">⋮</strong> browser menu and tap{' '}
                <strong className="text-neutral-900">Install app</strong> or{' '}
                <strong className="text-neutral-900">Add to Home screen</strong>.
              </p>
              <p>
                <strong className="text-neutral-900">iPhone (Safari):</strong> Tap{' '}
                <strong className="text-neutral-900">Share</strong> and choose{' '}
                <strong className="text-neutral-900">Add to Home Screen</strong>.
              </p>
            </>
          )}
        </div>
      )}
    </div>
  );
};
