import React from 'react';
import { motion } from 'motion/react';
import { Disc3, Play, Sparkles, Heart, Music2, Move } from 'lucide-react';
import { Song } from '../types';
import { useAudio } from '../context/AudioContext';

interface CdItemProps {
  song: Song;
  isCurrent?: boolean;
  onLoadToPlatter?: (song: Song) => void;
  compact?: boolean;
}

export const CdItem: React.FC<CdItemProps> = ({
  song,
  isCurrent = false,
  onLoadToPlatter,
  compact = false
}) => {
  const { loadCDToTurntable, toggleLikeSong, likedSongIds, isPlaying, isNeedleDown } = useAudio();
  const isLiked = likedSongIds.has(song.id);

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('text/plain', song.id);
    e.dataTransfer.setData('application/json', JSON.stringify(song));
    e.dataTransfer.effectAllowed = 'copyMove';

    // Set custom drag preview if available
    const img = new Image();
    img.src = song.coverUrl;
    try {
      e.dataTransfer.setDragImage(e.currentTarget, 60, 60);
    } catch {}
  };

  const handleLoad = () => {
    if (onLoadToPlatter) {
      onLoadToPlatter(song);
    } else {
      loadCDToTurntable(song, false);
    }
  };

  const formatExt = (song.fileType || song.fileName || 'mp3')
    .split('/')
    .pop()
    ?.toUpperCase()
    .replace('X-', '')
    .slice(0, 4) || 'CD';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -6 }}
      transition={{ duration: 0.2 }}
      draggable
      onDragStart={handleDragStart}
      onClick={handleLoad}
      className={`group relative rounded-2xl bg-neutral-900/90 border transition-all cursor-grab active:cursor-grabbing select-none overflow-hidden p-3 sm:p-4 flex flex-col items-center justify-between ${
        isCurrent
          ? 'border-purple-500 shadow-[0_0_25px_rgba(168,85,247,0.35)] ring-2 ring-purple-500/50'
          : 'border-white/10 hover:border-purple-500/40 hover:bg-neutral-850 shadow-xl'
      }`}
    >
      {/* Top badges */}
      <div className="w-full flex items-center justify-between z-10 mb-2.5">
        <span className="px-2 py-0.5 rounded-md bg-white/10 text-[10px] font-mono font-bold tracking-wider text-purple-300 border border-white/10 uppercase">
          {formatExt}
        </span>

        <div className="flex items-center gap-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleLikeSong(song.id);
            }}
            className={`p-1.5 rounded-lg transition-colors ${
              isLiked ? 'text-rose-500' : 'text-neutral-500 hover:text-white'
            }`}
            title="Favorite"
          >
            <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-500' : ''}`} />
          </button>

          <span className="text-[11px] font-mono text-neutral-400">
            {song.durationFormatted}
          </span>
        </div>
      </div>

      {/* Realistic CD Disc Visual Representation */}
      <div className="relative w-36 h-36 sm:w-40 sm:h-40 my-1 flex items-center justify-center">
        {/* Holographic Iridescent Outer CD Surface */}
        <div 
          className="relative w-full h-full rounded-full border-[3px] border-neutral-700/60 shadow-2xl flex items-center justify-center overflow-hidden transition-transform duration-500 group-hover:rotate-45"
          style={{
            background: 'radial-gradient(circle at 50% 50%, #1e1e24 0%, #2a2b32 40%, #121316 70%, #0a0a0c 100%)'
          }}
        >
          {/* Rainbow Spectral Laser Reflections */}
          <div 
            className="absolute inset-0 rounded-full opacity-60 group-hover:opacity-80 transition-opacity pointer-events-none"
            style={{
              background: 'conic-gradient(from 180deg at 50% 50%, rgba(255,0,128,0.25) 0deg, rgba(0,255,255,0.3) 60deg, rgba(255,255,0,0.25) 120deg, rgba(0,255,128,0.3) 180deg, rgba(147,51,234,0.3) 240deg, rgba(255,0,128,0.25) 360deg)'
            }}
          />

          {/* Micro Grooves */}
          <div className="absolute inset-3 rounded-full border border-white/10 pointer-events-none" />
          <div className="absolute inset-6 rounded-full border border-white/5 pointer-events-none" />
          <div className="absolute inset-9 rounded-full border border-white/10 pointer-events-none" />
          <div className="absolute inset-12 rounded-full border border-white/5 pointer-events-none" />

          {/* Circular Center Label with Album Art */}
          <div className="relative w-16 h-16 sm:w-18 sm:h-18 rounded-full overflow-hidden border-2 border-white/20 shadow-inner flex items-center justify-center bg-neutral-950 z-10">
            <img
              src={song.coverUrl}
              alt={song.title}
              className="w-full h-full object-cover pointer-events-none"
            />
            {/* Center Clear Ring and Spindle Hole */}
            <div className="absolute w-6 h-6 rounded-full bg-neutral-950/80 border border-neutral-600/80 flex items-center justify-center shadow-inner">
              <div className="w-2.5 h-2.5 rounded-full bg-neutral-900 border border-neutral-700 shadow-md" />
            </div>
          </div>
        </div>

        {/* Floating "DRAG TO PLAY" indicator on hover */}
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] rounded-full flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20 pointer-events-none">
          <div className="w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center shadow-lg transform scale-90 group-hover:scale-100 transition-transform mb-1">
            <Move className="w-5 h-5 animate-pulse" />
          </div>
          <span className="text-[10px] font-bold tracking-wider text-white uppercase drop-shadow">
            Drag to Center
          </span>
        </div>

        {/* Active playing indicator badge */}
        {isCurrent && (
          <div className="absolute -bottom-1 z-20 px-2.5 py-0.5 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center gap-1 shadow-lg">
            {isPlaying && isNeedleDown ? (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                <span>Spinning</span>
              </>
            ) : (
              <span>Loaded</span>
            )}
          </div>
        )}
      </div>

      {/* Song Info Text */}
      <div className="w-full text-center mt-2.5 space-y-0.5 z-10">
        <h3 className="font-bold text-xs sm:text-sm text-white truncate group-hover:text-purple-300 transition-colors">
          {song.title}
        </h3>
        <p className="text-[11px] text-neutral-400 truncate">
          {song.artist}
        </p>
      </div>

      {/* Direct Load Action Button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          handleLoad();
        }}
        className="mt-2.5 w-full py-1.5 px-3 rounded-xl bg-white/5 hover:bg-purple-600 text-neutral-300 hover:text-white border border-white/10 hover:border-purple-500 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
      >
        <Disc3 className="w-3.5 h-3.5 text-purple-400 group-hover:text-white" />
        <span>{isCurrent ? 'Mounted on Deck' : 'Load onto Player'}</span>
      </button>
    </motion.div>
  );
};
