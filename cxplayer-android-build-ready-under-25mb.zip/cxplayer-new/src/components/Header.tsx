import React, { useState } from 'react';
import {
  Search,
  Smartphone,
  Sliders,
  Sparkles,
  Command,
  Disc3,
  HardDrive
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { PhoneFileScanner } from './PhoneFileScanner';

export const Header: React.FC = () => {
  const {
    currentView,
    searchQuery,
    setSearchQuery,
    navigateTo,
    isPlaying,
    isNeedleDown,
    allSongs
  } = useAudio();

  const [showDeviceScanner, setShowDeviceScanner] = useState(false);

  return (
    <header className="sticky top-0 z-20 flex items-center justify-between px-6 py-4 bg-[#0a0b12]/80 backdrop-blur-xl border-b border-white/[0.06] gap-4">
      
      {/* Center Search Input with ⌘K Badge */}
      <div className="flex-1 max-w-xl">
        <div className="relative flex items-center group">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 group-focus-within:text-purple-400 transition-colors" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              if (currentView !== 'search' && e.target.value.trim().length > 0) {
                navigateTo('search');
              }
            }}
            placeholder="Search songs, albums, artists..."
            className="w-full pl-10 pr-12 py-2.5 rounded-2xl bg-white/[0.04] border border-white/[0.08] hover:border-white/15 focus:border-purple-500/50 text-white placeholder-neutral-400 text-sm focus:outline-none focus:ring-1 focus:ring-purple-500/50 focus:bg-white/[0.07] transition-all shadow-inner"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-white/[0.08] border border-white/[0.08] text-[10px] font-mono text-neutral-400 pointer-events-none">
            <span>⌘</span>
            <span>K</span>
          </div>
        </div>
      </div>

      {/* Right Actions: Device Importer, Spectrum & Profile Avatar */}
      <div className="flex items-center gap-3 shrink-0">
        
        {/* Device File Access Pill Button */}
        <div className="relative">
          <button
            onClick={() => setShowDeviceScanner(!showDeviceScanner)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-white/[0.04] hover:bg-purple-600/20 text-neutral-200 hover:text-white border border-white/[0.08] hover:border-purple-500/40 text-xs font-semibold transition-all cursor-pointer shadow-sm group"
          >
            <Smartphone className="w-4 h-4 text-purple-400 group-hover:scale-110 transition-transform" />
            <span>Device</span>
          </button>

          {/* Scanner Dropdown */}
          {showDeviceScanner && (
            <div className="absolute right-0 top-12 w-80 bg-neutral-950/95 border border-white/15 rounded-3xl p-4 shadow-2xl z-50 backdrop-blur-2xl">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-purple-400" />
                  <span>Import Phone Audio</span>
                </span>
                <button
                  onClick={() => setShowDeviceScanner(false)}
                  className="text-xs text-neutral-400 hover:text-white"
                >
                  ✕
                </button>
              </div>
              <PhoneFileScanner />
            </div>
          )}
        </div>

        {/* Animated Spectrum Equalizer Icon Button */}
        <button
          onClick={() => navigateTo('profile')}
          className="p-2.5 rounded-2xl bg-white/[0.04] hover:bg-purple-600/20 text-neutral-300 hover:text-purple-300 border border-white/[0.08] hover:border-purple-500/40 transition-all cursor-pointer flex items-end gap-1 h-9 shadow-sm"
          title="Audio Equalizer & Visualizer"
        >
          <span className={`w-1 bg-purple-400 rounded-full ${isPlaying && isNeedleDown ? 'h-full animate-pulse' : 'h-2'}`} />
          <span className={`w-1 bg-purple-400 rounded-full ${isPlaying && isNeedleDown ? 'h-3/4 animate-pulse delay-75' : 'h-3'}`} />
          <span className={`w-1 bg-purple-400 rounded-full ${isPlaying && isNeedleDown ? 'h-full animate-pulse delay-150' : 'h-4'}`} />
          <span className={`w-1 bg-purple-400 rounded-full ${isPlaying && isNeedleDown ? 'h-1/2 animate-pulse delay-100' : 'h-1.5'}`} />
        </button>

        {/* Profile Avatar */}
        <div 
          onClick={() => navigateTo('profile')}
          className="relative w-9 h-9 rounded-2xl overflow-hidden border border-purple-500/40 shadow-[0_0_15px_rgba(168,85,247,0.3)] cursor-pointer group"
          title="User Profile & Settings"
        >
          <img
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&q=80"
            alt="Profile Avatar"
            className="w-full h-full object-cover group-hover:scale-110 transition-transform"
          />
          <div className="absolute inset-0 bg-purple-600/10 group-hover:bg-transparent transition-colors" />
        </div>

      </div>

    </header>
  );
};
