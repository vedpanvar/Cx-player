import React from 'react';
import {
  Heart,
  MoreHorizontal,
  Volume2,
  VolumeX,
  Volume1,
  ListMusic,
  Maximize2
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { motion } from 'motion/react';

export const PlayerBar: React.FC = () => {
  const {
    currentSong,
    isPlaying,
    isNeedleDown,
    currentTime,
    duration,
    volume,
    isMuted,
    seek,
    setVolumeLevel,
    toggleMute,
    toggleLikeSong,
    likedSongIds,
    setIsNowPlayingOpen,
    isQueueOpen,
    setIsQueueOpen
  } = useAudio();

  if (!currentSong) return null;

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const isLiked = likedSongIds.has(currentSong.id);
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = (parseFloat(e.target.value) / 100) * duration;
    seek(newTime);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVolumeLevel(parseFloat(e.target.value));
  };

  // Generate stylized audio waveform bars
  const totalWaveBars = 36;
  const activeBars = Math.floor((currentTime / (duration || 1)) * totalWaveBars);

  return (
    <footer className="w-full bg-[#07080f]/95 backdrop-blur-2xl border-t border-white/[0.08] px-3.5 sm:px-5 py-2.5 select-none shadow-[0_-15px_40px_rgba(0,0,0,0.85)]">
      <div className="w-full flex flex-col gap-1.5">
        
        {/* Top Mini Waveform & Scrubber */}
        <div className="w-full flex flex-col items-center gap-1">
          {/* Audio Waveform Spectrum */}
          <div className="w-full flex items-end justify-center gap-[2.5px] h-4 px-1">
            {Array.from({ length: totalWaveBars }).map((_, i) => {
              const heightFactor = Math.sin((i / totalWaveBars) * Math.PI * 2) * 0.4 + Math.cos((i / totalWaveBars) * Math.PI * 4) * 0.3 + 0.5;
              const barHeight = Math.max(20, Math.min(100, heightFactor * 100));
              const isActive = i <= activeBars;

              return (
                <span
                  key={i}
                  className={`w-1 rounded-full transition-all duration-150 ${
                    isActive 
                      ? 'bg-gradient-to-t from-pink-500 via-purple-400 to-indigo-300 shadow-[0_0_8px_rgba(168,85,247,0.5)]' 
                      : 'bg-white/[0.1]'
                  }`}
                  style={{ 
                    height: `${barHeight}%`,
                    opacity: isPlaying && isNeedleDown && isActive ? 0.9 + Math.random() * 0.1 : isActive ? 0.8 : 0.35
                  }}
                />
              );
            })}
          </div>

          {/* Scrubber Timeline Bar */}
          <div className="w-full flex items-center gap-2 px-1">
            <span className="text-[10px] font-mono text-neutral-400 w-8 text-right">
              {formatTime(currentTime)}
            </span>

            <div className="relative flex-1 flex items-center">
              <input
                type="range"
                min="0"
                max="100"
                value={progressPercent}
                onChange={handleSeekChange}
                className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-purple-500 hover:h-1.5 transition-all"
              />
            </div>

            <span className="text-[10px] font-mono text-neutral-400 w-8">
              {formatTime(duration)}
            </span>
          </div>
        </div>

        {/* Bottom Row: Track Info + Quick Controls */}
        <div className="w-full flex items-center justify-between gap-3 pt-0.5">
          {/* Left Track Info */}
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div 
              onClick={() => setIsQueueOpen(true)}
              className="relative w-9 h-9 rounded-xl overflow-hidden border border-white/[0.12] bg-neutral-900 flex-shrink-0 cursor-pointer shadow-md group"
            >
              <img
                src={currentSong.coverUrl}
                alt={currentSong.title}
                className={`w-full h-full object-cover ${
                  isPlaying && isNeedleDown ? 'animate-spin-slow' : ''
                }`}
                style={{ animationDuration: '10s' }}
              />
            </div>

            <div className="min-w-0 flex-1">
              <div 
                onClick={() => setIsQueueOpen(true)}
                className="font-bold text-xs text-white truncate cursor-pointer hover:text-purple-300 transition-colors"
              >
                {currentSong.title}
              </div>
              <div className="text-[10.5px] text-neutral-400 truncate">
                {currentSong.artist}
              </div>
            </div>

            <button
              onClick={() => toggleLikeSong(currentSong.id)}
              className={`p-1.5 rounded-full transition-all cursor-pointer ${
                isLiked ? 'text-rose-500' : 'text-neutral-400 hover:text-white'
              }`}
              title="Like"
            >
              <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-500' : ''}`} />
            </button>
          </div>

          {/* Right Action: Queue Trigger & Volume */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={toggleMute}
              className="p-1.5 text-neutral-400 hover:text-white transition-colors"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-3.5 h-3.5 text-rose-400" />
              ) : (
                <Volume2 className="w-3.5 h-3.5" />
              )}
            </button>

            <button
              onClick={() => setIsQueueOpen(!isQueueOpen)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/40 text-[11px] font-semibold transition-all cursor-pointer"
            >
              <ListMusic className="w-3.5 h-3.5" />
              <span>Queue</span>
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
