import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { Song, ViewType, LibraryTab, RepeatMode, AudioFolder } from '../types';
import { parseAudioFile } from '../utils/audioMetadata';
import { 
  playNeedleDropSound, 
  playNeedleLiftSound, 
  playDiscInsertSound, 
  playDiscEjectSound 
} from '../utils/audioEffects';
import { INITIAL_DEMO_CDS, generateDemoAudioBuffer } from '../utils/sampleAudioGenerator';
import { PlayerController } from '../platform/PlayerController';
import { CrossPlatformStateSyncAdapter } from '../platform/StateSyncAdapter';
import { AudioTrackPayload, PersistedAppState, PlatformKind } from '../platform/types';

function toAudioPayload(song: Song): AudioTrackPayload {
  return {
    id: song.id,
    title: song.title,
    artist: song.artist,
    album: song.album,
    audioUrl: song.audioUrl || '',
    coverUrl: song.coverUrl,
    duration: song.duration
  };
}

interface AudioContextType {
  // Platform info & Cross-Platform Sync
  platform: PlatformKind;
  exportSyncState: () => string;
  importSyncState: (rawJson: string) => boolean;
  flushSyncState: () => Promise<void>;

  // Current playback state
  currentSong: Song | null;
  isPlaying: boolean;
  isNeedleDown: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  repeatMode: RepeatMode;
  playbackRate: number;
  pitchRate: number;
  setPitchRate: (rate: number) => void;
  
  // Turntable & CD Actions
  putNeedleDown: (seekRatio?: number) => void;
  liftNeedle: () => void;
  toggleNeedle: () => void;
  loadCDToTurntable: (song: Song, autoDropNeedle?: boolean) => void;
  swapDiscAndPlay: (song: Song) => void;
  ejectCD: () => void;

  // DJ Controls Mode (persisted, defaults to false)
  djControlsEnabled: boolean;
  setDjControlsEnabled: (enabled: boolean) => void;
  toggleDjControls: () => void;
  
  // Queue & Navigation
  queue: Song[];
  queueIndex: number;
  history: Song[];
  
  // Views & UI Modals
  currentView: ViewType;
  selectedEntityId: string | null;
  libraryTab: LibraryTab;
  isNowPlayingOpen: boolean;
  isQueueOpen: boolean;
  
  // Data State
  allSongs: Song[];
  localSongs: Song[];
  folders: AudioFolder[];
  likedSongIds: Set<string>;
  downloadedSongIds: Set<string>;
  searchQuery: string;
  downloadToast: string | null;
  isScanning: boolean;
  scanProgress: { current: number; total: number } | null;
  equalizerPreset: string;
  setEqualizerPreset: (preset: string) => void;
  
  // File System Access Actions
  importAudioFiles: (files: FileList | File[]) => Promise<number>;
  clearLocalLibrary: () => void;
  deleteSong: (songId: string) => void;
  
  // Player Actions
  playSong: (song: Song, newQueue?: Song[]) => void;
  togglePlay: () => void;
  pause: () => void;
  resume: () => void;
  seek: (time: number) => void;
  setVolumeLevel: (vol: number) => void;
  toggleMute: () => void;
  playNext: () => void;
  playPrevious: (forceSwitch?: boolean) => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  toggleLikeSong: (songId: string) => void;
  downloadSong: (song: Song) => void;
  
  // Queue Actions
  addToQueue: (song: Song) => void;
  removeFromQueue: (index: number) => void;
  clearQueue: () => void;
  
  // Navigation Actions
  navigateTo: (view: ViewType, entityId?: string) => void;
  setLibraryTab: (tab: LibraryTab) => void;
  setSearchQuery: (query: string) => void;
  setIsNowPlayingOpen: (open: boolean) => void;
  setIsQueueOpen: (open: boolean) => void;
  
  // Visualizer data & Web Audio
  audioVisualizerData: number[];
  getAnalyserNode: () => AnalyserNode | null;
  audioElement: HTMLAudioElement | null;

  // Sleep Timer & Theme
  sleepTimerSeconds: number | null;
  startSleepTimer: (minutes: number) => void;
  cancelSleepTimer: () => void;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
}

const AudioContext = createContext<AudioContextType | undefined>(undefined);

export const AudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation & UI state
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>(null);
  const [libraryTab, setLibraryTab] = useState<LibraryTab>('songs');
  const [searchQuery, setSearchQuery] = useState('');
  const [isNowPlayingOpen, setIsNowPlayingOpen] = useState(false);
  const [isQueueOpen, setIsQueueOpen] = useState(false);

  // Local phone audio files state + initial sample demo CDs
  const [localSongs, setLocalSongs] = useState<Song[]>(INITIAL_DEMO_CDS);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState<{ current: number; total: number } | null>(null);

  // Playback & Turntable Needle state
  const [currentSong, setCurrentSong] = useState<Song | null>(INITIAL_DEMO_CDS[0]);
  const [isNeedleDown, setIsNeedleDown] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(INITIAL_DEMO_CDS[0]?.duration || 25);
  const [volume, setVolume] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('off');
  const [pitchRate, setPitchRate] = useState(1.0);
  const [equalizerPreset, setEqualizerPreset] = useState('Flat');
  const [djControlsEnabled, setDjControlsEnabledState] = useState<boolean>(() => {
    try {
      return localStorage.getItem('cxplayer_dj_controls') === 'true';
    } catch {
      return false;
    }
  });

  const setDjControlsEnabled = (enabled: boolean) => {
    setDjControlsEnabledState(enabled);
    try {
      localStorage.setItem('cxplayer_dj_controls', String(enabled));
    } catch {}
    // Keep needle visuals synced with current playback state when switching modes
    setIsNeedleDown(isPlaying);
  };

  const toggleDjControls = () => {
    setDjControlsEnabled(!djControlsEnabled);
  };

  // Unified all songs
  const allSongs = localSongs;

  // Queue state
  const [queue, setQueue] = useState<Song[]>(INITIAL_DEMO_CDS);
  const [queueIndex, setQueueIndex] = useState(0);
  const [history, setHistory] = useState<Song[]>([]);

  // Persistent user state
  const [likedSongIds, setLikedSongIds] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('cxplayer_liked');
      if (saved) {
        const parsed = JSON.parse(saved);
        const valid = parsed.filter((id: string) => !id.startsWith('s') || id.length > 3);
        return new Set(valid);
      }
      return new Set();
    } catch {
      return new Set();
    }
  });

  const [downloadedSongIds, setDownloadedSongIds] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('cxplayer_downloads');
      return saved ? new Set(JSON.parse(saved)) : new Set([]);
    } catch {
      return new Set([]);
    }
  });

  const [downloadToast, setDownloadToast] = useState<string | null>(null);
  const [sleepTimerSeconds, setSleepTimerSeconds] = useState<number | null>(null);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Compute Folders from local audio files
  const folders: AudioFolder[] = React.useMemo(() => {
    const folderMap = new Map<string, Song[]>();
    
    localSongs.forEach((song) => {
      const folder = song.folderName || 'Internal Storage';
      if (!folderMap.has(folder)) {
        folderMap.set(folder, []);
      }
      folderMap.get(folder)!.push(song);
    });

    return Array.from(folderMap.entries()).map(([name, songs]) => ({
      id: `folder-${name.toLowerCase().replace(/\s+/g, '-')}`,
      name,
      songCount: songs.length,
      songs
    }));
  }, [localSongs]);

  const controllerRef = useRef<PlayerController | null>(null);
  const syncRef = useRef<CrossPlatformStateSyncAdapter | null>(null);
  const lastSyncTimestampRef = useRef<number>(0);
  const pendingRestoreTimeRef = useRef<number | null>(null);
  const hydratedRef = useRef(false);

  if (!controllerRef.current) {
    controllerRef.current = new PlayerController();
  }
  if (!syncRef.current) {
    syncRef.current = new CrossPlatformStateSyncAdapter();
  }

  const getAnalyserNode = useCallback((): AnalyserNode | null => {
    return controllerRef.current?.getAnalyserNode() ?? null;
  }, []);

  // Audio visualizer data
  const [audioVisualizerData, setAudioVisualizerData] = useState<number[]>(
    Array.from({ length: 24 }, () => 10)
  );

  // Sync legacy liked & downloaded localStorage keys for backward compatibility
  useEffect(() => {
    try {
      localStorage.setItem('cxplayer_liked', JSON.stringify(Array.from(likedSongIds)));
    } catch {}
  }, [likedSongIds]);

  useEffect(() => {
    try {
      localStorage.setItem('cxplayer_downloads', JSON.stringify(Array.from(downloadedSongIds)));
    } catch {}
  }, [downloadedSongIds]);

  const buildPersistedState = useCallback(
    (): PersistedAppState => ({
      version: 1,
      updatedAt: Date.now(),
      currentTrackId: currentSong?.id ?? null,
      currentTime,
      queueTrackIds: queue.map((s) => s.id),
      queueIndex,
      likedSongIds: Array.from(likedSongIds),
      downloadedSongIds: Array.from(downloadedSongIds),
      djControlsEnabled,
      volume,
      isMuted,
      isShuffle,
      repeatMode,
      pitchRate,
      equalizerPreset
    }),
    [
      currentSong?.id,
      currentTime,
      queue,
      queueIndex,
      likedSongIds,
      downloadedSongIds,
      djControlsEnabled,
      volume,
      isMuted,
      isShuffle,
      repeatMode,
      pitchRate,
      equalizerPreset
    ]
  );

  const buildPersistedStateRef = useRef(buildPersistedState);
  buildPersistedStateRef.current = buildPersistedState;

  const applyPersistedState = useCallback(
    (saved: PersistedAppState) => {
      lastSyncTimestampRef.current = saved.updatedAt;
      setDjControlsEnabledState(Boolean(saved.djControlsEnabled));
      try {
        localStorage.setItem('cxplayer_dj_controls', String(Boolean(saved.djControlsEnabled)));
      } catch {}
      setLikedSongIds(new Set(saved.likedSongIds || []));
      setDownloadedSongIds(new Set(saved.downloadedSongIds || []));
      if (typeof saved.volume === 'number') setVolume(Math.max(0, Math.min(1, saved.volume)));
      if (typeof saved.isMuted === 'boolean') setIsMuted(saved.isMuted);
      if (typeof saved.isShuffle === 'boolean') setIsShuffle(saved.isShuffle);
      if (saved.repeatMode === 'off' || saved.repeatMode === 'all' || saved.repeatMode === 'one') {
        setRepeatMode(saved.repeatMode);
      }
      if (typeof saved.pitchRate === 'number') setPitchRate(saved.pitchRate);
      if (saved.equalizerPreset) setEqualizerPreset(saved.equalizerPreset);

      if (saved.currentTrackId) {
        const match = localSongs.find((s) => s.id === saved.currentTrackId);
        if (match) {
          setCurrentSong(match);
          const idx = queue.findIndex((q) => q.id === match.id);
          if (idx !== -1) setQueueIndex(idx);
          if (typeof saved.currentTime === 'number' && saved.currentTime > 0) {
            pendingRestoreTimeRef.current = saved.currentTime;
            setCurrentTime(saved.currentTime);
          }
        }
      }
    },
    [localSongs, queue]
  );

  // Hydrate persisted state on mount and listen to cross-tab updates
  useEffect(() => {
    const sync = syncRef.current;
    if (!sync) return;

    let mounted = true;
    void sync.load().then((saved) => {
      if (!mounted) return;
      if (saved) {
        applyPersistedState(saved);
      }
      hydratedRef.current = true;
    });

    const unsub = sync.subscribe((incoming) => {
      if (incoming.updatedAt > lastSyncTimestampRef.current) {
        applyPersistedState(incoming);
      }
    });

    return () => {
      mounted = false;
      unsub();
    };
  }, []);

  // Persist shared settings & playback metadata when changed
  useEffect(() => {
    if (!hydratedRef.current || !syncRef.current) return;
    const state = buildPersistedState();
    lastSyncTimestampRef.current = state.updatedAt;
    const timer = setTimeout(() => {
      void syncRef.current?.save(state);
    }, 300);
    return () => clearTimeout(timer);
  }, [
    djControlsEnabled,
    likedSongIds,
    downloadedSongIds,
    volume,
    isMuted,
    isShuffle,
    repeatMode,
    pitchRate,
    equalizerPreset,
    currentSong?.id,
    queueIndex
  ]);

  const flushSyncState = useCallback(async () => {
    if (!syncRef.current) return;
    const state = buildPersistedStateRef.current();
    lastSyncTimestampRef.current = state.updatedAt;
    await syncRef.current.save(state);
  }, []);

  // Wire PlayerController events (Web + Native Android MediaSession / Service)
  const playNextRef = useRef<() => void>(() => {});
  const playPreviousRef = useRef<(forceSwitch?: boolean) => void>(() => {});
  const togglePlayRef = useRef<() => void>(() => {});
  const liftNeedleRef = useRef<() => void>(() => {});

  useEffect(() => {
    const controller = controllerRef.current;
    if (!controller) return;

    const unsubTime = controller.on('timeupdate', (ct) => {
      setCurrentTime(ct);
    });
    const unsubMeta = controller.on('loadedmetadata', (dur) => {
      if (dur > 0 && !isNaN(dur)) {
        setDuration(dur);
      }
      if (pendingRestoreTimeRef.current !== null) {
        const restoreAt = pendingRestoreTimeRef.current;
        pendingRestoreTimeRef.current = null;
        void controller.seek(restoreAt);
      }
    });
    const unsubEnded = controller.on('ended', () => {
      playNextRef.current();
    });
    const unsubPlay = controller.on('play', () => {
      if (controller.platform === 'android') {
        setIsPlaying(true);
        setIsNeedleDown(true);
      }
    });
    const unsubPause = controller.on('pause', () => {
      if (controller.platform === 'android') {
        setIsPlaying(false);
        setIsNeedleDown(false);
      }
    });
    const unsubRemoteNext = controller.on('remoteNext', () => {
      playNextRef.current();
    });
    const unsubRemotePrev = controller.on('remotePrevious', () => {
      playPreviousRef.current();
    });
    const unsubRemoteToggle = controller.on('remoteTogglePlay', () => {
      togglePlayRef.current();
    });
    const unsubFocusLost = controller.on('audioFocusLost', () => {
      liftNeedleRef.current();
    });
    const unsubError = controller.on('error', () => {
      setIsPlaying(false);
    });

    return () => {
      unsubTime();
      unsubMeta();
      unsubEnded();
      unsubPlay();
      unsubPause();
      unsubRemoteNext();
      unsubRemotePrev();
      unsubRemoteToggle();
      unsubFocusLost();
      unsubError();
      controller.dispose();
    };
  }, []);

  // Preload synthesized audio buffers for initial demo CDs
  useEffect(() => {
    let isMounted = true;
    async function initDemoAudio() {
      try {
        const types: Array<'lofi' | 'synthwave' | 'jazz'> = ['lofi', 'synthwave', 'jazz'];
        const updated = await Promise.all(
          INITIAL_DEMO_CDS.map(async (cd, idx) => {
            if (!cd.audioUrl) {
              const url = await generateDemoAudioBuffer(types[idx % types.length]);
              return { ...cd, audioUrl: url };
            }
            return cd;
          })
        );
        if (isMounted) {
          setLocalSongs((prev) => {
            if (prev.length === INITIAL_DEMO_CDS.length && prev[0]?.id === INITIAL_DEMO_CDS[0].id) {
              return updated;
            }
            return prev;
          });
          setQueue((prev) => {
            if (prev.length === INITIAL_DEMO_CDS.length && prev[0]?.id === INITIAL_DEMO_CDS[0].id) {
              return updated;
            }
            return prev;
          });
          setCurrentSong((prev) => {
            if (prev && !prev.audioUrl) {
              const match = updated.find((u) => u.id === prev.id);
              return match || prev;
            }
            return prev;
          });
        }
      } catch (err) {
        console.warn('Demo audio synthesis deferred:', err);
      }
    }
    void initDemoAudio();
    return () => {
      isMounted = false;
    };
  }, []);

  // Sleep Timer Interval
  useEffect(() => {
    if (sleepTimerSeconds === null || sleepTimerSeconds <= 0) return;

    const timer = setInterval(() => {
      setSleepTimerSeconds((prev) => {
        if (prev === null || prev <= 1) {
          liftNeedleRef.current();
          setDownloadToast('Sleep timer expired. Playback paused.');
          setTimeout(() => setDownloadToast(null), 3000);
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [sleepTimerSeconds]);

  // Synchronize PlayerController track source
  useEffect(() => {
    const controller = controllerRef.current;
    if (!controller || !currentSong?.audioUrl) return;
    void controller.loadTrack(toAudioPayload(currentSong));
  }, [currentSong]);

  useEffect(() => {
    const controller = controllerRef.current;
    if (!controller) return;
    void controller.setPlaybackRate(pitchRate);
  }, [pitchRate]);

  useEffect(() => {
    const controller = controllerRef.current;
    if (!controller) return;
    if (isPlaying) {
      void controller.play();
    } else {
      void controller.pause();
    }
  }, [isPlaying]);

  useEffect(() => {
    const controller = controllerRef.current;
    if (!controller) return;
    void controller.setVolume(volume);
  }, [volume]);

  useEffect(() => {
    const controller = controllerRef.current;
    if (!controller) return;
    void controller.setMuted(isMuted);
  }, [isMuted]);

  // Dynamic visualizer animation loop
  useEffect(() => {
    let animId: number;
    const updateVisualizer = () => {
      if (isPlaying) {
        setAudioVisualizerData(
          Array.from({ length: 24 }, () => Math.floor(Math.random() * 85) + 15)
        );
      } else {
        setAudioVisualizerData(Array.from({ length: 24 }, () => 8));
      }
      animId = requestAnimationFrame(updateVisualizer);
    };

    if (isPlaying) {
      animId = requestAnimationFrame(updateVisualizer);
    } else {
      setAudioVisualizerData(Array.from({ length: 24 }, () => 8));
    }

    return () => cancelAnimationFrame(animId);
  }, [isPlaying]);

  // Local Audio File Import
  const importAudioFiles = async (files: FileList | File[]): Promise<number> => {
    setIsScanning(true);
    const fileArray = Array.from(files).filter((file) => {
      const ext = file.name.split('.').pop()?.toLowerCase();
      return (
        ['mp3', 'wav', 'flac', 'aac', 'm4a', 'm4b', 'ogg', 'opus', 'wma', 'webm', 'aiff'].includes(
          ext || ''
        ) || file.type.startsWith('audio/')
      );
    });

    if (fileArray.length === 0) {
      setIsScanning(false);
      setDownloadToast('No supported audio files found (MP3, WAV, FLAC, M4A, AAC, OGG).');
      setTimeout(() => setDownloadToast(null), 3000);
      return 0;
    }

    setScanProgress({ current: 0, total: fileArray.length });
    const parsedSongs: Song[] = [];

    for (let i = 0; i < fileArray.length; i++) {
      const file = fileArray[i];
      try {
        const song = await parseAudioFile(file);
        parsedSongs.push(song);
      } catch (err) {
        console.warn('Failed parsing audio metadata for:', file.name, err);
      }
      setScanProgress({ current: i + 1, total: fileArray.length });
    }

    if (parsedSongs.length > 0) {
      setLocalSongs((prev) => [...parsedSongs, ...prev]);
      setQueue((prev) => [...parsedSongs, ...prev]);

      if (!isPlaying) {
        setQueueIndex(0);
        setCurrentSong(parsedSongs[0]);
        setCurrentTime(0);
        setDuration(parsedSongs[0].duration || 180);
      } else {
        setQueueIndex((prev) => prev + parsedSongs.length);
      }

      setDownloadToast(
        parsedSongs.length === 1
          ? `Uploaded "${parsedSongs[0].title}" to deck.`
          : `Uploaded ${parsedSongs.length} songs to library.`
      );
    } else {
      setDownloadToast('Could not read selected audio file(s).');
    }

    setIsScanning(false);
    setScanProgress(null);
    setTimeout(() => setDownloadToast(null), 3000);

    return parsedSongs.length;
  };

  const clearLocalLibrary = () => {
    setLocalSongs((prev) => {
      const remaining = prev.filter((s) => !s.id.startsWith('local-'));
      return remaining.length > 0 ? remaining : INITIAL_DEMO_CDS;
    });
    setQueue((prev) => {
      const remaining = prev.filter((s) => !s.id.startsWith('local-'));
      return remaining.length > 0 ? remaining : INITIAL_DEMO_CDS;
    });
    if (currentSong?.id.startsWith('local-')) {
      const fallback = localSongs.find((s) => !s.id.startsWith('local-')) || INITIAL_DEMO_CDS[0];
      if (fallback) {
        setCurrentSong(fallback);
        setCurrentTime(0);
        setDuration(fallback.duration || 180);
        setIsPlaying(false);
        setIsNeedleDown(false);
        setQueueIndex(0);
      }
    }
    setDownloadToast('Uploaded songs cleared.');
    setTimeout(() => setDownloadToast(null), 2500);
  };

  const deleteSong = (songId: string) => {
    setLocalSongs((prev) => prev.filter((s) => s.id !== songId));
    setQueue((prev) => prev.filter((s) => s.id !== songId));
    if (currentSong?.id === songId) {
      playNext();
    }
  };

  // Turntable & Needle Handlers
  const putNeedleDown = (seekRatio?: number) => {
    if (!currentSong && allSongs.length > 0) {
      loadCDToTurntable(allSongs[0], true);
      return;
    }
    if (!currentSong) return;

    if (seekRatio !== undefined && duration > 0) {
      const targetTime = Math.max(0, Math.min(duration, duration * seekRatio));
      seek(targetTime);
    }

    playNeedleDropSound();
    setIsNeedleDown(true);
    setIsPlaying(true);
    getAnalyserNode();
  };

  const liftNeedle = () => {
    playNeedleLiftSound();
    setIsNeedleDown(false);
    setIsPlaying(false);
  };
  liftNeedleRef.current = liftNeedle;

  const toggleNeedle = () => {
    if (djControlsEnabled ? isNeedleDown : isPlaying) {
      liftNeedle();
    } else {
      putNeedleDown();
    }
  };

  const loadCDToTurntable = (song: Song, autoDropNeedle: boolean = false) => {
    playDiscInsertSound();

    const existingIdx = queue.findIndex((s) => s.id === song.id);
    if (existingIdx !== -1) {
      setQueueIndex(existingIdx);
    } else {
      setQueue((prev) => [song, ...prev]);
      setQueueIndex(0);
    }

    if (currentSong && currentSong.id !== song.id) {
      setHistory((prev) => [currentSong, ...prev.slice(0, 20)]);
    }

    pendingRestoreTimeRef.current = null;
    if (controllerRef.current && song.audioUrl) {
      void controllerRef.current.loadTrack(toAudioPayload(song), true);
      void controllerRef.current.seek(0);
    }

    setCurrentSong(song);
    setCurrentTime(0);
    setDuration(song.duration || 180);

    if (autoDropNeedle) {
      playNeedleDropSound();
      setIsNeedleDown(true);
      setIsPlaying(true);
      getAnalyserNode();
    } else {
      setIsNeedleDown(false);
      setIsPlaying(false);
    }

    setDownloadToast(`CD Mounted: "${song.title}"`);
    setTimeout(() => setDownloadToast(null), 2500);
  };

  const swapTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const swapDiscAndPlay = (song: Song) => {
    if (swapTimerRef.current) {
      clearTimeout(swapTimerRef.current);
      swapTimerRef.current = null;
    }

    // Unlock audio context synchronously on user gesture (web only)
    getAnalyserNode();

    const existingIdx = queue.findIndex((s) => s.id === song.id);
    if (existingIdx !== -1) {
      setQueueIndex(existingIdx);
    } else {
      setQueue((prev) => [song, ...prev]);
      setQueueIndex(0);
    }

    if (currentSong && currentSong.id !== song.id) {
      setHistory((prev) => [currentSong, ...prev.slice(0, 20)]);
    }

    pendingRestoreTimeRef.current = null;
    if (controllerRef.current && song.audioUrl) {
      void controllerRef.current.loadTrack(toAudioPayload(song), true);
      void controllerRef.current.seek(0);
    }

    if (djControlsEnabled) {
      // Lift needle for disc swap, mount new artwork & start playback, then lower needle
      setIsNeedleDown(false);
      setIsPlaying(false);
      playDiscInsertSound();
      setCurrentSong(song);
      setCurrentTime(0);
      setDuration(song.duration || 180);

      swapTimerRef.current = setTimeout(() => {
        setIsPlaying(true);
        setIsNeedleDown(true);
        playNeedleDropSound();
        swapTimerRef.current = null;
      }, 260);
    } else {
      playDiscInsertSound();
      setCurrentSong(song);
      setCurrentTime(0);
      setDuration(song.duration || 180);
      setIsNeedleDown(true);
      setIsPlaying(true);
    }
  };

  const ejectCD = () => {
    if (!currentSong) return;
    playDiscEjectSound();
    setIsNeedleDown(false);
    setIsPlaying(false);
    setCurrentSong(null);
    setCurrentTime(0);
    setDownloadToast('CD ejected back to collection.');
    setTimeout(() => setDownloadToast(null), 2500);
  };

  // Playback Control Handlers
  const playSong = (song: Song, newQueue?: Song[]) => {
    if (newQueue && newQueue.length > 0) {
      setQueue(newQueue);
      const idx = newQueue.findIndex((s) => s.id === song.id);
      setQueueIndex(idx !== -1 ? idx : 0);
    } else {
      const existingIdx = queue.findIndex((s) => s.id === song.id);
      if (existingIdx !== -1) {
        setQueueIndex(existingIdx);
      } else {
        setQueue((prev) => [song, ...prev]);
        setQueueIndex(0);
      }
    }

    if (currentSong && currentSong.id !== song.id) {
      setHistory((prev) => [currentSong, ...prev.slice(0, 20)]);
    }

    pendingRestoreTimeRef.current = null;
    if (controllerRef.current && song.audioUrl) {
      void controllerRef.current.loadTrack(toAudioPayload(song), true);
      void controllerRef.current.seek(0);
    }

    setCurrentSong(song);
    setCurrentTime(0);
    setDuration(song.duration || 180);
    setIsNeedleDown(true);
    setIsPlaying(true);
    playNeedleDropSound();
    getAnalyserNode();
  };

  const togglePlay = () => {
    if (!currentSong && allSongs.length > 0) {
      loadCDToTurntable(allSongs[0], true);
      return;
    }
    toggleNeedle();
  };
  togglePlayRef.current = togglePlay;

  const pause = () => setIsPlaying(false);
  const resume = () => {
    setIsPlaying(true);
    getAnalyserNode();
  };

  const seek = (time: number) => {
    const controller = controllerRef.current;
    const ctrlDuration = controller?.getDuration() || 0;
    const maxDur = duration > 0 ? duration : ctrlDuration;
    const clamped = maxDur > 0 ? Math.max(0, Math.min(maxDur, time)) : Math.max(0, time);
    setCurrentTime(clamped);
    if (controller) {
      void controller.seek(clamped);
    }
  };

  const setVolumeLevel = (vol: number) => {
    const clamped = Math.max(0, Math.min(1, vol));
    setVolume(clamped);
    if (isMuted && clamped > 0) {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    setIsMuted((prev) => !prev);
  };

  const playNext = () => {
    if (queue.length === 0) return;

    if (repeatMode === 'one') {
      seek(0);
      setIsNeedleDown(true);
      setIsPlaying(true);
      return;
    }

    const keepPlaying = isPlaying;

    if (isShuffle && queue.length > 1) {
      let randomIdx = Math.floor(Math.random() * queue.length);
      if (randomIdx === queueIndex) {
        randomIdx = (queueIndex + 1) % queue.length;
      }
      setQueueIndex(randomIdx);
      loadCDToTurntable(queue[randomIdx], keepPlaying);
      return;
    }

    const nextIndex = (queueIndex + 1) % queue.length;
    setQueueIndex(nextIndex);
    loadCDToTurntable(queue[nextIndex], keepPlaying);
  };

  playNextRef.current = playNext;

  const playPrevious = (forceSwitch: boolean = false) => {
    if (queue.length === 0) return;

    if (!forceSwitch && currentTime > 3) {
      seek(0);
      return;
    }

    const keepPlaying = isPlaying;
    const prevIndex = (queueIndex - 1 + queue.length) % queue.length;
    setQueueIndex(prevIndex);
    loadCDToTurntable(queue[prevIndex], keepPlaying);
  };
  playPreviousRef.current = playPrevious;

  const toggleShuffle = () => {
    setIsShuffle((prev) => !prev);
  };

  const toggleRepeat = () => {
    setRepeatMode((prev) => {
      if (prev === 'off') return 'all';
      if (prev === 'all') return 'one';
      return 'off';
    });
  };

  const toggleLikeSong = (songId: string) => {
    setLikedSongIds((prev) => {
      const next = new Set(prev);
      if (next.has(songId)) {
        next.delete(songId);
      } else {
        next.add(songId);
      }
      return next;
    });
  };

  const downloadSong = (song: Song) => {
    setDownloadedSongIds((prev) => {
      const next = new Set(prev);
      if (next.has(song.id)) {
        next.delete(song.id);
        setDownloadToast(`Removed "${song.title}" from downloads.`);
      } else {
        next.add(song.id);
        setDownloadToast(`Saved "${song.title}" for offline playback.`);
      }
      return next;
    });

    setTimeout(() => {
      setDownloadToast(null);
    }, 2500);
  };

  const addToQueue = (song: Song) => {
    setQueue((prev) => [...prev, song]);
    setDownloadToast(`Added "${song.title}" to playback queue.`);
    setTimeout(() => setDownloadToast(null), 2000);
  };

  const removeFromQueue = (index: number) => {
    setQueue((prev) => prev.filter((_, i) => i !== index));
    if (index < queueIndex) {
      setQueueIndex((prev) => Math.max(0, prev - 1));
    }
  };

  const clearQueue = () => {
    if (currentSong) {
      setQueue([currentSong]);
      setQueueIndex(0);
    } else {
      setQueue([]);
      setQueueIndex(0);
    }
  };

  const navigateTo = (view: ViewType, entityId?: string) => {
    setCurrentView(view);
    if (entityId) {
      setSelectedEntityId(entityId);
    } else {
      setSelectedEntityId(null);
    }
    const mainEl = document.getElementById('main-content');
    if (mainEl) {
      mainEl.scrollTop = 0;
    }
  };

  const startSleepTimer = (minutes: number) => {
    setSleepTimerSeconds(minutes * 60);
    setDownloadToast(`Sleep timer set for ${minutes} minutes.`);
    setTimeout(() => setDownloadToast(null), 3000);
  };

  const cancelSleepTimer = () => {
    setSleepTimerSeconds(null);
    setDownloadToast('Sleep timer cancelled.');
    setTimeout(() => setDownloadToast(null), 2000);
  };

  const toggleTheme = () => {
    setTheme((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      localStorage.setItem('cxplayer_theme', next);
      return next;
    });
  };

  const exportSyncState = useCallback((): string => {
    const state = buildPersistedStateRef.current();
    return syncRef.current?.exportJson(state) || JSON.stringify(state, null, 2);
  }, []);

  const importSyncState = useCallback(
    (rawJson: string): boolean => {
      const parsed = syncRef.current?.importJson(rawJson);
      if (!parsed) {
        setDownloadToast('Invalid Cxplayer sync profile JSON.');
        setTimeout(() => setDownloadToast(null), 2500);
        return false;
      }
      const stamped: PersistedAppState = { ...parsed, updatedAt: Date.now() };
      applyPersistedState(stamped);
      void syncRef.current?.save(stamped);
      setDownloadToast('Synced preferences and playlists imported.');
      setTimeout(() => setDownloadToast(null), 2500);
      return true;
    },
    [applyPersistedState]
  );

  return (
    <AudioContext.Provider
      value={{
        platform: controllerRef.current.platform,
        exportSyncState,
        importSyncState,
        flushSyncState,
        currentSong,
        isPlaying,
        isNeedleDown,
        currentTime,
        duration,
        volume,
        isMuted,
        isShuffle,
        repeatMode,
        playbackRate: pitchRate,
        pitchRate,
        setPitchRate,
        putNeedleDown,
        liftNeedle,
        toggleNeedle,
        loadCDToTurntable,
        swapDiscAndPlay,
        ejectCD,
        djControlsEnabled,
        setDjControlsEnabled,
        toggleDjControls,
        queue,
        queueIndex,
        history,
        currentView,
        selectedEntityId,
        libraryTab,
        isNowPlayingOpen,
        isQueueOpen,
        allSongs,
        localSongs,
        folders,
        likedSongIds,
        downloadedSongIds,
        searchQuery,
        downloadToast,
        isScanning,
        scanProgress,
        equalizerPreset,
        setEqualizerPreset,
        importAudioFiles,
        clearLocalLibrary,
        deleteSong,
        playSong,
        togglePlay,
        pause,
        resume,
        seek,
        setVolumeLevel,
        toggleMute,
        playNext,
        playPrevious,
        toggleShuffle,
        toggleRepeat,
        toggleLikeSong,
        downloadSong,
        addToQueue,
        removeFromQueue,
        clearQueue,
        navigateTo,
        setLibraryTab,
        setSearchQuery,
        setIsNowPlayingOpen,
        setIsQueueOpen,
        audioVisualizerData,
        getAnalyserNode,
        audioElement: controllerRef.current.getAudioElement(),
        sleepTimerSeconds,
        startSleepTimer,
        cancelSleepTimer,
        theme,
        toggleTheme,
      }}
    >
      {children}
    </AudioContext.Provider>
  );
};

export const useAudio = () => {
  const context = useContext(AudioContext);
  if (!context) {
    throw new Error('useAudio must be used within an AudioProvider');
  }
  return context;
};
