export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  durationFormatted: string; // e.g. "3:42"
  coverUrl: string;
  genre: string;
  plays: number;
  likesCount?: string;
  playsCount?: string;
  bitrate?: string;
  audioUrl?: string; // MP3 URL or Blob URL
  releaseYear: number;
  lyrics?: string[];
  isExplicit?: boolean;
  isLocal?: boolean;
  fileSize?: number;
  fileType?: string;
  folderName?: string;
  fileName?: string;
}

export interface AudioFolder {
  id: string;
  name: string;
  songCount: number;
  songs: Song[];
}

export interface Album {
  id: string;
  title: string;
  artist: string;
  coverUrl: string;
  year: number;
  genre: string;
  songIds: string[];
}

export interface Artist {
  id: string;
  name: string;
  avatarUrl: string;
  bannerUrl: string;
  genres: string[];
  monthlyListeners: number;
  bio: string;
  popularSongIds: string[];
  albums: Album[];
}

export type ViewType = 
  | 'home'
  | 'player'
  | 'turntable'
  | 'tracks'
  | 'albums'
  | 'artists'
  | 'folders'
  | 'playlists'
  | 'liked'
  | 'favorites'
  | 'equalizer'
  | 'search'
  | 'library'
  | 'recent'
  | 'top-rated'
  | 'most-played'
  | 'downloads'
  | 'album'
  | 'artist'
  | 'profile';

export type LibraryTab = 'songs' | 'liked' | 'albums' | 'artists' | 'downloads' | 'local';

export type RepeatMode = 'off' | 'all' | 'one';

export interface GenreCategory {
  id: string;
  name: string;
  color: string;
  coverUrl: string;
}

