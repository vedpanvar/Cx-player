import { Song, Album, Artist, GenreCategory } from '../types';

export const MOCK_SONGS: Song[] = [];

export const MOCK_GENRES: GenreCategory[] = [];

export const MOCK_ALBUMS: Album[] = [];

export const MOCK_ARTISTS: Artist[] = [];
