import { useState, useEffect } from 'react';

export interface ChromaTheme {
  id: string;
  primary: string;
  secondary: string;
  accentBg: string;
  scrubberGradient: string;
  knobShadow: string;
  rimTint: string;
  ambientGlow: string;
}

export const BURNT_ORANGE_DEFAULT: ChromaTheme = {
  id: 'burnt-orange-acrylic',
  primary: '#ea580c',
  secondary: '#f97316',
  accentBg: 'rgba(234, 88, 12, 0.14)',
  scrubberGradient: 'linear-gradient(90deg, #c2410c 0%, #ea580c 55%, #fb923c 100%)',
  knobShadow: '0 0 10px rgba(234, 88, 12, 0.65)',
  rimTint: 'rgba(234, 88, 12, 0.35)',
  ambientGlow: 'rgba(234, 88, 12, 0.12)'
};

export const NEUTRAL_ACRYLIC_THEME: ChromaTheme = {
  id: 'neutral-acrylic',
  primary: '#71717a',
  secondary: '#a1a1aa',
  accentBg: 'rgba(113, 113, 122, 0.12)',
  scrubberGradient: 'linear-gradient(90deg, #52525b 0%, #71717a 60%, #a1a1aa 100%)',
  knobShadow: '0 0 8px rgba(82, 82, 91, 0.45)',
  rimTint: 'rgba(161, 161, 170, 0.35)',
  ambientGlow: 'rgba(161, 161, 170, 0.12)'
};

const CURATED_THEMES: Record<string, ChromaTheme> = {
  'song-after-hours': BURNT_ORANGE_DEFAULT,
  'song-city-lights': {
    id: 'city-lights',
    primary: '#ea580c',
    secondary: '#fb923c',
    accentBg: 'rgba(234, 88, 12, 0.14)',
    scrubberGradient: 'linear-gradient(90deg, #c2410c 0%, #ea580c 55%, #fb923c 100%)',
    knobShadow: '0 0 10px rgba(234, 88, 12, 0.65)',
    rimTint: 'rgba(249, 115, 22, 0.35)',
    ambientGlow: 'rgba(251, 146, 60, 0.14)'
  },
  'song-amber-run': {
    id: 'amber-run',
    primary: '#d97706',
    secondary: '#f59e0b',
    accentBg: 'rgba(217, 119, 6, 0.15)',
    scrubberGradient: 'linear-gradient(90deg, #b45309 0%, #d97706 55%, #fbbf24 100%)',
    knobShadow: '0 0 10px rgba(217, 119, 6, 0.65)',
    rimTint: 'rgba(245, 158, 11, 0.4)',
    ambientGlow: 'rgba(245, 158, 11, 0.16)'
  },
  'song-late-coast': {
    id: 'late-coast',
    primary: '#0d9488',
    secondary: '#14b8a6',
    accentBg: 'rgba(13, 148, 136, 0.14)',
    scrubberGradient: 'linear-gradient(90deg, #0f766e 0%, #0d9488 55%, #2dd4bf 100%)',
    knobShadow: '0 0 10px rgba(13, 148, 136, 0.6)',
    rimTint: 'rgba(20, 184, 166, 0.35)',
    ambientGlow: 'rgba(20, 184, 166, 0.14)'
  },
  'song-glass-roads': {
    id: 'glass-roads',
    primary: '#c2410c',
    secondary: '#f59e0b',
    accentBg: 'rgba(194, 65, 12, 0.14)',
    scrubberGradient: 'linear-gradient(90deg, #9a3412 0%, #ea580c 55%, #fbbf24 100%)',
    knobShadow: '0 0 10px rgba(234, 88, 12, 0.6)',
    rimTint: 'rgba(234, 88, 12, 0.35)',
    ambientGlow: 'rgba(245, 158, 11, 0.14)'
  },
  'song-morning-signal': {
    id: 'morning-signal',
    primary: '#0284c7',
    secondary: '#06b6d4',
    accentBg: 'rgba(2, 132, 199, 0.14)',
    scrubberGradient: 'linear-gradient(90deg, #0369a1 0%, #0284c7 55%, #22d3ee 100%)',
    knobShadow: '0 0 10px rgba(2, 132, 199, 0.6)',
    rimTint: 'rgba(6, 182, 212, 0.35)',
    ambientGlow: 'rgba(6, 182, 212, 0.14)'
  }
};

const extractedCache = new Map<string, ChromaTheme>();

function buildThemeFromRgb(r: number, g: number, b: number, id: string): ChromaTheme {
  const dr = Math.max(0, Math.round(r * 0.8));
  const dg = Math.max(0, Math.round(g * 0.8));
  const db = Math.max(0, Math.round(b * 0.8));
  const lr = Math.min(255, Math.round(r + (255 - r) * 0.25));
  const lg = Math.min(255, Math.round(g + (255 - g) * 0.25));
  const lb = Math.min(255, Math.round(b + (255 - b) * 0.25));

  return {
    id,
    primary: `rgb(${r}, ${g}, ${b})`,
    secondary: `rgb(${lr}, ${lg}, ${lb})`,
    accentBg: `rgba(${r}, ${g}, ${b}, 0.14)`,
    scrubberGradient: `linear-gradient(90deg, rgb(${dr}, ${dg}, ${db}) 0%, rgb(${r}, ${g}, ${b}) 55%, rgb(${lr}, ${lg}, ${lb}) 100%)`,
    knobShadow: `0 0 10px rgba(${r}, ${g}, ${b}, 0.65)`,
    rimTint: `rgba(${r}, ${g}, ${b}, 0.35)`,
    ambientGlow: `rgba(${r}, ${g}, ${b}, 0.14)`
  };
}

export function useChromaTheme(songId?: string, coverUrl?: string, hasCoverError?: boolean): ChromaTheme {
  const [dynamicTheme, setDynamicTheme] = useState<ChromaTheme>(() => {
    if (hasCoverError || !coverUrl) return NEUTRAL_ACRYLIC_THEME;
    if (songId && CURATED_THEMES[songId]) return CURATED_THEMES[songId];
    if (extractedCache.has(coverUrl)) return extractedCache.get(coverUrl)!;
    return BURNT_ORANGE_DEFAULT;
  });

  useEffect(() => {
    if (hasCoverError || !coverUrl) {
      setDynamicTheme(NEUTRAL_ACRYLIC_THEME);
      return;
    }

    if (songId && CURATED_THEMES[songId]) {
      setDynamicTheme(CURATED_THEMES[songId]);
      return;
    }

    if (extractedCache.has(coverUrl)) {
      setDynamicTheme(extractedCache.get(coverUrl)!);
      return;
    }

    let cancelled = false;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (cancelled) return;
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 16;
        canvas.height = 16;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.drawImage(img, 0, 0, 16, 16);
        const data = ctx.getImageData(0, 0, 16, 16).data;

        let bestR = 234;
        let bestG = 88;
        let bestB = 12;
        let bestScore = -1;

        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const max = Math.max(r, g, b);
          const min = Math.min(r, g, b);
          const saturation = max === 0 ? 0 : (max - min) / max;
          const brightness = (r + g + b) / 3;

          if (brightness < 40 || brightness > 225) continue;
          const score = saturation * 2.2 + (1 - Math.abs(brightness - 130) / 130) * 0.6;
          if (score > bestScore) {
            bestScore = score;
            bestR = r;
            bestG = g;
            bestB = b;
          }
        }

        const theme = bestScore > 0.25
          ? buildThemeFromRgb(bestR, bestG, bestB, `extracted-${songId || 'track'}`)
          : NEUTRAL_ACRYLIC_THEME;

        extractedCache.set(coverUrl, theme);
        setDynamicTheme(theme);
      } catch {
        setDynamicTheme(NEUTRAL_ACRYLIC_THEME);
      }
    };
    img.onerror = () => {
      if (!cancelled) setDynamicTheme(NEUTRAL_ACRYLIC_THEME);
    };
    img.src = coverUrl;

    return () => {
      cancelled = true;
    };
  }, [songId, coverUrl, hasCoverError]);

  return dynamicTheme;
}
