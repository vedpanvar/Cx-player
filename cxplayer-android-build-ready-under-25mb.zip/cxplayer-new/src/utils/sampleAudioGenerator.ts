import { Song } from '../types';
import afterHoursCover from '../assets/images/album_after_hours_1795621788392.jpg';
import cityLightsCover from '../assets/images/album_city_lights_1795624007558.jpg';
import amberRunCover from '../assets/images/album_amber_run_1795624007678.jpg';
import lateCoastCover from '../assets/images/album_late_coast_1795624008211.jpg';
import glassRoadsCover from '../assets/images/album_glass_roads_1795621789178.jpg';
import morningSignalCover from '../assets/images/album_morning_signal_1795621789318.jpg';

/**
 * Generates playable Audio Blobs for demo CDs using Web Audio API offline rendering.
 */
export async function generateDemoAudioBuffer(type: 'lofi' | 'synthwave' | 'jazz'): Promise<string> {
  const sampleRate = 44100;
  const duration = 30;
  const offlineCtx = new OfflineAudioContext(2, sampleRate * duration, sampleRate);

  const tempo = type === 'lofi' ? 76 : type === 'synthwave' ? 112 : 90;
  const beatDuration = 60 / tempo;

  const masterGain = offlineCtx.createGain();
  masterGain.gain.setValueAtTime(0.7, 0);

  const lowpass = offlineCtx.createBiquadFilter();
  lowpass.type = type === 'lofi' ? 'lowpass' : 'peaking';
  lowpass.frequency.setValueAtTime(type === 'lofi' ? 3200 : 8000, 0);

  masterGain.connect(lowpass);
  lowpass.connect(offlineCtx.destination);

  const chordFrequencies = type === 'lofi'
    ? [
        [261.63, 329.63, 392.00, 493.88],
        [220.00, 261.63, 329.63, 392.00],
        [174.61, 220.00, 261.63, 329.63],
        [196.00, 246.94, 293.66, 349.23],
      ]
    : type === 'synthwave'
    ? [
        [146.83, 220.00, 293.66, 369.99],
        [110.00, 164.81, 220.00, 261.63],
        [130.81, 196.00, 261.63, 329.63],
        [174.61, 220.00, 261.63, 349.23],
      ]
    : [
        [207.65, 261.63, 311.13, 392.00],
        [185.00, 233.08, 277.18, 349.23],
        [155.56, 196.00, 233.08, 293.66],
        [174.61, 220.00, 261.63, 329.63],
      ];

  const totalBars = Math.floor(duration / (beatDuration * 4));

  for (let bar = 0; bar < totalBars; bar++) {
    const chord = chordFrequencies[bar % chordFrequencies.length];
    const startTime = bar * beatDuration * 4;

    chord.forEach((freq) => {
      const osc = offlineCtx.createOscillator();
      const gain = offlineCtx.createGain();

      osc.type = type === 'synthwave' ? 'sawtooth' : 'sine';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.001, startTime);
      gain.gain.linearRampToValueAtTime(0.08, startTime + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + beatDuration * 3.8);

      osc.connect(gain);
      gain.connect(masterGain);

      osc.start(startTime);
      osc.stop(startTime + beatDuration * 4);
    });

    const bassOsc = offlineCtx.createOscillator();
    const bassGain = offlineCtx.createGain();
    bassOsc.type = 'triangle';
    bassOsc.frequency.setValueAtTime(chord[0] / 2, startTime);
    bassGain.gain.setValueAtTime(0.18, startTime);
    bassGain.gain.exponentialRampToValueAtTime(0.01, startTime + beatDuration * 3.5);
    bassOsc.connect(bassGain);
    bassGain.connect(masterGain);
    bassOsc.start(startTime);
    bassOsc.stop(startTime + beatDuration * 4);

    for (let beat = 0; beat < 4; beat++) {
      const beatTime = startTime + beat * beatDuration;

      if (beat === 0 || beat === 2) {
        const kickOsc = offlineCtx.createOscillator();
        const kickGain = offlineCtx.createGain();
        kickOsc.frequency.setValueAtTime(130, beatTime);
        kickOsc.frequency.exponentialRampToValueAtTime(35, beatTime + 0.12);
        kickGain.gain.setValueAtTime(0.35, beatTime);
        kickGain.gain.exponentialRampToValueAtTime(0.001, beatTime + 0.14);
        kickOsc.connect(kickGain);
        kickGain.connect(masterGain);
        kickOsc.start(beatTime);
        kickOsc.stop(beatTime + 0.15);
      }

      if (beat === 1 || beat === 3) {
        const snareNoise = offlineCtx.createBufferSource();
        const noiseBuffer = offlineCtx.createBuffer(1, sampleRate * 0.1, sampleRate);
        const output = noiseBuffer.getChannelData(0);
        for (let i = 0; i < sampleRate * 0.1; i++) {
          output[i] = Math.random() * 2 - 1;
        }
        snareNoise.buffer = noiseBuffer;
        const snareGain = offlineCtx.createGain();
        snareGain.gain.setValueAtTime(0.16, beatTime);
        snareGain.gain.exponentialRampToValueAtTime(0.001, beatTime + 0.1);
        snareNoise.connect(snareGain);
        snareGain.connect(masterGain);
        snareNoise.start(beatTime);
        snareNoise.stop(beatTime + 0.11);
      }
    }
  }

  const renderedBuffer = await offlineCtx.startRendering();
  const wavBlob = audioBufferToWavBlob(renderedBuffer);
  return URL.createObjectURL(wavBlob);
}

function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numOfChan = buffer.numberOfChannels;
  const length = buffer.length * numOfChan * 2 + 44;
  const outBuffer = new ArrayBuffer(length);
  const view = new DataView(outBuffer);
  const channels: Float32Array[] = [];
  let sample = 0;
  let offset = 0;
  let pos = 0;

  function setUint16(data: number) {
    view.setUint16(pos, data, true);
    pos += 2;
  }
  function setUint32(data: number) {
    view.setUint32(pos, data, true);
    pos += 4;
  }

  setUint32(0x46464952);
  setUint32(length - 8);
  setUint32(0x45564157);

  setUint32(0x20746d66);
  setUint32(16);
  setUint16(1);
  setUint16(numOfChan);
  setUint32(buffer.sampleRate);
  setUint32(buffer.sampleRate * 2 * numOfChan);
  setUint16(numOfChan * 2);
  setUint16(16);

  setUint32(0x61746164);
  setUint32(length - pos - 4);

  for (let i = 0; i < buffer.numberOfChannels; i++) {
    channels.push(buffer.getChannelData(i));
  }

  while (pos < length) {
    for (let i = 0; i < numOfChan; i++) {
      sample = Math.max(-1, Math.min(1, channels[i][offset]));
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
      view.setInt16(pos, sample, true);
      pos += 2;
    }
    offset++;
  }

  return new Blob([outBuffer], { type: 'audio/wav' });
}

export const INITIAL_DEMO_CDS: Song[] = [
  {
    id: 'song-after-hours',
    title: 'After Hours',
    artist: 'Lumen Drive',
    album: 'Neon Overpass',
    duration: 268,
    durationFormatted: '4:28',
    coverUrl: afterHoursCover,
    genre: 'Synthwave / Ambient',
    plays: 532000,
    playsCount: '532K',
    likesCount: '12.4K',
    bitrate: 'FLAC 24-bit',
    releaseYear: 2025,
    isLocal: true,
    fileType: 'audio/wav',
    folderName: 'Favorites'
  },
  {
    id: 'song-city-lights',
    title: 'City Lights',
    artist: 'Velvet Roads',
    album: 'Dusk Towers',
    duration: 236,
    durationFormatted: '3:56',
    coverUrl: cityLightsCover,
    genre: 'Dream Pop',
    plays: 645000,
    playsCount: '645K',
    likesCount: '24.1K',
    bitrate: 'FLAC 24-bit',
    releaseYear: 2025,
    isLocal: true,
    fileType: 'audio/wav',
    folderName: 'City Mix'
  },
  {
    id: 'song-amber-run',
    title: 'Amber Run',
    artist: 'Phase North',
    album: 'Sunlit Dunes',
    duration: 250,
    durationFormatted: '4:10',
    coverUrl: amberRunCover,
    genre: 'Ambient Electronic',
    plays: 710000,
    playsCount: '710K',
    likesCount: '31.8K',
    bitrate: 'FLAC 24-bit',
    releaseYear: 2025,
    isLocal: true,
    fileType: 'audio/wav',
    folderName: 'Golden Hour'
  },
  {
    id: 'song-late-coast',
    title: 'Late Coast',
    artist: 'Mirage Suite',
    album: 'Shoreline',
    duration: 227,
    durationFormatted: '3:47',
    coverUrl: lateCoastCover,
    genre: 'Chillwave',
    plays: 498000,
    playsCount: '498K',
    likesCount: '18.7K',
    bitrate: 'FLAC 24-bit',
    releaseYear: 2025,
    isLocal: true,
    fileType: 'audio/wav',
    folderName: 'Coastline'
  },
  {
    id: 'song-glass-roads',
    title: 'Glass Roads',
    artist: 'Velvet Orbit',
    album: 'Sunbeam Avenue',
    duration: 237,
    durationFormatted: '3:57',
    coverUrl: glassRoadsCover,
    genre: 'Downtempo / Indie',
    plays: 890000,
    playsCount: '890K',
    likesCount: '45.2K',
    bitrate: 'FLAC 24-bit',
    releaseYear: 2025,
    isLocal: true,
    fileType: 'audio/wav',
    folderName: 'Golden Hour'
  },
  {
    id: 'song-morning-signal',
    title: 'Morning Signal',
    artist: 'Lumen Bay',
    album: 'Tidal Horizon',
    duration: 316,
    durationFormatted: '5:16',
    coverUrl: morningSignalCover,
    genre: 'Electronic',
    plays: 1240000,
    playsCount: '1.2M',
    likesCount: '88.1K',
    bitrate: 'FLAC 24-bit',
    releaseYear: 2025,
    isLocal: true,
    fileType: 'audio/wav',
    folderName: 'Coastline'
  }
];
