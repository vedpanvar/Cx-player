import { Song } from '../types';

/**
 * Parses ID3 tags (v2.3/v2.4) and audio metadata directly in the browser.
 */
export async function parseAudioFile(file: File): Promise<Song> {
  const id = `local-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  const objectUrl = URL.createObjectURL(file);
  
  // Default metadata from filename
  const cleanName = file.name.replace(/\.[^/.]+$/, '');
  let title = cleanName;
  let artist = 'Local Audio';
  let album = 'Device Music';
  let year = new Date().getFullYear();
  let genre = getFormatFromFilename(file.name).toUpperCase();
  let coverUrl = '';

  // Parse "Artist - Title" filename convention if present
  if (cleanName.includes(' - ')) {
    const parts = cleanName.split(' - ');
    if (parts.length >= 2) {
      artist = parts[0].trim().replace(/^\d+[\s.-]*/, ''); // strip track numbers
      title = parts.slice(1).join(' - ').trim();
    }
  } else {
    // Strip leading track numbers like "01. " or "01 - "
    title = cleanName.replace(/^\d+[\s.-]*/, '').trim() || cleanName;
  }

  // Attempt ID3 Tag parsing from file ArrayBuffer
  try {
    const buffer = await file.slice(0, Math.min(file.size, 512 * 1024)).arrayBuffer();
    const id3 = parseID3Tags(buffer);
    if (id3.title) title = id3.title;
    if (id3.artist) artist = id3.artist;
    if (id3.album) album = id3.album;
    if (id3.year) year = id3.year;
    if (id3.genre) genre = id3.genre;
    if (id3.coverUrl) coverUrl = id3.coverUrl;
  } catch (err) {
    console.warn('ID3 parsing skipped:', err);
  }

  // Leave coverUrl empty when no embedded artwork exists so the neutral glass skin is used

  // Get duration using temporary Audio element
  const duration = await getAudioDuration(objectUrl);

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const folder = file.webkitRelativePath 
    ? file.webkitRelativePath.split('/')[0] 
    : 'Phone Storage';

  return {
    id,
    title,
    artist,
    album: album || folder,
    duration: Math.round(duration) || 180,
    durationFormatted: formatSeconds(duration || 180),
    coverUrl,
    genre: genre || 'Local Track',
    plays: 0,
    audioUrl: objectUrl,
    releaseYear: year,
    isLocal: true,
    fileSize: file.size,
    fileType: file.type || `audio/${getFormatFromFilename(file.name)}`,
    folderName: folder,
    fileName: file.name
  };
}

function getFormatFromFilename(name: string): string {
  const ext = name.split('.').pop()?.toLowerCase();
  return ext || 'audio';
}

function getAudioDuration(url: string): Promise<number> {
  return new Promise((resolve) => {
    const audio = new Audio();
    audio.preload = 'metadata';
    audio.src = url;
    
    const cleanup = () => {
      audio.removeEventListener('loadedmetadata', onLoaded);
      audio.removeEventListener('error', onError);
    };

    const onLoaded = () => {
      const dur = audio.duration;
      cleanup();
      resolve(isNaN(dur) || !isFinite(dur) ? 180 : dur);
    };

    const onError = () => {
      cleanup();
      resolve(180);
    };

    audio.addEventListener('loadedmetadata', onLoaded);
    audio.addEventListener('error', onError);

    // Timeout safety
    setTimeout(() => {
      cleanup();
      resolve(180);
    }, 2000);
  });
}

interface ParsedID3 {
  title?: string;
  artist?: string;
  album?: string;
  year?: number;
  genre?: string;
  coverUrl?: string;
}

function parseID3Tags(buffer: ArrayBuffer): ParsedID3 {
  const result: ParsedID3 = {};
  const view = new DataView(buffer);

  // Check for ID3v2 header: 'ID3'
  if (
    buffer.byteLength > 10 &&
    view.getUint8(0) === 0x49 &&
    view.getUint8(1) === 0x44 &&
    view.getUint8(2) === 0x33
  ) {
    const version = view.getUint8(3); // 3 or 4
    const flags = view.getUint8(5);
    const hasExtendedHeader = (flags & 0x40) !== 0;

    // Synchsafe integer for ID3 total size
    const tagSize =
      ((view.getUint8(6) & 0x7f) << 21) |
      ((view.getUint8(7) & 0x7f) << 14) |
      ((view.getUint8(8) & 0x7f) << 7) |
      (view.getUint8(9) & 0x7f);

    let offset = 10;
    if (hasExtendedHeader && offset + 4 < buffer.byteLength) {
      const extSize = view.getUint32(offset);
      offset += extSize;
    }

    const maxOffset = Math.min(buffer.byteLength, 10 + tagSize);

    while (offset + 10 < maxOffset) {
      const frameID = String.fromCharCode(
        view.getUint8(offset),
        view.getUint8(offset + 1),
        view.getUint8(offset + 2),
        view.getUint8(offset + 3)
      );

      // Check for valid frame ID characters (A-Z, 0-9)
      if (!/^[A-Z0-9]{4}$/.test(frameID)) {
        break;
      }

      let frameSize = 0;
      if (version === 4) {
        // ID3v2.4 synchsafe
        frameSize =
          ((view.getUint8(offset + 4) & 0x7f) << 21) |
          ((view.getUint8(offset + 5) & 0x7f) << 14) |
          ((view.getUint8(offset + 6) & 0x7f) << 7) |
          (view.getUint8(offset + 7) & 0x7f);
      } else {
        // ID3v2.3 standard 32-bit uint
        frameSize = view.getUint32(offset + 4);
      }

      if (frameSize <= 0 || offset + 10 + frameSize > buffer.byteLength) {
        break;
      }

      const frameDataOffset = offset + 10;
      const frameBytes = new Uint8Array(buffer, frameDataOffset, frameSize);

      if (frameID === 'TIT2') {
        result.title = decodeTextFrame(frameBytes);
      } else if (frameID === 'TPE1') {
        result.artist = decodeTextFrame(frameBytes);
      } else if (frameID === 'TALB') {
        result.album = decodeTextFrame(frameBytes);
      } else if (frameID === 'TYER' || frameID === 'TDRC') {
        const yStr = decodeTextFrame(frameBytes);
        const yNum = parseInt(yStr.substring(0, 4), 10);
        if (!isNaN(yNum)) result.year = yNum;
      } else if (frameID === 'TCON') {
        result.genre = decodeTextFrame(frameBytes).replace(/^\(\d+\)/, '');
      } else if (frameID === 'APIC') {
        try {
          const cover = parseAPICFrame(frameBytes);
          if (cover) result.coverUrl = cover;
        } catch {}
      }

      offset += 10 + frameSize;
    }
  }

  return result;
}

function decodeTextFrame(bytes: Uint8Array): string {
  if (bytes.length === 0) return '';
  const encoding = bytes[0];
  const content = bytes.subarray(1);

  try {
    if (encoding === 1 || encoding === 2) {
      // UTF-16
      const decoder = new TextDecoder(encoding === 1 ? 'utf-16' : 'utf-16be');
      return decoder.decode(content).replace(/\0+$/, '').trim();
    } else if (encoding === 3) {
      // UTF-8
      const decoder = new TextDecoder('utf-8');
      return decoder.decode(content).replace(/\0+$/, '').trim();
    } else {
      // ISO-8859-1 / ASCII
      const decoder = new TextDecoder('iso-8859-1');
      return decoder.decode(content).replace(/\0+$/, '').trim();
    }
  } catch {
    return '';
  }
}

function parseAPICFrame(bytes: Uint8Array): string | null {
  if (bytes.length < 10) return null;
  const encoding = bytes[0];
  let offset = 1;

  // Read MIME type (null-terminated ASCII)
  let mimeType = '';
  while (offset < bytes.length && bytes[offset] !== 0) {
    mimeType += String.fromCharCode(bytes[offset]);
    offset++;
  }
  offset++; // skip null byte

  if (!mimeType) mimeType = 'image/jpeg';
  if (mimeType === '-->') mimeType = 'image/jpeg';

  // Skip Picture type byte
  if (offset < bytes.length) offset++;

  // Skip Description (null-terminated according to encoding)
  if (encoding === 1 || encoding === 2) {
    // 2 null bytes for UTF-16
    while (offset + 1 < bytes.length && !(bytes[offset] === 0 && bytes[offset + 1] === 0)) {
      offset += 2;
    }
    offset += 2;
  } else {
    while (offset < bytes.length && bytes[offset] !== 0) {
      offset++;
    }
    offset++;
  }

  if (offset >= bytes.length) return null;

  const imageBytes = bytes.subarray(offset);
  const blob = new Blob([imageBytes], { type: mimeType });
  return URL.createObjectURL(blob);
}

const GRADIENT_PALETTES = [
  ['#6366f1', '#a855f7', '#ec4899'],
  ['#3b82f6', '#2dd4bf', '#10b981'],
  ['#8b5cf6', '#d946ef', '#f43f5e'],
  ['#f59e0b', '#ef4444', '#7c3aed'],
  ['#06b6d4', '#3b82f6', '#6366f1'],
  ['#10b981', '#059669', '#047857'],
  ['#ec4899', '#f43f5e', '#be123c'],
  ['#14b8a6', '#06b6d4', '#0284c7']
];

function generateCoverArtGradient(title: string, artist: string): string {
  let hash = 0;
  const str = `${title}-${artist}`;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  const palette = GRADIENT_PALETTES[Math.abs(hash) % GRADIENT_PALETTES.length];
  
  // Create an SVG vinyl artwork data URI
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${palette[0]}"/>
        <stop offset="50%" stop-color="${palette[1]}"/>
        <stop offset="100%" stop-color="${palette[2]}"/>
      </linearGradient>
      <radialGradient id="v" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#000000" stop-opacity="0.8"/>
        <stop offset="60%" stop-color="#18181b" stop-opacity="0.3"/>
        <stop offset="100%" stop-color="#09090b" stop-opacity="0.9"/>
      </radialGradient>
    </defs>
    <rect width="400" height="400" fill="url(#g)"/>
    <circle cx="200" cy="200" r="170" fill="url(#v)" stroke="#ffffff" stroke-width="2" stroke-opacity="0.15"/>
    <circle cx="200" cy="200" r="120" fill="none" stroke="#ffffff" stroke-width="1" stroke-opacity="0.1"/>
    <circle cx="200" cy="200" r="70" fill="none" stroke="#ffffff" stroke-width="1" stroke-opacity="0.15"/>
    <circle cx="200" cy="200" r="30" fill="#09090b" stroke="#ffffff" stroke-width="2" stroke-opacity="0.4"/>
    <circle cx="200" cy="200" r="8" fill="#ffffff" fill-opacity="0.8"/>
    <text x="200" y="320" font-family="sans-serif" font-weight="900" font-size="20" fill="#ffffff" text-anchor="middle" letter-spacing="2">${title.substring(0, 18).toUpperCase()}</text>
    <text x="200" y="345" font-family="sans-serif" font-weight="600" font-size="13" fill="#cbd5e1" text-anchor="middle">${artist.substring(0, 22)}</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
