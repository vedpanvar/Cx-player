import React, { useState, useEffect, useRef } from 'react';
import { AudioProvider, useAudio } from './context/AudioContext';
import { MobileHeader } from './components/MobileHeader';
import { HomeView } from './components/HomeView';
import { UpNextSidebar } from './components/UpNextSidebar';
import { MobileUpNextSheet } from './components/MobileUpNextSheet';
import { MobileEqualizerSheet } from './components/MobileEqualizerSheet';
import { MobileSearchSheet } from './components/MobileSearchSheet';
import { MobileSettingsSheet } from './components/MobileSettingsSheet';
import { DownloadToast } from './components/DownloadToast';
import { useChromaTheme } from './utils/themeColors';
import { initPlatformLifecycle } from './platform/PlatformLifecycle';

const CxplayerShell: React.FC = () => {
  const { currentSong, flushSyncState } = useAudio();
  const [isUpNextOpen, setIsUpNextOpen] = useState(false);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [isEqOpen, setIsEqOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSidebarDropTarget, setIsSidebarDropTarget] = useState(false);

  const backStateRef = useRef({
    isUpNextOpen,
    isLibraryOpen,
    isEqOpen,
    isSearchOpen,
    isSettingsOpen
  });
  backStateRef.current = {
    isUpNextOpen,
    isLibraryOpen,
    isEqOpen,
    isSearchOpen,
    isSettingsOpen
  };

  useEffect(() => {
    return initPlatformLifecycle({
      onBackButton: () => {
        const s = backStateRef.current;
        if (s.isSearchOpen) {
          setIsSearchOpen(false);
          return true;
        }
        if (s.isEqOpen) {
          setIsEqOpen(false);
          return true;
        }
        if (s.isSettingsOpen) {
          setIsSettingsOpen(false);
          return true;
        }
        if (s.isLibraryOpen) {
          setIsLibraryOpen(false);
          return true;
        }
        if (s.isUpNextOpen) {
          setIsUpNextOpen(false);
          return true;
        }
        return false;
      },
      onAppBackground: () => {
        void flushSyncState();
      }
    });
  }, [flushSyncState]);

  const theme = useChromaTheme(currentSong?.id, currentSong?.coverUrl);

  return (
    <div className="relative h-[100dvh] max-h-[100dvh] lg:h-auto lg:max-h-none lg:min-h-[100dvh] w-full bg-gradient-to-b from-[#f6f6f9] via-[#ececf2] to-[#e4e4ec] text-neutral-900 font-sans overflow-hidden lg:overflow-x-hidden select-none flex flex-col items-center antialiased pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)]">
      
      {/* Subtle Adaptive Studio Ambient Highlight */}
      <div
        className="fixed top-[-15%] left-1/2 -translate-x-1/2 w-full max-w-[540px] h-[360px] rounded-full blur-[120px] pointer-events-none z-0 transition-colors duration-700"
        style={{ backgroundColor: theme.ambientGlow }}
      />

      {/* Responsive Phone / Desktop Container */}
      <div className="relative z-10 w-full max-w-md lg:max-w-6xl flex-1 min-h-0 flex flex-col">
        <MobileHeader
          isUpNextOpen={isUpNextOpen}
          onToggleUpNext={() => setIsUpNextOpen((prev) => !prev)}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />

        <main className="relative flex-1 min-h-0 w-full flex flex-col">
          <HomeView
            onOpenLibrary={() => setIsLibraryOpen(true)}
            isSidebarDropTarget={isSidebarDropTarget}
          />
        </main>

        {/* Transparent Glass Up Next Sidebar (Both Modes) */}
        <UpNextSidebar
          isOpen={isUpNextOpen}
          onClose={() => setIsUpNextOpen(false)}
          onDropTargetChange={setIsSidebarDropTarget}
        />

        {/* Full Library, Liked Songs & Search Bottom Sheet */}
        <MobileUpNextSheet
          isOpen={isLibraryOpen}
          onClose={() => setIsLibraryOpen(false)}
        />

        {/* Equalizer & Sound FX Bottom Sheet */}
        <MobileEqualizerSheet
          isOpen={isEqOpen}
          onClose={() => setIsEqOpen(false)}
        />

        {/* Settings Sheet (with DJ controls toggle) */}
        <MobileSettingsSheet
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenLibrary={() => setIsLibraryOpen(true)}
          onOpenEqualizer={() => setIsEqOpen(true)}
        />

        {/* Search Sheet */}
        <MobileSearchSheet
          isOpen={isSearchOpen}
          onClose={() => setIsSearchOpen(false)}
        />

        <DownloadToast />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AudioProvider>
      <CxplayerShell />
    </AudioProvider>
  );
}
