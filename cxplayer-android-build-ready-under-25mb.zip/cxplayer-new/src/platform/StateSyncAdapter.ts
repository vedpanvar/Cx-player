import { Capacitor } from '@capacitor/core';
import { Preferences } from '@capacitor/preferences';
import { PersistedAppState, StateSyncAdapter } from './types';

const STORAGE_KEY = 'cxplayer_shared_state_v1';
const BROADCAST_CHANNEL = 'cxplayer_cross_tab_sync';

function isValidPersistedState(value: unknown): value is PersistedAppState {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as Record<string, unknown>;
  return candidate.version === 1 && typeof candidate.updatedAt === 'number';
}

export class CrossPlatformStateSyncAdapter implements StateSyncAdapter {
  private channel: BroadcastChannel | null = null;
  private listeners = new Set<(state: PersistedAppState) => void>();

  constructor() {
    if (typeof window !== 'undefined') {
      if ('BroadcastChannel' in window) {
        try {
          this.channel = new BroadcastChannel(BROADCAST_CHANNEL);
          this.channel.onmessage = (event) => {
            if (isValidPersistedState(event.data)) {
              this.listeners.forEach((fn) => fn(event.data));
            }
          };
        } catch {
          this.channel = null;
        }
      }
      window.addEventListener('storage', this.handleStorageEvent);
    }
  }

  private handleStorageEvent = (e: StorageEvent) => {
    if (e.key !== STORAGE_KEY || !e.newValue) return;
    try {
      const parsed = JSON.parse(e.newValue);
      if (isValidPersistedState(parsed)) {
        this.listeners.forEach((fn) => fn(parsed));
      }
    } catch {
      // Ignore malformed external storage payloads
    }
  };

  async load(): Promise<PersistedAppState | null> {
    try {
      if (Capacitor.isNativePlatform()) {
        const { value } = await Preferences.get({ key: STORAGE_KEY });
        if (value) {
          const parsed = JSON.parse(value);
          return isValidPersistedState(parsed) ? parsed : null;
        }
      }
      if (typeof localStorage !== 'undefined') {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          return isValidPersistedState(parsed) ? parsed : null;
        }
      }
    } catch {
      return null;
    }
    return null;
  }

  async save(state: PersistedAppState): Promise<void> {
    const serialized = JSON.stringify(state);
    try {
      if (Capacitor.isNativePlatform()) {
        await Preferences.set({ key: STORAGE_KEY, value: serialized });
      }
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(STORAGE_KEY, serialized);
      }
      if (this.channel) {
        this.channel.postMessage(state);
      }
    } catch {
      // Ignore storage quota errors
    }
  }

  subscribe(listener: (state: PersistedAppState) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  exportJson(state: PersistedAppState): string {
    return JSON.stringify(state, null, 2);
  }

  importJson(raw: string): PersistedAppState | null {
    try {
      const parsed = JSON.parse(raw);
      return isValidPersistedState(parsed) ? parsed : null;
    } catch {
      return null;
    }
  }

  dispose(): void {
    if (this.channel) {
      this.channel.close();
      this.channel = null;
    }
    if (typeof window !== 'undefined') {
      window.removeEventListener('storage', this.handleStorageEvent);
    }
    this.listeners.clear();
  }
}
