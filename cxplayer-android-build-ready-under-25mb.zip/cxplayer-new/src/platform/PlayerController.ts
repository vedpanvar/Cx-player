import { Capacitor } from '@capacitor/core';
import { AudioAdapter, AudioAdapterEventMap, AudioTrackPayload, PlatformKind } from './types';
import { WebAudioAdapter } from './WebAudioAdapter';
import { NativeAudioAdapter } from './NativeAudioAdapter';

export function detectPlatform(): PlatformKind {
  try {
    if (Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android') {
      return 'android';
    }
  } catch {
    // Fallback to web outside Capacitor
  }
  return 'web';
}

export function createAudioAdapter(platformOverride?: PlatformKind): AudioAdapter {
  const platform = platformOverride ?? detectPlatform();
  return platform === 'android' ? new NativeAudioAdapter() : new WebAudioAdapter();
}

export class PlayerController {
  private adapter: AudioAdapter;
  private loadedTrackId: string | null = null;
  private loadedUrl = '';
  private pendingLoad: Promise<void> | null = null;
  private loadSeq = 0;

  constructor(adapter?: AudioAdapter) {
    this.adapter = adapter ?? createAudioAdapter();
  }

  get platform(): PlatformKind {
    return this.adapter.kind;
  }

  async loadTrack(track: AudioTrackPayload, forceReload = false): Promise<void> {
    if (!forceReload && this.loadedTrackId === track.id && this.loadedUrl === track.audioUrl) {
      if (this.pendingLoad) {
        await this.pendingLoad;
      }
      return;
    }
    this.loadedTrackId = track.id;
    this.loadedUrl = track.audioUrl;
    const seq = ++this.loadSeq;
    const task = this.adapter.loadTrack(track);
    this.pendingLoad = task;
    try {
      await task;
    } finally {
      if (this.loadSeq === seq) {
        this.pendingLoad = null;
      }
    }
  }

  async play(): Promise<void> {
    if (this.pendingLoad) {
      await this.pendingLoad;
    }
    await this.adapter.play();
  }

  async pause(): Promise<void> {
    if (this.pendingLoad) {
      await this.pendingLoad;
    }
    await this.adapter.pause();
  }

  async seek(seconds: number): Promise<number> {
    if (this.pendingLoad) {
      await this.pendingLoad;
    }
    const dur = this.adapter.getDuration();
    const clamped = dur > 0 ? Math.max(0, Math.min(dur, seconds)) : Math.max(0, seconds);
    await this.adapter.seek(clamped);
    return clamped;
  }

  async setVolume(volume: number): Promise<void> {
    await this.adapter.setVolume(volume);
  }

  async setMuted(muted: boolean): Promise<void> {
    await this.adapter.setMuted(muted);
  }

  async setPlaybackRate(rate: number): Promise<void> {
    await this.adapter.setPlaybackRate(rate);
  }

  getCurrentTime(): number {
    return this.adapter.getCurrentTime();
  }

  getDuration(): number {
    return this.adapter.getDuration();
  }

  getAnalyserNode(): AnalyserNode | null {
    return this.adapter.getAnalyserNode();
  }

  getAudioElement(): HTMLAudioElement | null {
    return this.adapter.getAudioElement();
  }

  on<K extends keyof AudioAdapterEventMap>(
    event: K,
    handler: AudioAdapterEventMap[K]
  ): () => void {
    return this.adapter.on(event, handler);
  }

  dispose(): void {
    this.adapter.dispose();
  }
}
