import { AudioAdapter, AudioAdapterEventMap, AudioTrackPayload } from './types';

type ListenerStore = {
  [K in keyof AudioAdapterEventMap]: Set<AudioAdapterEventMap[K]>;
};

export class WebAudioAdapter implements AudioAdapter {
  readonly kind = 'web' as const;

  private audio: HTMLAudioElement | null = null;
  private webAudioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private currentSrc = '';
  private currentTrack: AudioTrackPayload | null = null;
  private volume = 0.85;
  private isMuted = false;
  private playbackRate = 1.0;

  private listeners: ListenerStore = {
    timeupdate: new Set(),
    loadedmetadata: new Set(),
    ended: new Set(),
    play: new Set(),
    pause: new Set(),
    remoteNext: new Set(),
    remotePrevious: new Set(),
    remoteTogglePlay: new Set(),
    audioFocusLost: new Set(),
    error: new Set()
  };

  constructor() {
    if (typeof Audio !== 'undefined') {
      const audio = new Audio();
      audio.preload = 'auto';
      audio.volume = this.volume;
      this.audio = audio;

      audio.addEventListener('timeupdate', this.handleTimeUpdate);
      audio.addEventListener('loadedmetadata', this.handleLoadedMetadata);
      audio.addEventListener('ended', this.handleEnded);
      audio.addEventListener('play', this.handlePlayEvent);
      audio.addEventListener('pause', this.handlePauseEvent);
      audio.addEventListener('error', this.handleError);
    }

    this.setupMediaSessionHandlers();
  }

  private emit<K extends keyof AudioAdapterEventMap>(
    event: K,
    ...args: Parameters<AudioAdapterEventMap[K]>
  ) {
    this.listeners[event].forEach((fn) => {
      (fn as (...a: Parameters<AudioAdapterEventMap[K]>) => void)(...args);
    });
  }

  private handleTimeUpdate = () => {
    if (!this.audio) return;
    const ct = this.audio.currentTime || 0;
    this.emit('timeupdate', ct);
    this.updateMediaSessionPosition();
  };

  private handleLoadedMetadata = () => {
    if (!this.audio) return;
    if (this.audio.duration && !isNaN(this.audio.duration) && isFinite(this.audio.duration)) {
      this.emit('loadedmetadata', this.audio.duration);
      this.updateMediaSessionPosition();
    }
  };

  private handleEnded = () => {
    this.emit('ended');
  };

  private handlePlayEvent = () => {
    if (typeof navigator !== 'undefined' && 'mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'playing';
    }
    this.emit('play');
  };

  private handlePauseEvent = () => {
    if (typeof navigator !== 'undefined' && 'mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'paused';
    }
    this.emit('pause');
  };

  private handleError = () => {
    this.emit('error', 'Failed to load web audio track.');
  };

  private setupMediaSessionHandlers() {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;
    const ms = navigator.mediaSession;
    try {
      ms.setActionHandler('play', () => this.emit('remoteTogglePlay'));
      ms.setActionHandler('pause', () => this.emit('remoteTogglePlay'));
      ms.setActionHandler('previoustrack', () => this.emit('remotePrevious'));
      ms.setActionHandler('nexttrack', () => this.emit('remoteNext'));
      ms.setActionHandler('seekto', (details) => {
        if (typeof details.seekTime === 'number') {
          void this.seek(details.seekTime);
        }
      });
    } catch {
      // Some browsers restrict specific MediaSession actions
    }
  }

  private updateMediaSessionMetadata(track: AudioTrackPayload) {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;
    if (typeof MediaMetadata === 'undefined') return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track.title,
        artist: track.artist,
        album: track.album || 'Cxplayer',
        artwork: track.coverUrl
          ? [{ src: track.coverUrl, sizes: '512x512', type: 'image/jpeg' }]
          : []
      });
    } catch {
      // Ignore metadata errors on non-supporting platforms
    }
  }

  private updateMediaSessionPosition() {
    if (typeof navigator === 'undefined' || !('mediaSession' in navigator)) return;
    const ms = navigator.mediaSession;
    if (!this.audio || typeof ms.setPositionState !== 'function') return;
    const duration = this.audio.duration;
    if (!duration || isNaN(duration) || !isFinite(duration) || duration <= 0) return;
    try {
      ms.setPositionState({
        duration,
        playbackRate: this.playbackRate || 1,
        position: Math.min(duration, Math.max(0, this.audio.currentTime || 0))
      });
    } catch {
      // Ignore invalid position states during track switching
    }
  }

  async loadTrack(track: AudioTrackPayload): Promise<void> {
    this.currentTrack = track;
    this.updateMediaSessionMetadata(track);

    if (!this.audio) return;
    if (track.audioUrl && this.currentSrc !== track.audioUrl) {
      this.currentSrc = track.audioUrl;
      this.audio.src = track.audioUrl;
      this.audio.playbackRate = this.playbackRate;
      this.audio.volume = this.isMuted ? 0 : this.volume;
    }
  }

  async play(): Promise<void> {
    this.getAnalyserNode();
    if (this.webAudioCtx && this.webAudioCtx.state === 'suspended') {
      await this.webAudioCtx.resume().catch(() => {});
    }
    if (this.audio && this.currentTrack?.audioUrl) {
      if (this.audio.src !== this.currentTrack.audioUrl) {
        this.audio.src = this.currentTrack.audioUrl;
        this.currentSrc = this.currentTrack.audioUrl;
      }
      this.audio.playbackRate = this.playbackRate;
      await this.audio.play().catch(() => {});
    }
  }

  async pause(): Promise<void> {
    if (this.audio) {
      this.audio.pause();
    }
  }

  async seek(seconds: number): Promise<void> {
    if (!this.audio) return;
    const dur = this.getDuration();
    const clamped = dur > 0 ? Math.max(0, Math.min(dur, seconds)) : Math.max(0, seconds);
    this.audio.currentTime = clamped;
    this.emit('timeupdate', clamped);
    this.updateMediaSessionPosition();
  }

  async setVolume(volume: number): Promise<void> {
    this.volume = Math.max(0, Math.min(1, volume));
    if (this.audio) {
      this.audio.volume = this.isMuted ? 0 : this.volume;
    }
  }

  async setMuted(muted: boolean): Promise<void> {
    this.isMuted = muted;
    if (this.audio) {
      this.audio.volume = muted ? 0 : this.volume;
    }
  }

  async setPlaybackRate(rate: number): Promise<void> {
    this.playbackRate = Math.max(0.5, Math.min(2.0, rate));
    if (this.audio) {
      this.audio.playbackRate = this.playbackRate;
    }
    this.updateMediaSessionPosition();
  }

  getCurrentTime(): number {
    return this.audio?.currentTime || 0;
  }

  getDuration(): number {
    if (!this.audio) return this.currentTrack?.duration || 0;
    const d = this.audio.duration;
    return d && !isNaN(d) && isFinite(d) ? d : this.currentTrack?.duration || 0;
  }

  getAudioElement(): HTMLAudioElement | null {
    return this.audio;
  }

  getAnalyserNode(): AnalyserNode | null {
    if (this.analyser) {
      if (this.webAudioCtx && this.webAudioCtx.state === 'suspended') {
        this.webAudioCtx.resume().catch(() => {});
      }
      return this.analyser;
    }
    if (!this.audio || typeof window === 'undefined') return null;

    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;

      const ctx = new AudioCtx();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.82;
      analyser.minDecibels = -90;
      analyser.maxDecibels = -10;

      this.audio.crossOrigin = 'anonymous';
      if (!this.sourceNode) {
        try {
          const source = ctx.createMediaElementSource(this.audio);
          source.connect(analyser);
          analyser.connect(ctx.destination);
          this.sourceNode = source;
        } catch {
          // Audio element source already created
        }
      }

      this.webAudioCtx = ctx;
      this.analyser = analyser;
      return analyser;
    } catch {
      return null;
    }
  }

  on<K extends keyof AudioAdapterEventMap>(
    event: K,
    handler: AudioAdapterEventMap[K]
  ): () => void {
    this.listeners[event].add(handler);
    return () => {
      this.listeners[event].delete(handler);
    };
  }

  dispose(): void {
    if (this.audio) {
      this.audio.removeEventListener('timeupdate', this.handleTimeUpdate);
      this.audio.removeEventListener('loadedmetadata', this.handleLoadedMetadata);
      this.audio.removeEventListener('ended', this.handleEnded);
      this.audio.removeEventListener('play', this.handlePlayEvent);
      this.audio.removeEventListener('pause', this.handlePauseEvent);
      this.audio.removeEventListener('error', this.handleError);
      this.audio.pause();
    }
    Object.values(this.listeners).forEach((set) => set.clear());
  }
}
