import { Capacitor } from '@capacitor/core';
import { App as CapacitorApp } from '@capacitor/app';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';

export interface LifecycleHandlers {
  onBackButton: () => boolean;
  onAppBackground?: () => void;
  onAppForeground?: () => void;
}

export function initPlatformLifecycle(handlers: LifecycleHandlers): () => void {
  if (!Capacitor.isNativePlatform()) {
    return () => {};
  }

  let disposed = false;
  const cleanups: Array<() => Promise<void> | void> = [];

  void (async () => {
    try {
      await StatusBar.setStyle({ style: Style.Dark });
      await StatusBar.setBackgroundColor({ color: '#ececf1' });
    } catch {
      // StatusBar plugin optional on unsupported devices
    }

    try {
      await SplashScreen.hide();
    } catch {
      // SplashScreen auto-hides cleanly
    }

    try {
      const backHandle = await CapacitorApp.addListener('backButton', () => {
        const handled = handlers.onBackButton();
        if (!handled) {
          void CapacitorApp.minimizeApp();
        }
      });
      if (disposed) {
        void backHandle.remove();
      } else {
        cleanups.push(() => backHandle.remove());
      }

      const stateHandle = await CapacitorApp.addListener('appStateChange', ({ isActive }) => {
        if (isActive) {
          handlers.onAppForeground?.();
        } else {
          handlers.onAppBackground?.();
        }
      });
      if (disposed) {
        void stateHandle.remove();
      } else {
        cleanups.push(() => stateHandle.remove());
      }
    } catch {
      // Ignore if App plugin unavailable
    }
  })();

  return () => {
    disposed = true;
    cleanups.forEach((fn) => {
      void fn();
    });
  };
}
