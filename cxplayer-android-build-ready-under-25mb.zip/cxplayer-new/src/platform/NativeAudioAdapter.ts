import { registerPlugin, PluginListenerHandle } from '@capacitor/core';
import { AudioAdapter, AudioAdapterEventMap, AudioTrackPayload } from './types';

export interface CxplayerAudioPlugin {
  loadTrack(options: {
    id: string;
    title: string;
    artist: string;
    album: string;
    audioUrl: string;
    coverUrl?: string;
    duration?: number;
  }): Promise<{ duration: number }>;
  cacheTrackData(options: {
    id: string;
    base64Data: string;
    mimeType: string;
  }): Promise<{ fileUri: string }>;
  play(): Promise<void>;
  pause(): Promise<void>;
  seek(options: { seconds: number }): Promise<void>;
  setVolume(options: { volume: number }): Promise<void>;
  setPlaybackRate(options: { rate: number }): Promise<void>;
  getState(): Promise<{
    currentTime: number;
    duration: number;
    isPlaying: boolean;
  }>;
  addListener(
    eventName:
      | 'timeUpdate'
      | 'stateChange'
      | 'trackEnded'
      | 'remoteNext'
      | 'remotePrevious'
      | 'remoteTogglePlay'
      | 'audioFocusLost'
      | 'audioError',
    listenerFunc: (data: Record<string, unknown>) => void
  ): Promise<PluginListenerHandle>;
}

const CxplayerAudio = registerPlugin<CxplayerAudioPlugin>('CxplayerAudio');

type ListenerStore = {
  [K in keyof AudioAdapterEventMap]: Set<AudioAdapterEventMap[K]>;
};

export class NativeAudioAdapter implements AudioAdapter {
  readonly kind = 'android' as const;

  private currentTime = 0;
  private duration = 0;
  private volume = 0.85;
  private isMuted = false;
  private cachedBlobUris = new Map<string, string>();
  private pluginListeners: PluginListenerHandle[] = [];

  private listeners: ListenerStore = {
    timeupdate: new Set(),
    loadedmetadata: new Set(),
    ended: new Set(),
    play: new Set(),
    pause: new Set(),
    remoteNext: new Set(),
    remotePrevious: new Set(),
    remoteTogglePlay: new Set(),
    audioFocusLost: new Set(),
    error: new Set()
  };

  constructor() {
    void this.attachNativeListeners();
  }

  private emit<K extends keyof AudioAdapterEventMap>(
    event: K,
    ...args: Parameters<AudioAdapterEventMap[K]>
  ) {
    this.listeners[event].forEach((fn) => {
      (fn as (...a: Parameters<AudioAdapterEventMap[K]>) => void)(...args);
    });
  }

  private async attachNativeListeners() {
    try {
      const h1 = await CxplayerAudio.addListener('timeUpdate', (data) => {
        const ct = typeof data.currentTime === 'number' ? data.currentTime : 0;
        const dur = typeof data.duration === 'number' ? data.duration : this.duration;
        this.currentTime = ct;
        if (dur > 0 && dur !== this.duration) {
          this.duration = dur;
          this.emit('loadedmetadata', dur);
        }
        this.emit('timeupdate', ct);
      });

      const h2 = await CxplayerAudio.addListener('stateChange', (data) => {
        if (data.isPlaying === true) {
          this.emit('play');
        } else {
          this.emit('pause');
        }
      });

      const h3 = await CxplayerAudio.addListener('trackEnded', () => {
        this.emit('ended');
      });

      const h4 = await CxplayerAudio.addListener('remoteNext', () => {
        this.emit('remoteNext');
      });

      const h5 = await CxplayerAudio.addListener('remotePrevious', () => {
        this.emit('remotePrevious');
      });

      const h6 = await CxplayerAudio.addListener('remoteTogglePlay', () => {
        this.emit('remoteTogglePlay');
      });

      const h7 = await CxplayerAudio.addListener('audioFocusLost', (data) => {
        this.emit('audioFocusLost', Boolean(data.transient));
      });

      const h8 = await CxplayerAudio.addListener('audioError', (data) => {
        this.emit('error', String(data.message || 'Native audio playback error'));
      });

      this.pluginListeners.push(h1, h2, h3, h4, h5, h6, h7, h8);
    } catch {
      // Ignore listener setup errors outside native Android runtime
    }
  }

  private async resolvePlayableUri(track: AudioTrackPayload): Promise<string> {
    if (!track.audioUrl) return '';
    if (!track.audioUrl.startsWith('blob:')) {
      return track.audioUrl;
    }

    const cached = this.cachedBlobUris.get(track.id);
    if (cached) return cached;

    try {
      const response = await fetch(track.audioUrl);
      const blob = await response.blob();
      const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const raw = String(reader.result || '');
          const commaIdx = raw.indexOf(',');
          resolve(commaIdx !== -1 ? raw.slice(commaIdx + 1) : raw);
        };
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(blob);
      });

      const { fileUri } = await CxplayerAudio.cacheTrackData({
        id: track.id,
        base64Data,
        mimeType: blob.type || 'audio/wav'
      });

      this.cachedBlobUris.set(track.id, fileUri);
      return fileUri;
    } catch {
      return track.audioUrl;
    }
  }

  async loadTrack(track: AudioTrackPayload): Promise<void> {
    const resolvedUri = await this.resolvePlayableUri(track);
    if (!resolvedUri) return;

    const result = await CxplayerAudio.loadTrack({
      id: track.id,
      title: track.title,
      artist: track.artist,
      album: track.album || 'Cxplayer',
      audioUrl: resolvedUri,
      coverUrl: track.coverUrl,
      duration: track.duration
    });

    if (result?.duration && result.duration > 0) {
      this.duration = result.duration;
      this.emit('loadedmetadata', result.duration);
    } else if (track.duration) {
      this.duration = track.duration;
    }
  }

  async play(): Promise<void> {
    await CxplayerAudio.play();
  }

  async pause(): Promise<void> {
    await CxplayerAudio.pause();
  }

  async seek(seconds: number): Promise<void> {
    const clamped =
      this.duration > 0 ? Math.max(0, Math.min(this.duration, seconds)) : Math.max(0, seconds);
    this.currentTime = clamped;
    await CxplayerAudio.seek({ seconds: clamped });
    this.emit('timeupdate', clamped);
  }

  async setVolume(volume: number): Promise<void> {
    this.volume = Math.max(0, Math.min(1, volume));
    await CxplayerAudio.setVolume({ volume: this.isMuted ? 0 : this.volume });
  }

  async setMuted(muted: boolean): Promise<void> {
    this.isMuted = muted;
    await CxplayerAudio.setVolume({ volume: muted ? 0 : this.volume });
  }

  async setPlaybackRate(rate: number): Promise<void> {
    await CxplayerAudio.setPlaybackRate({ rate: Math.max(0.5, Math.min(2.0, rate)) });
  }

  getCurrentTime(): number {
    return this.currentTime;
  }

  getDuration(): number {
    return this.duration;
  }

  getAnalyserNode(): AnalyserNode | null {
    return null;
  }

  getAudioElement(): HTMLAudioElement | null {
    return null;
  }

  on<K extends keyof AudioAdapterEventMap>(
    event: K,
    handler: AudioAdapterEventMap[K]
  ): () => void {
    this.listeners[event].add(handler);
    return () => {
      this.listeners[event].delete(handler);
    };
  }

  dispose(): void {
    this.pluginListeners.forEach((h) => {
      void h.remove().catch(() => {});
    });
    this.pluginListeners = [];
    Object.values(this.listeners).forEach((set) => set.clear());
  }
}
