import { RepeatMode } from '../types';

export type PlatformKind = 'web' | 'android';

export interface AudioTrackPayload {
  id: string;
  title: string;
  artist: string;
  album: string;
  audioUrl: string;
  coverUrl?: string;
  duration?: number;
}

export interface AudioAdapterEventMap {
  timeupdate: (time: number) => void;
  loadedmetadata: (duration: number) => void;
  ended: () => void;
  play: () => void;
  pause: () => void;
  remoteNext: () => void;
  remotePrevious: () => void;
  remoteTogglePlay: () => void;
  audioFocusLost: (transient: boolean) => void;
  error: (message: string) => void;
}

export interface AudioAdapter {
  readonly kind: PlatformKind;
  loadTrack(track: AudioTrackPayload): Promise<void>;
  play(): Promise<void>;
  pause(): Promise<void>;
  seek(seconds: number): Promise<void>;
  setVolume(volume: number): Promise<void>;
  setMuted(muted: boolean): Promise<void>;
  setPlaybackRate(rate: number): Promise<void>;
  getCurrentTime(): number;
  getDuration(): number;
  getAnalyserNode(): AnalyserNode | null;
  getAudioElement(): HTMLAudioElement | null;
  on<K extends keyof AudioAdapterEventMap>(
    event: K,
    handler: AudioAdapterEventMap[K]
  ): () => void;
  dispose(): void;
}

export interface PersistedAppState {
  version: 1;
  updatedAt: number;
  currentTrackId: string | null;
  currentTime: number;
  queueTrackIds: string[];
  queueIndex: number;
  likedSongIds: string[];
  downloadedSongIds: string[];
  djControlsEnabled: boolean;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  repeatMode: RepeatMode;
  pitchRate: number;
  equalizerPreset: string;
}

export interface StateSyncAdapter {
  load(): Promise<PersistedAppState | null>;
  save(state: PersistedAppState): Promise<void>;
  subscribe(listener: (state: PersistedAppState) => void): () => void;
  exportJson(state: PersistedAppState): string;
  importJson(raw: string): PersistedAppState | null;
}
