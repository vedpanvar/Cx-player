import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.cxplayer.app',
  appName: 'Cxplayer',
  webDir: 'dist',
  android: {
    allowMixedContent: true,
    backgroundColor: '#ececf1'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1200,
      launchAutoHide: true,
      backgroundColor: '#ececf1',
      androidSplashResourceName: 'splash',
      showSpinner: false
    },
    StatusBar: {
      overlaysWebView: false,
      style: 'DARK',
      backgroundColor: '#ececf1'
    }
  }
};

export default config;
